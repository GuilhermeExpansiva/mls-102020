/// <mls shortName="start" project="102020" enhancement="_blank" />
export function start() {
    console.info('start collab aura');
}
