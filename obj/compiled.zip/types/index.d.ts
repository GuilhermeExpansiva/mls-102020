declare module "_102020_/l2/aura.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/aura" {
    export class Aura {
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
}
declare module "_102020_/l2/auraOrganismBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/auraOrganismBase" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class AuraOrganismBase extends CollabLitElement {
    }
}
declare module "_102020_/l2/build.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/build" {
    export const DISTFOLDER = "wwwroot";
    export function buildModule(project: number, moduleName: string): Promise<boolean>;
}
declare module "_102020_/l2/collabAuraLiveView.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/collabAuraLiveView" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    import '/_100554_/l2/collabNav4Menu.js';
    interface ITab {
        moduleName: string;
        modulePath: string;
        project: number;
        pageInitial: string;
        actualPage: string;
        icon: string | undefined;
        target: string;
        iframe: HTMLIFrameElement | undefined;
    }
    export class CollabAuraLiveView102020 extends CollabLitElement {
        private msg;
        mode: 'develpoment' | 'production';
        actualTab: number;
        tabsMenu: any;
        lastInit: number;
        container?: HTMLElement;
        tabs: ITab[];
        private liveViewReady;
        get iframe(): HTMLIFrameElement | null;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        init(project: number, shortName: string, folder: string): Promise<void>;
        private setEvents;
        private onTabSelected;
        private onTabClosed;
        private checkToLoadPage;
        private setInitialTabInfos;
        private setActualTabInfos;
        private openTab;
        private closeTab;
        private addTab;
        private load;
        private toogleLoading;
        private loadPage;
        private loadInProduction;
        private loadInDevelopment;
        private APP_ID;
        private clearOldPageScripts;
        private injectHTML;
        private injectJS;
        private injectScriptRunTime;
        private injectGlobalStyle;
        private functionReplaceAnchor;
        private addStyleApp;
        private addScript;
    }
}
declare module "_102020_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102020_/l2/enhancementAura.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_102020_/l2/moleculeBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/moleculeBase" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export interface ParsedItem {
        value: string;
        label: string;
        disabled: boolean;
    }
    export interface ParsedGroup {
        label: string;
        items: ParsedItem[];
    }
    export class MoleculeAuraElement extends StateLitElement {
        protected slotTags: string[];
        connectedCallback(): void;
        /**
         * Hides all slot tags defined in slotTags array
         */
        private hideSlotTags;
        /**
         * Returns a single slot tag element by name
         */
        protected getSlot(tag: string): Element | null;
        /**
         * Returns all elements of a slot tag
         */
        protected getSlots(tag: string): Element[];
        /**
         * Returns an attribute value from a slot tag
         */
        protected getSlotAttr(tag: string, attr: string): string | null;
        /**
         * Returns the innerHTML of a slot tag
         */
        protected getSlotContent(tag: string): string;
        /**
         * Checks if a slot tag exists
         */
        protected hasSlot(tag: string): boolean;
        /**
         * Returns parsed items from slot tags
         */
        protected getItems(selector?: string): ParsedItem[];
        /**
         * Returns parsed groups with their items
         */
        protected getGroups(selector?: string): ParsedGroup[];
        /**
         * Returns standalone items (not inside groups)
         */
        protected getStandaloneItems(selector?: string): ParsedItem[];
        /**
         * Finds an item by value
         */
        protected findItem(value: string | null): ParsedItem | undefined;
    }
}
declare module "_102020_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102020_/l2/start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/start" {
    export function start(): void;
}
declare module "_102020_/l2/widgetPlaygroundState.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateBoolean.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateBoolean" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WcInputBoolean102020 extends CollabLitElement {
        value: boolean;
        name: string | undefined;
        label: string | undefined;
        disabled: boolean;
        hint: string | undefined;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateNumber.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateNumber" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WcInputNumber102020 extends CollabLitElement {
        value: number | undefined;
        name: string | undefined;
        label: string | undefined;
        min: number | undefined;
        max: number | undefined;
        step: number | undefined;
        placeholder: string | undefined;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        hint: string | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStatePreviewCode.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStatePreviewCode" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class PlaygroundStatePreviewCode extends MoleculeAuraElement {
        target: string;
        language: string;
        private code;
        private targetElement;
        private hljsLoaded;
        private codeEditor;
        firstUpdated(): Promise<void>;
        private loadHljs;
        private getSourceCode;
        private initContent;
        private formatHtml;
        private highlightCode;
        private debounceTimer;
        private handleInput;
        private updateDemo;
        private setStateDeep;
        private savedRange;
        private savedOffset;
        private saveSelection;
        private restoreSelection;
        private handleKeyDown;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateText.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateText" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WcInputText100554 extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autocorrect: 'off' | 'on' | undefined;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/agents/agentNewMolecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMolecule" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        ts: string;
        htmlUseCaseExample: string;
        group: string;
    };
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export function updateDefs(skill: string, fileReference: string, group: string): Promise<void>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        group: string;
        skillMd: string;
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner2" {
    import { IAgentAsync } from '_102027_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: TClarification;
    };
    export interface TClarification {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlannerClarification.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlannerClarification" {
    import { StateLitElement } from '_102027_/l2/stateLitElement';
    export interface ClarificationData {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
    export class AgentNewMoleculePlannerClarification102020 extends StateLitElement {
        private msg;
        data: ClarificationData;
        private _editingField;
        private _editingIndex;
        private _tempValue;
        private _expandedSections;
        private _startEdit;
        private _cancelEdit;
        private _saveEdit;
        private _dispatchChange;
        private _toggleSection;
        private _addRequirement;
        private _removeRequirement;
        private _handleKeydown;
        private _renderEditableField;
        private _renderRequirementsList;
        render(): any;
        private onAction;
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlayground.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlayground" {
    import { IAgentAsync } from '_102027_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export function getSource(file: mls.stor.IFileInfo): Promise<string>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        html: string;
    }
}
declare module "_102020_/l2/agents/templates/molecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/templates/molecule" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class TemplateMolecule extends StateLitElement {
        private msg;
        /**
      * =========================================================================
      * INPUT DATA (FROM ORGANISMS)
      * =========================================================================
      * Molecules SHOULD receive business data via @propertyDataSource or propertyCompositeDataSource when possible.
      */
        value: number | undefined;
        hint: string;
        label: string;
        loading: boolean;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView.defs" {
    export const group = "groupViewData";
    export const skill = "# Objective\nDisplay a data collection with adaptive layout that automatically switches between Table and Cards based on viewport size.\n\n# Responsibilities\n- Render data as Table on larger screens and Cards on smaller screens.\n- Automatically switch presentation based on configurable breakpoint.\n- Support row/card selection (none, single, multiple).\n- Display visual feedback for hover, selected, and disabled states.\n- Display empty and loading states.\n- Emit events for row clicks and selection changes.\n- Provide keyboard navigation and accessibility support.\n\n# Constraints\n- Must switch between Table and Cards based on viewport width.\n- Must respect selection mode configured.\n- Must block interactions when loading or disabled.\n- Must apply appropriate ARIA attributes for each presentation mode.\n\n# Notes\n- In Card mode, use first column as card title and remaining columns as field/value pairs.\n- Column `hidden` attribute can be used to hide specific fields in certain contexts.\n";
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    type SelectionMode = 'none' | 'single' | 'multiple';
    export class AdaptiveDataViewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        hoverable: boolean;
        selectable: boolean;
        /** When true, blocks all interactions (click/keyboard/selection). */
        disabled: boolean;
        /** Selection mode: none | single | multiple */
        selectionMode: SelectionMode;
        /** Breakpoint (px). Below this width -> cards, otherwise table. */
        breakpointPx: number;
        private isCardMode;
        private selectedIndexes;
        private activeIndex;
        private resizeObserver;
        private mediaQueryList;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changed: Map<string, unknown>): void;
        private setupResponsiveMode;
        private teardownResponsiveMode;
        private parseColumns;
        private parseRows;
        private getVisibleColumnIndexes;
        private syncSelectionFromSlots;
        private syncActiveIndex;
        private isInteractiveBlocked;
        private isRowSelected;
        private emitRowClick;
        private emitSelectionChange;
        private handleToggleSelection;
        private handleRowActivate;
        private handleKeyDown;
        private focusActiveRow;
        private getRowClasses;
        private getCardClasses;
        private getCellAlignClass;
        private renderLoadingState;
        private renderEmptyState;
        private renderSelectionHint;
        private renderTable;
        private renderCards;
        private renderContractValidation;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable.defs" {
    export const group = "groupViewTable";
    export const skill = "# Objective\nExibir uma tabela de dados responsiva em formato tradicional, permitindo que o sistema apresente registros com colunas configur\u00E1veis e c\u00E9lulas com conte\u00FAdo rico, com suporte a sele\u00E7\u00E3o de linhas e emiss\u00E3o de eventos de intera\u00E7\u00E3o.\n\n# Responsibilities\n- Renderizar os dados em um layout de tabela tradicional, com cabe\u00E7alho e corpo, adaptando-se a telas pequenas com rolagem horizontal quando necess\u00E1rio.\n- Aceitar a defini\u00E7\u00E3o de colunas por meio de Slot Tags, permitindo configurar r\u00F3tulo, alinhamento e largura por coluna.\n- Aceitar a defini\u00E7\u00E3o de linhas por meio de Slot Tags, garantindo associa\u00E7\u00E3o est\u00E1vel entre linha (id) e suas c\u00E9lulas (key).\n- Exibir conte\u00FAdo rico dentro das c\u00E9lulas conforme fornecido pelo desenvolvedor, preservando a estrutura e a sem\u00E2ntica do conte\u00FAdo apresentado.\n- Oferecer sele\u00E7\u00E3o de linhas conforme modo configurado: nenhuma, sele\u00E7\u00E3o \u00FAnica ou sele\u00E7\u00E3o m\u00FAltipla.\n- Exibir, quando configurado, uma coluna dedicada de sele\u00E7\u00E3o (checkbox ou radio) alinhada ao modo de sele\u00E7\u00E3o.\n- Refletir visualmente os estados de intera\u00E7\u00E3o: hover de linha, linha selecionada e foco de teclado.\n- Permitir intera\u00E7\u00E3o por teclado para sele\u00E7\u00E3o de linha (Enter/Espa\u00E7o) quando a linha estiver focada e a sele\u00E7\u00E3o estiver habilitada.\n- Emitir eventos de intera\u00E7\u00E3o:\n  - Ao selecionar ou desselecionar linhas.\n  - Ao clicar em uma linha (quando habilitado).\n  - Ao acionar um elemento marcado como a\u00E7\u00E3o dentro de uma c\u00E9lula.\n  - Opcionalmente, ao interagir com o cabe\u00E7alho quando necess\u00E1rio para delegar comportamentos a camadas superiores.\n- Exibir um estado vazio quando n\u00E3o houver linhas, usando conte\u00FAdo fornecido via Slot Tag espec\u00EDfica.\n\n# Constraints\n- N\u00E3o deve implementar pagina\u00E7\u00E3o, ordena\u00E7\u00E3o ou filtragem; quando aplic\u00E1vel, deve apenas sinalizar intera\u00E7\u00F5es por eventos para que camadas superiores decidam o comportamento.\n- Quando em estado disabled ou readonly:\n  - N\u00E3o deve permitir altera\u00E7\u00F5es de sele\u00E7\u00E3o.\n  - Deve impedir affordances de intera\u00E7\u00E3o relacionadas \u00E0 sele\u00E7\u00E3o.\n  - Deve manter a capacidade de visualiza\u00E7\u00E3o e rolagem do conte\u00FAdo.\n- A sele\u00E7\u00E3o deve respeitar o modo configurado:\n  - Em modo \"none\", nenhuma a\u00E7\u00E3o deve alterar sele\u00E7\u00E3o.\n  - Em modo \"single\", no m\u00E1ximo uma linha pode ficar selecionada.\n  - Em modo \"multiple\", m\u00FAltiplas linhas podem ficar selecionadas.\n- Quando uma sele\u00E7\u00E3o controlada for fornecida externamente:\n  - A tabela deve refletir o estado informado.\n  - Intera\u00E7\u00F5es do usu\u00E1rio devem apenas emitir eventos solicitando mudan\u00E7a, sem assumir que a sele\u00E7\u00E3o foi efetivada.\n- Deve garantir acessibilidade:\n  - Linhas selecionadas devem expor estado selecionado por atributos apropriados.\n  - Controles de sele\u00E7\u00E3o devem ter r\u00F3tulos acess\u00EDveis.\n  - A navega\u00E7\u00E3o por teclado deve ser poss\u00EDvel, com indicadores de foco vis\u00EDveis.\n\n# Notes\n- O conte\u00FAdo de c\u00E9lulas \u00E9 considerado fornecido pelo desenvolvedor; a tabela apenas apresenta o conte\u00FAdo e reporta intera\u00E7\u00F5es.\n- Uma legenda (caption) pode ser exibida quando fornecida, melhorando a compreens\u00E3o e acessibilidade do conjunto de dados.";
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    type SelectionMode = 'none' | 'single' | 'multiple';
    export class ResponsiveRichDataTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        striped: boolean;
        hoverable: boolean;
        bordered: boolean;
        compact: boolean;
        disabled: boolean;
        readonly: boolean;
        /** Enables emitting row-click event on row click */
        rowClickable: boolean;
        /** none | single | multiple */
        selectionMode: SelectionMode;
        /** Whether to render a dedicated selection control column */
        showSelectionColumn: boolean;
        /** Controlled selection: comma-separated ids OR array-like string. Recommended: comma-separated. */
        selectedIds: string | null;
        /** When true, the component will compute and apply selection changes internally. Default: false (controlled). */
        uncontrolledSelection: boolean;
        private internalSelected;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseSelectedIds;
        private getEffectiveSelectedSet;
        private getSelectionEnabled;
        private parseColumns;
        private parseRows;
        private getTextAlignClass;
        private getCellPaddingClasses;
        private getTableBaseClasses;
        private getCellBorderClasses;
        private getHeadCellClasses;
        private getBodyRowClasses;
        private getBodyCellClasses;
        private getColumnStyle;
        private getSelectionHeaderCellTemplate;
        private getSelectionBodyCellTemplate;
        private emitRowClick;
        private emitSelectionChange;
        private emitHeaderInteract;
        private emitCellAction;
        private requestToggleRowSelection;
        private requestToggleAllSelection;
        private handleRootClick;
        private handleRootKeyDown;
        private renderCaption;
        private renderLoadingState;
        private renderEmptyState;
        private renderHeader;
        private renderBody;
        private renderFooter;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/skills/aura/design.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/design" {
    export const skill = "\n\n---\nname: interface-design\ndescription: Interface design for organism and molecules implemented using Lit Web Components and Tailwind CSS.\n---\n\n# Tailwind Ui\n\n## Identity\n\nYou are a Tailwind CSS expert. You understand utility-first CSS, responsive\ndesign patterns, dark mode implementation, and how to build consistent,\nmaintainable component styles.\n\nYour core principles:\n1. Utility-first - compose styles from utilities, extract components when patterns repeat\n2. Responsive mobile-first - start with mobile, add breakpoint modifiers\n3. Design system consistency - use the theme, extend don't override\n4. Performance - purge unused styles, avoid arbitrary values when possible\n5. Accessibility - proper contrast, focus states, reduced motion\n\n# Implementation Stack\n\nAll interfaces must be implemented using:\n\n- **Lit 3.0 Web Components**\n- **Tailwind CSS**\n- **Semantic tokens mapped in Tailwind config**\n\n# Designing Frontend\n\n## Workflow\n\n1. **Conceptualize**\n   - Identify purpose and user context\n   - Choose a bold aesthetic direction (brutally minimal, maximalist, retro-futuristic, organic, luxury, brutalist, etc.)\n   - Define the one unforgettable element\n   - Note technical constraints (framework, performance, accessibility)\n\n2. **Implement**\n   - Write production-grade code (HTML/CSS/JS.)\n   - Apply aesthetic guidelines below\n\n3. **Verify**\n   - Check visual hierarchy and cohesion\n   - Test interactions and animations\n   - Validate accessibility requirements\n   - Confirm no generic patterns emerged\n\n4. **Iterate**\n   - Refine details based on verification\n   - Enhance distinctiveness where needed\n\n## Aesthetic Guidelines\n\n**Typography**\n- Use distinctive, characterful fonts (avoid Inter, Roboto, Arial, system fonts)\n- Pair expressive display fonts with refined body fonts\n\n**Color & Theme**\n- Build cohesive palettes with CSS variables\n- Use dominant colors with sharp accents, not evenly-distributed schemes\n- Avoid clich\u00E9d combinations (purple gradients on white)\n\n**Motion**\n- Create high-impact moments with orchestrated page loads and staggered reveals\n- Use CSS animations for HTML; Motion library for React\n- Add surprising hover states and scroll-triggered effects\n\n**Spatial Composition**\n- Break from grid conventions: asymmetry, overlap, diagonal flow\n- Use generous negative space OR intentional density\n\n**Backgrounds & Visual Effects**\n- Layer gradient meshes, noise textures, geometric patterns\n- Apply contextual effects: layered transparencies, dramatic shadows, decorative borders\n- Add atmosphere through depth and texture\n\n## Implementation Principles\n\n- **Match complexity to vision**: Maximalist designs require elaborate code; minimalist designs demand precision in spacing and typography\n- **Vary every design**: Different fonts, themes, aesthetics for each project\n- **Never converge**: Avoid repeated choices (Space Grotesk, common layouts)\n- **Context-specific**: Design should feel genuinely crafted for its purpose\n\n## Every Choice Must Be A Choice\n\nFor every decision, you must be able to explain WHY.\n\n- Why this layout and not another?\n- Why this color temperature?\n- Why this typeface?\n- Why this spacing scale?\n- Why this information hierarchy?\n\nIf your answer is \"it's common\" or \"it's clean\" or \"it works\" \u2014 you haven't chosen. You've defaulted. Defaults are invisible. Invisible choices compound into generic output.\n\n**The test:** If you swapped your choices for the most common alternatives and the design didn't feel meaningfully different, you never made real choices.\n";
}
declare module "_102020_/l2/skills/aura/moleculeGeneration.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/moleculeGeneration" {
    export const skill = "\n\n\n# Molecule Generation Skill\n\n> Skill for generating UI Molecule components in the MLS system.\n\n---\n\n## 1. Metadata\n\n| Field       | Value                                                                 |\n|-------------|-----------------------------------------------------------------------|\n| **Name**    | `moleculeGeneration`                                                  |\n| **Version** | `1.0.0`                                                               |\n| **Category**| `ui-generation`                                                       |\n| **Triggers**| `create molecule`, `generate ui component`, `new component`, `build molecule` |\n\n---\n\n## 2. Core Principles\n\nMolecules are **UI-first** components that follow these rules:\n\n| Principle              | Description                                                      |\n|------------------------|------------------------------------------------------------------|\n| **No Business Logic**  | Molecules do NOT contain business logic                          |\n| **No Shadow DOM**      | Molecules do NOT use Shadow Root                                 |\n| **Independence**       | Molecules must function independently                            |\n| **Data Flow**          | Data flows DOWN from Organisms via properties; events flow UP    |\n| **No Slots**           | Do NOT use the `<slot>` system                                   |\n\n---\n\n## 3. Naming Conventions\n\n### Tag Name (Custom Element)\n```\nkebab-case(folder)--kebab-case(component)-(projectId)\n```\n**Example:** `molecules--button-102020`\n\n### Class Name\n```\nPascalCase + Molecule\n```\n**Example:** `ButtonMolecule`\n\n### File Name\n```\ncamelCase.ts\n```\n**Example:** `buttonMolecule.ts`\n\n---\n\n## 4. Import Structure\n\n```typescript\n// Lit and directives \u2014 ALWAYS from 'lit'\nimport {\n    html,\n    HTMLTemplateResult,\n    classMap,\n    ifDefined,\n    repeat,\n    until,\n    choose,\n    guard,\n    keyed,\n    live,\n    ref\n} from 'lit';\n\n// Lit decorators\nimport { customElement, property, state } from 'lit/decorators';\n\n// Data Binding decorators\nimport { propertyDataSource, propertyCompositeDataSource } from '_100554_/l2/collabDecorators';\n\n// Base Class\nimport { StateLitElement } from '/_100554_/l2/stateLitElement';\n```\n\n---\n\n## 5. Property Decorators\n\n### `@propertyDataSource`\nBinds the property to a **single dynamic state**.\n\n```typescript\n@propertyDataSource({ type: String }) \nvalue: string | undefined;\n```\n**Binding:** `{{page1.name}}`\n\n---\n\n### `@propertyCompositeDataSource`\nBinds the property to **multiple composed states**.\n\n```typescript\n@propertyCompositeDataSource({ type: String }) \nlabel: string = '';\n```\n**Binding:** `Hello {{page1.userId}} - {{page1.userName}}`\n\n---\n\n### `@property`\nStandard Lit property for **static configuration or local UI state**.\n\n```typescript\n@property({ type: Boolean }) \nloading = false;\n\n@property({ type: String }) \nvariant: 'primary' | 'secondary' = 'primary';\n```\n\n---\n\n### `@state`\n**Internal** reactive state (not exposed as an attribute).\n\n```typescript\n@state() \nprivate isOpen = false;\n```\n\n---\n\n## 6. Internationalization (i18n) Structure\n\n```typescript\n/// **collab_i18n_start**\nconst message_en = {\n    loading: 'Loading...',\n    // add more messages as needed\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record = {\n    en: message_en,\n    pt: {\n        loading: 'Carregando...',\n    },\n    // add more languages as requested\n};\n/// **collab_i18n_end**\n```\n\n### Usage in Component\n```typescript\nrender() {\n    const lang = this.getMessageKey(messages);\n    this.msg = messages[lang];\n    \n    return html`${this.msg.loading}`;\n}\n```\n\n---\n\n## 7. Complete Structural Template\n\n```typescript\n/// <mls fileReference=\"[file-reference]\" enhancement=\"_102020_/l2/enhancementAura\"/>\n\n// =============================================================================\n// [COMPONENT NAME] MOLECULE \u2014 UI-FIRST COMPONENT\n// =============================================================================\n// [Brief description of the component]\n// This molecule does NOT contain business logic.\n\nimport {\n    html,\n    HTMLTemplateResult,\n    classMap,\n    ifDefined,\n} from 'lit';\n\nimport { customElement, property, state } from 'lit/decorators';\nimport { propertyDataSource, propertyCompositeDataSource } from '_100554_/l2/collabDecorators';\nimport { StateLitElement } from '/_100554_/l2/stateLitElement';\n\n/// **collab_i18n_start**\nconst message_en = {\n    loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record = {\n    en: message_en,\n};\n/// **collab_i18n_end**\n\n@customElement('molecules--[component-name]-102020')\nexport class [ComponentName]Molecule extends StateLitElement {\n\n    private msg: MessageType = messages.en;\n\n    // =========================================================================\n    // PROPERTIES \u2014 Data from Organisms\n    // =========================================================================\n    \n    @propertyDataSource({ type: String }) \n    value: string | undefined;\n\n    @propertyCompositeDataSource({ type: String }) \n    label: string = '';\n\n    @property({ type: Boolean }) \n    loading = false;\n\n    // =========================================================================\n    // INTERNAL STATE\n    // =========================================================================\n    \n    @state() \n    private isActive = false;\n\n    // =========================================================================\n    // EVENT HANDLERS\n    // =========================================================================\n    \n    private handleClick(e: Event) {\n        this.dispatchEvent(new CustomEvent('component-click', {\n            bubbles: true,\n            composed: true,\n            detail: { /* event data */ }\n        }));\n    }\n\n    // =========================================================================\n    // RENDER\n    // =========================================================================\n    \n    render() {\n        const lang = this.getMessageKey(messages);\n        this.msg = messages[lang];\n\n        if (this.loading) {\n            return html`${this.msg.loading}`;\n        }\n\n        return html`\n            \n                \n            \n        `;\n    }\n}\n```\n\n\n";
}
declare module "_102020_/l2/skills/aura/moleculeGeneration2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/moleculeGeneration2" {
    export const skill = "# Molecule Generation Skill\n\n> Skill for generating UI Molecule components in the Collab system.\n\n---\n\n## 1. Metadata\n\n| Field       | Value                                                           |\n|-------------|-----------------------------------------------------------------|\n| **Name**    | moleculeGeneration                                              |\n| **Version** | 2.0.1                                                           |\n| **Category**| ui-generation                                                   |\n\n---\n\n## 2. Core Principles\n\nMolecules are **UI-first** components that follow these rules:\n\n| Principle              | Description                                                      |\n|------------------------|------------------------------------------------------------------|\n| **No Business Logic**  | Molecules do NOT contain business logic                          |\n| **No Shadow DOM**      | Molecules do NOT use Shadow Root                                 |\n| **Independence**       | Molecules must function independently                            |\n| **Data Flow**          | Data flows DOWN from Organisms via properties; events flow UP    |\n| **Slot Tags**          | Use Slot Tags (unknown HTML elements) for internal structure     |\n| **Contract-Based**     | Each molecule belongs to a Skill Group with a defined contract   |\n| **Interchangeable**    | Molecules in the same group can be swapped without breaking      |\n\n---\n\n## 3. Naming Conventions\n\n### Tag Name (Custom Element)\n```\nkebab-case(folder)--kebab-case(component)-(projectId)\n```\n**Example:** folder/subfolder/molecule1 => 'folder--subfolder--molecule1-102020'\n\n### Class Name\n```\nPascalCase + Molecule\n```\n**Example:** `SelectMolecule`\n\n### File Name\n```\ncamelCase.ts\n```\n**Example:** `selectMolecule.ts`\n\n---\n\n## 4. Import Structure\n\n```typescript\n// Lit and directives \u2014 ALWAYS from 'lit'\nimport {\n    html,\n    TemplateResult,\n    ifDefined,\n    nothing,\n    unsafeHTML,\n    ...\n} from 'lit';\n\n// Lit decorators\nimport { customElement, property, state } from 'lit/decorators';\n\n// Data Binding decorators\nimport { propertyDataSource, propertyCompositeDataSource } from '_100554_/l2/collabDecorators';\n\n// Base Class\nimport { MoleculeAuraElement } from '/_102020_/l2/moleculeBase';\n```\n\n### Import Rules \u2014 CRITICAL\n\n```typescript\n// \u274C WRONG \u2014 Do NOT import directives from separate paths\nimport { unsafeHTML } from 'lit/directives/unsafe-html';\nimport { ifDefined } from 'lit/directives/if-defined';\nimport { classMap } from 'lit/directives/class-map';\nimport { repeat } from 'lit/directives/repeat';\n\n// \u2705 CORRECT \u2014 Import ALL directives from 'lit'\nimport { html, nothing, unsafeHTML, ifDefined, repeat } from 'lit';\n```\n\n> **Note:** Do NOT import `classMap`. Use template strings for CSS classes instead (see Section 7).\n\n---\n\n\n## 5. Property Decorators\n\n### `@propertyDataSource`\nBinds the property to a **single dynamic state**.\n\n```typescript\n@propertyDataSource({ type: String }) \nvalue: string | undefined;\n```\n**Binding:** `{{page1.selectedId}}`\n\n---\n\n### `@propertyCompositeDataSource`\nBinds the property to **multiple composed states**.\n\n```typescript\n@propertyCompositeDataSource({ type: String }) \nlabel: string = '';\n```\n**Binding:** `Hello {{page1.userId}} - {{page1.userName}}`\n\n---\n\n### `@property`\nStandard Lit property for **static configuration or local UI state**.\n\n```typescript\n@property({ type: Boolean }) \nloading = false;\n\n@property({ type: Boolean }) \ndisabled = false;\n```\n\n---\n\n### `@state`\n**Internal** reactive state (not exposed as an attribute).\n\n```typescript\n@state() \nprivate isOpen = false;\n```\n\n---\n\n## 6. Slot Tags\n\n### What are Slot Tags?\n\nSlot Tags are **unknown HTML elements** that define the molecule's internal structure. The user writes them declaratively, and the molecule reads and interprets them.\n\n```html\n<molecules--select-102020 value=\"a\">\n  <Trigger>\n    <Value placeholder=\"Select...\" />\n  </Trigger>\n  <Content>\n    <Group label=\"Fruits\">\n      <Item value=\"apple\">Apple</Item>\n      <Item value=\"banana\">Banana</Item>\n    </Group>\n    <Item value=\"other\">Other</Item>\n  </Content>\n</molecules--select-102020>\n```\n\n### Defining Slot Tags\nEach molecule must declare which Slot Tags it uses. Use ONLY the tags defined in the group contract. Do NOT create new tags.\n\n```typescript\nslotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n```\n\nThe base class automatically hides these tags so they don't appear on screen.\n\n### Reading Slot Tags\n\nUse the helper methods from `MoleculeAuraElement`:\n\n| Method | Returns | Description |\n|--------|---------|-------------|\n| `getSlot(tag)` | `Element | null` | Single slot tag element |\n| `getSlots(tag)` | `Element[]` | All elements of a slot tag |\n| `getSlotAttr(tag, attr)` | `string | null` | Attribute value from a slot tag |\n| `getSlotContent(tag)` | `string` | innerHTML of a slot tag |\n| `hasSlot(tag)` | `boolean` | Check if slot tag exists |\n| `getItems(selector?)` | `ParsedItem[]` | Parsed items with value, label, disabled |\n| `getGroups(selector?)` | `ParsedGroup[]` | Parsed groups with label and items |\n| `getStandaloneItems(selector?)` | `ParsedItem[]` | Items not inside groups |\n| `findItem(value)` | `ParsedItem | undefined` | Find item by value |\n\n---\n\n## 7. Naming Rules\n\n### Do NOT use `protected` or `override` in herdeded functions\n\nAll methods and properties should be `private` or without access modifier:\n\n```typescript\n// \u274C WRONG\nprotected firstUpdated() { }\nprotected override updated() { }\n\n// \u2705 CORRECT\n\nfirstUpdated() {\n  // ...\n}\n\nprivate handleSelect(value: string) {\n  // ...\n}\n```\n\n### Reserved Method Names - Do NOT Use\n\nThese names are used by Lit internally. Using them for other purposes will cause errors:\n\n| Reserved Name | Reason |\n|---------------|--------|\n| `renderOptions` | Lit internal |\n| `renderRoot` | Lit internal |\n| `createRenderRoot` | Lit internal |\n| `connectedCallback` | Lifecycle (use only for override) |\n| `disconnectedCallback` | Lifecycle (use only for override) |\n| `attributeChangedCallback` | Lifecycle (use only for override) |\n| `requestUpdate` | Lit internal |\n| `performUpdate` | Lit internal |\n| `shouldUpdate` | Lit internal |\n| `willUpdate` | Lit internal |\n| `update` | Lit internal |\n| `updated` | Lifecycle (use only for override) |\n| `firstUpdated` | Lifecycle (use only for override) |\n\n### Use descriptive prefixes for custom methods\n\n```typescript\n// \u274C WRONG - may conflict with Lit\nrenderOptions() { }\nupdateValue() { }\n\n// \u2705 CORRECT - clear custom method names\nrenderItemList() { }\nrenderDropdownContent() { }\nrenderTriggerButton() { }\nhandleValueChange() { }\nonItemSelect() { }\n```\n\n---\n\n## 8. CSS Classes Pattern\n\n### Do NOT use `classMap` with multiple classes\n\nThe `classMap` directive expects **one class per key**. Using multiple classes as a key causes errors:\n\n```typescript\n// \u274C WRONG - causes DOMTokenList error\nclassMap({\n  'border-slate-300 bg-white': !isSelected,  // Multiple classes as key\n})\n\n// \u274C WRONG - same problem with variable\nconst base = 'w-full rounded-md px-3 py-2';\nclassMap({\n  [base]: true,  // Multiple classes as key\n})\n```\n\n### Use template strings instead\n\nBuild CSS classes using arrays and `join()`:\n\n```typescript\n// \u2705 CORRECT - template strings\nconst classes = [\n  // Base classes (always applied)\n  'w-full rounded-md px-3 py-2 text-sm border transition',\n  // Conditional classes\n  isSelected ? 'border-sky-500 bg-sky-50 text-sky-900' : 'border-slate-200 bg-white hover:bg-slate-50',\n  // State classes\n  disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',\n].join(' ');\n\nreturn html`<button class=${classes}>...</button>`;\n```\n\n### Pattern for complex states\n\n```typescript\nprivate getItemClasses(item: ParsedItem, isSelected: boolean): string {\n  return [\n    // Base\n    'w-full rounded-md px-3 py-2 text-sm border transition',\n    // Selection state\n    isSelected \n      ? 'border-sky-500 bg-sky-50 text-sky-900' \n      : 'border-slate-200 bg-white text-slate-900',\n    // Hover (only when not disabled)\n    !item.disabled && !isSelected ? 'hover:bg-slate-50' : '',\n    // Disabled state\n    item.disabled ? 'opacity-50 cursor-not-allowed' : '',\n    // Focus state\n    !item.disabled ? 'focus:outline-none focus:ring-2 focus:ring-sky-500' : '',\n  ].filter(Boolean).join(' ');\n}\n\nrender() {\n  const items = this.getItems();\n\n  return html`\n    ${items.map(item => {\n      const isSelected = item.value === this.value;\n      \n      return html`\n        <button \n          class=${this.getItemClasses(item, isSelected)}\n          @click=${() => this.handleSelect(item.value)}\n        >\n          ${item.label}\n        </button>\n      `;\n    })}\n  `;\n}\n```\n\n---\n## 9. Using `nothing` Correctly\n\n### Understanding Lit's `nothing`\n\nThe `nothing` sentinel from Lit is **NOT** a `TemplateResult`. It has its own type: `typeof nothing`.\n\n**Type definitions:**\n- `TemplateResult` \u2014 returned by `html` tagged template\n- `typeof nothing` \u2014 the type of the `nothing` constant\n\n### Do NOT return `nothing` directly from methods typed as `TemplateResult`\n\nSolution 1: Wrap`nothing` in `html` template\n\n\n---\n\n## 10. Rendering Slot Tag Content\n\nSlot Tag content may contain HTML. To render it properly, use `unsafeHTML` directive.\n\n### Do NOT use dynamic template strings\n\n```typescript\n// \u274C WRONG - causes \"invalid template strings array\" error\nhtml([content] as unknown as TemplateStringsArray)\n\n// \u274C WRONG - same error\nhtml(content)\n\n// \u274C WRONG - HTML will be escaped, not rendered\nconst content = '<strong>Bold</strong>';\nhtml`${content}`  // Outputs: \"<strong>Bold</strong>\" as text\n```\n\n### Use `unsafeHTML` for Slot Tag content\n\n```typescript\n\n// \u2705 CORRECT - HTML is rendered properly\nprivate renderItem(item: ParsedItem): TemplateResult {\n  return html`\n    <div class=\"item\">\n      ${unsafeHTML(item.label)}\n    </div>\n  `;\n}\n\n// \u2705 CORRECT - with fallback\nprivate renderEmpty(): TemplateResult {\n  const content = this.getSlotContent('Empty') || this.msg.noResults;\n  return html`\n    <div class=\"text-slate-500\">\n      ${unsafeHTML(content)}\n    </div>\n  `;\n}\n```\n\n### When to use each approach\n\n| Content Type | Approach | Example |\n|--------------|----------|---------|\n| Plain text (i18n messages) | Direct interpolation | `${this.msg.loading}` |\n| Slot Tag content (may have HTML) | `unsafeHTML` | `${unsafeHTML(item.label)}` |\n| User input (untrusted) | Never render as HTML | Always escape |\n\n> **Note:** Slot Tag content comes from the developer (trusted), so `unsafeHTML` is safe to use.\n\n```typescript\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n  pt: {\n    placeholder: 'Selecione uma op\u00E7\u00E3o',\n    noResults: 'Nenhum resultado encontrado',\n    loading: 'Carregando...',\n  },\n};\n/// **collab_i18n_end**\n```\n\n### Usage\n```typescript\nrender() {\n  const lang = this.getMessageKey(messages);\n  this.msg = messages[lang];\n  \n  return html`${this.msg.placeholder}`;\n}\n```\n\n---\n\n## 11. Component Template\n\n```typescript\n/// <mls fileReference=\"[file-reference]\" enhancement=\"_102020_/l2/enhancementAura\"/>\n\n// =============================================================================\n// [COMPONENT NAME] MOLECULE\n// =============================================================================\n// Skill Group: [group-name] (e.g., select + one)\n// This molecule does NOT contain business logic.\n\nimport { html, TemplateResult, classMap, nothing, unsafeHTML } from 'lit';\nimport { customElement, property, state } from 'lit/decorators';\nimport { propertyDataSource } from '_100554_/l2/collabDecorators';\nimport { MoleculeAuraElement } from '/_102020_/l2/moleculeBase';\n\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n};\n/// **collab_i18n_end**\n\n@customElement('molecules--[component-name]-102020')\nexport class [ComponentName]Molecule extends MoleculeAuraElement {\n\n  private msg: MessageType = messages.en;\n\n  // ===========================================================================\n  // SLOT TAGS\n  // ===========================================================================\n\n  slotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n\n  // ===========================================================================\n  // PROPERTIES \u2014 From Contract\n  // ===========================================================================\n  \n  @propertyDataSource({ type: String }) \n  value: string | null = null;\n\n  @property({ type: Boolean }) \n  disabled = false;\n\n  @property({ type: Boolean }) \n  readonly = false;\n\n  @property({ type: Boolean }) \n  loading = false;\n\n  @property({ type: Boolean }) \n  required = false;\n\n  @property({ type: String }) \n  error: string | boolean = false;\n\n  @property({ type: String }) \n  name = '';\n\n  // ===========================================================================\n  // INTERNAL STATE\n  // ===========================================================================\n  \n  @state() \n  private isOpen = false;\n\n  // ===========================================================================\n  // EVENT HANDLERS\n  // ===========================================================================\n  \n  private handleSelect(value: string) {\n    if (this.disabled || this.readonly) return;\n\n    this.value = value;\n    this.isOpen = false;\n    \n    this.dispatchEvent(new CustomEvent('change', {\n      bubbles: true,\n      composed: true,\n      detail: { value }\n    }));\n  }\n\n  private handleBlur() {\n    this.dispatchEvent(new CustomEvent('blur', {\n      bubbles: true,\n      composed: true,\n    }));\n  }\n\n  // ===========================================================================\n  // RENDER\n  // ===========================================================================\n  \n  render() {\n    const lang = this.getMessageKey(messages);\n    this.msg = messages[lang];\n\n    if (this.loading) {\n      return html`<div class=\"loading\">${this.msg.loading}</div>`;\n    }\n\n    const placeholder = this.getSlotAttr('Value', 'placeholder') || this.msg.placeholder;\n    const items = this.getItems();\n    const selectedItem = this.findItem(this.value);\n\n    return html`\n      <div class=\"relative w-full\">\n        \n        <!-- Trigger -->\n        <button \n          type=\"button\"\n          class=\"w-full px-4 py-2 text-left border rounded-lg bg-white\"\n          ?disabled=${this.disabled}\n          @click=${() => this.isOpen = !this.isOpen}\n          @blur=${this.handleBlur}\n        >\n          ${selectedItem ? selectedItem.label : placeholder}\n        </button>\n\n        <!-- Content -->\n        ${this.isOpen ? html`\n          <div class=\"absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg\">\n            ${items.length > 0 ? items.map(item => html`\n              <div \n                class=${classMap({\n                  'px-4 py-2 cursor-pointer': true,\n                  'hover:bg-gray-100': !item.disabled,\n                  'bg-blue-50': item.value === this.value,\n                  'opacity-50 cursor-not-allowed': item.disabled,\n                })}\n                @click=${() => !item.disabled && this.handleSelect(item.value)}\n              >\n                ${item.label}\n              </div>\n            `) : html`\n              <div class=\"px-4 py-2 text-gray-500\">\n                ${this.getSlotContent('Empty') || this.msg.noResults}\n              </div>\n            `}\n          </div>\n        ` : nothing}\n\n      </div>\n    `;\n  }\n}\n```\n\n---\n\n## 12. Skill Groups\n\nEach molecule belongs to a **Skill Group** that defines its contract:\n\n| Group | Category | Contract File |\n|-------|----------|---------------|\n| `select + one` | Data Entry | `contract-select-one.md` |\n| `select + many` | Data Entry | `contract-select-many.md` |\n| `toggle + state` | Data Entry | `contract-toggle-state.md` |\n| `enter + text` | Data Entry | `contract-enter-text.md` |\n| `enter + number` | Data Entry | `contract-enter-number.md` |\n\nThe contract defines:\n- **Properties** (value, disabled, etc.)\n- **Events** (change, blur, etc.)\n- **Slot Tags** (Trigger, Content, Item, etc.)\n- **Validation Rules**\n\n---\n\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 03/23/2026 | Initial skill definition |\n| 2.0.0 | 04/01/2026 | Added Slot Tags system, contracts, interchangeability |\n| 2.1.0 | 04/02/2026 | Replaced classMap with template strings pattern for CSS classes |\n| 2.2.0 | 04/02/2026 | Added unsafeHTML for rendering Slot Tag content |\n| 2.3.0 | 04/02/2026 | Added naming rules: no protected/override, reserved method names |\n| 2.4.0 | 04/13/2026 | Added section 9: correct usage of `nothing` with proper return types |\n";
}
declare module "_102020_/l2/skills/aura/overview.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/overview" {
    export const skill = "\n## Skill \u2014 Frontend Architecture \u2014 Collab Aura\n\nThis document defines the official frontend architecture, design principles, and responsibilities for building applications using Collab Aura.\nAll components, pages, and integrations MUST follow these rules.\n\n## Core Architecture Principles\n### Atomic Design Structure\nThe frontend follows Atomic Design, with the following hierarchy:\n- Page \u2192 Top-level screen and orchestration layer\n- Organism \u2192 Complex UI sections composed of molecules and plugins\n- Molecule \u2192 Reusable UI components, presentation-only\n- Plugin \u2192 Integration components that communicate with external services\nEach level has a strict responsibility and separation of concerns.\n\n### Technology Stack\n- Use Lit 3 to build Web Components\n- Do NOT use Shadow DOM\n- Use Tailwind CSS for styling\n- Use SPA (Single Page Application) architecture\n- Each page corresponds to a URL entry point\n\n### Backend Communication Model\nFollow the BFF (Backend for Frontend) pattern.\nFrontend MUST communicate with backend routines using the BFF abstraction layer.\nAll backend communication MUST go through the frontend backend gateway (beInvoke or equivalent).\nDirect backend calls outside this abstraction are NOT allowed.\n\n### Data Fetching Strategy\nUse Stale-While-Revalidate (SWR) strategy for optimal perceived performance.\nThis means:\n- First attempt to load data from local IndexedDB (fast response)\n- Mark data consistency as \"stale\"\n- Then fetch fresh data from backend\n- Update state and IndexedDB when backend responds\n- Mark data consistency as \"fresh\"\nThis improves performance and user experience.\n\n## State Management\nGlobal state is used by pages and organisms.\nState naming:\nui.[pageName].[stateName]\nExamples:\nui.productDetail.product  \nui.productDetail.productConsistency  \nui.productDetail.onLoadMore  \nState types:\n- Data state \u2192 holds UI data\n- Event state \u2192 triggers actions (example: onUpdateUser)\nRules:\n- Pages MUST NOT pass data to organisms via properties, prefer states.\n- Molecules MUST NOT access global state.\n\n## Page Definitions\nA Page is a Web Component responsible for orchestrating the entire screen.\nResponsibilities:\n- Entry point of the user interface\n- Each page corresponds to a URL\n- Render the overall layout\n- Render organisms and plugins\n- Own business logic\n- Communicate with backend using BFF\n- Manage state lifecycle\n- Define state contracts for child organisms\n- Implement data fetching using SWR pattern\nPages MUST:\n- Follow business rules\n- Render SPA-compatible HTML\n- Render organisms and sections inside a root <div>\n- Orchestrate tabs and conditional content if needed\n- Update state based on backend responses\nPages MUST NOT:\n- Contain reusable UI logic that belongs in organisms\n- Contain reusable UI components that belong in molecules\nTesting:\nEach page MUST have a corresponding test file:\npageName.test.ts\nTests MUST verify:\n- Business logic\n- State transitions\n- Backend communication behavior\n\n## Organism Definitions\nOrganisms are Web Components responsible for rendering complex UI sections.\nResponsibilities:\n- Render layout sections\n- Combine molecules and plugins\n- Receive data via global states\n- Emit events via state updates\nOrganisms MUST:\n- Follow defined property contracts\n- Be reusable within the project\nOrganisms MUST NOT:\n- Communicate directly with backend\n- Own business logic\n- Fetch data\nTesting:\nEach organism MUST have:\norganismName.test.ts\nTests MUST verify:\n- Layout rendering\n- Property handling\n- State-driven rendering behavior\n\n## Molecule Definitions\nMolecules are reusable UI components.\nResponsibilities:\n- Render UI elements\n- Be highly reusable\n- Be presentation-only\nMolecules MUST:\n- Receive data only via properties\n- Be stateless regarding global application state\nMolecules MUST NOT:\n- Access global state\n- Communicate with backend\n- Contain business logic\n\n## Plugin Definitions\nPlugins are Web Components responsible for integrating with external services.\nExamples:\n- Payment platforms\n- External APIs\n- Third-party integrations\n- Analytics services\nPlugins MAY:\n- Communicate with external services\n- Provide integration functionality\nPlugins MUST NOT:\n- Contain core business logic of the application\n- Own application state\n\n## Folder and File Organization\nAll frontend files MUST follow this structure:\n_[projectId]_/l2/[moduleName]/[componentName].[extension]\nDefinitions:\n- projectId \u2192 numeric project identifier (example: 100111)\n- l2 \u2192 frontend layer\n- moduleName \u2192 module name or folder\n- componentName \u2192 component name using camelCase\n- extension \u2192 file type (ts, test.ts, defs.ts, css, etc.)\nImport rules:\n- Always use absolute project-based imports \nExample:\nimport \"/_100111_/l2/user/userProfileOrganism.js\";\n\nAll generated frontend code MUST strictly follow this architecture.\n";
}
declare module "_102020_/l2/skills/design/glassmorphism.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/glassmorphism" {
    export const skill = "\n\n# Skill: Glassmorphism\n\n## Philosophy\n> \"Depth through transparency. Light caught in layers.\"\n\nComponents float above a dark gradient canvas, simulating frosted glass. The background bleeds through every surface. Hierarchy is built with opacity and blur, not color or shadow.\n\n---\n\n## Canvas\n\nThis skill is **dark only**. Components must always render over a dark gradient canvas.\n\nThe canvas color palette is **free** \u2014 chosen by the implementer. What is required is the structure:\n\n```html\n<!-- Required canvas structure -->\n<div class=\"bg-gradient-to-br from-[your-color-950] via-[your-color-950] to-[your-color-950]\">\n\n  <!-- Ambient orbs: optional but recommended for depth -->\n  <div class=\"absolute w-96 h-96 rounded-full blur-3xl pointer-events-none bg-[--your-color]/20\" />\n  <div class=\"absolute w-80 h-80 rounded-full blur-3xl pointer-events-none bg-[your-color]/20\" />\n\n</div>\n```\n\n## Canvas rules\n- Background must be **dark** (`*-900` to `*-950` range)\n- Gradient must have **at least 2 stops** for depth\n- Ambient orbs use the same hue family as the gradient, at low opacity (`/15` to `/25`)\n- Orbs must be `pointer-events-none` and positioned absolutely\n\n> Components rendered without a dark canvas will lose their visual effect entirely.\n\n---\n\n## Tokens\n\n### Glass Surface (Moderate \u2014 default)\n| Token | Value |\n|---|---|\n| Background | `bg-white/10` |\n| Backdrop blur | `backdrop-blur-md` |\n| Border | `border border-white/20` |\n| Border highlight | `border-t-white/30` (top edge only) |\n| Inner glow | `shadow-inner shadow-white/5` |\n\n> **Intensity scale for reference:**\n> - Subtle: `bg-white/5` + `backdrop-blur-sm` + `border-white/10`\n> - **Moderate: `bg-white/10` + `backdrop-blur-md` + `border-white/20`** \u2190 default\n> - Intense: `bg-white/15` + `backdrop-blur-xl` + `border-white/30`\n\n### Color\n| Token | Value |\n|---|---|\n| Text Primary | `white` |\n| Text Secondary | `white/60` |\n| Text Muted | `white/40` |\n| Accent | inherits from canvas palette |\n| Danger | inherits from implementer |\n| Success | inherits from implementer |\n\n> All semantic colors are defined by the implementer. Use `*-300` or `*-400` lightness range to ensure legibility on dark backgrounds.\n\n### Typography\n| Token | Value |\n|---|---|\n| Font family | `font-sans` |\n| Body size | `text-base` |\n| Label size | `text-sm` |\n| Heading size | `text-xl` |\n| Body weight | `font-normal` |\n| Heading weight | `font-semibold` |\n| Heading tracking | `tracking-wide` |\n| Text rendering | `antialiased` |\n\n### Spacing\n| Token | Value |\n|---|---|\n| Component padding | `p-6` |\n| Element gap | `gap-4` |\n| Section gap | `gap-8` |\n\n### Shape\n| Token | Value |\n|---|---|\n| Border radius | `rounded-2xl` |\n| Border width | `border` (1px) |\n| Outer glow | `shadow-lg shadow-black/30` |\n\n### Interaction\n| State | Value |\n|---|---|\n| Hover (surface) | `hover:bg-white/15` |\n| Hover (border) | `hover:border-white/30` |\n| Focus ring | `focus-visible:ring-1 focus-visible:ring-white/50 focus-visible:ring-offset-0` |\n| Transition | `transition-all duration-200` |\n| Active | `active:bg-white/20` |\n\n> `ring-offset-0` is intentional \u2014 offset creates visual glitching on glass surfaces.\n\n---\n\n## Layering System\n\nGlass components gain depth through stacking. Use opacity to signal hierarchy:\n\n| Layer | bg | blur | border |\n|---|---|---|---|\n| Base (canvas) | gradient | \u2014 | \u2014 |\n| Card / Panel | `white/10` | `backdrop-blur-md` | `white/20` |\n| Elevated (modal, popover) | `white/15` | `backdrop-blur-lg` | `white/25` |\n| Tooltip / Badge | `white/20` | `backdrop-blur-sm` | `white/30` |\n\n---\n\n## Rules\n\n### \u2705 Do\n- Always render over a dark gradient canvas\n- Use `border-t-white/30` on the top edge to simulate light hitting glass\n- Use ambient orbs (`blur-3xl`) behind key components to add depth\n- Keep text `white` or `white/60` \u2014 never dark text on glass\n- Use `rounded-2xl` consistently\n- Prefer `transition-all` for smooth glass state changes\n- Use `pointer-events-none` on all decorative elements\n- Derive accent color from the canvas palette\n\n### \u274C Never\n- Render components on a white or light background\n- Use opaque backgrounds (`bg-zinc-900`, `bg-slate-800`, etc.)\n- Use colored borders \u2014 only `white/*` opacity borders\n- Use `ring-offset` on focus states\n- Use `font-bold` \u2014 weight feels heavy against transparent surfaces\n- Stack more than 3 glass layers\n- Use drop shadows with color \u2014 only `shadow-black/*`\n\n---\n\n## Iconography\n- Style: **outline / stroke**\n- Stroke width: `1.5`\n- Size: `size-5`\n- Color: `text-white/70` default, accent color for emphasis\n\n---\n\n## Tone\nEthereal. Expensive. Cinematic.  \nLight passes through every surface. The canvas is always part of the component.\n\n";
}
declare module "_102020_/l2/skills/design/minimalist.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/minimalist" {
    export const skill = "\n# Skill: Minimalist\n\n## Philosophy\n\n> \"The component exists. Nothing more.\"\n\nEverything that doesn't communicate is removed.  \nNo decorative shadows, no gradients, no unnecessary borders.  \nWhite space is not empty \u2014 it is the design itself.\n\n---\n\n## Tokens\n\n### Color\n\n| Token            | Light    | Dark     |\n|------------------|----------|----------|\n| Background       | zinc-50  | zinc-950 |\n| Surface          | white    | zinc-900 |\n| Border           | zinc-200 | zinc-800 |\n| Text Primary     | zinc-900 | zinc-50  |\n| Text Secondary   | zinc-500 | zinc-400 |\n| Accent           | zinc-900 | zinc-50  |\n\n**Note:**  \nAccent is the text itself. No separate accent color.\n\n---\n\n### Typography\n\n| Token             | Value                  |\n|-------------------|------------------------|\n| Font family       | font-sans (system-ui)  |\n| Body size         | text-base              |\n| Label size        | text-sm                |\n| Heading size      | text-lg                |\n| Body weight       | font-normal            |\n| Emphasis weight   | font-medium            |\n| Heading tracking  | tracking-tight         |\n\n**Rule:**  \nNever use `font-bold` or `font-semibold`.\n\n---\n\n### Spacing\n\n| Token             | Value                |\n|-------------------|----------------------|\n| Component padding | p-6 or p-8           |\n| Element gap       | gap-4 or gap-6       |\n| Section gap       | gap-8 or gap-12      |\n\n**Rule:**  \nWhen in doubt, add more space.\n\n---\n\n### Shape\n\n| Token         | Value                                      |\n|---------------|--------------------------------------------|\n| Border radius | rounded-none or rounded-sm                 |\n| Border width  | border (1px)                               |\n| Border color  | border-zinc-200 / dark:border-zinc-800     |\n| Shadow        | none                                       |\n\n---\n\n### Interaction\n\n| State        | Value                                                                 |\n|--------------|-----------------------------------------------------------------------|\n| Hover (bg)   | hover:bg-zinc-100 / dark:hover:bg-zinc-800                           |\n| Hover (text) | hover:text-zinc-600                                                  |\n| Focus ring   | focus-visible:ring-1 focus-visible:ring-zinc-900 focus-visible:ring-offset-2 |\n| Transition   | transition-colors duration-150                                       |\n| Active       | active:bg-zinc-200                                                   |\n\n**Rule:**  \nNo scale, translate, or transform effects.\n\n---\n\n## Rules\n\n### \u2705 Do\n\n- Use generous white space as a design element  \n- Use zinc scale exclusively for neutrals  \n- Separate sections with space, not dividers  \n- Use line-style icons (stroke, not fill)  \n- Keep a single level of visual hierarchy per component  \n- Prefer border over shadows for surface separation  \n\n### \u274C Never\n\n- Decorative shadows (`shadow-*`)  \n- Gradients (`bg-gradient-*`)  \n- Vibrant or saturated colors  \n- Large border radius (`rounded-lg` or above)  \n- `font-bold` or `font-semibold`  \n- Filled or colorful icons  \n- Animations beyond `transition-colors`  \n- More than 2 font sizes in a single component  \n\n---\n\n## Iconography\n\n- **Style:** outline / stroke  \n- **Stroke width:** 1 or 1.5 (never 2+)  \n- **Size:** size-4 or size-5  \n- **Color:** inherits from text (`currentColor`)  \n\n---\n\n## Tone\n\nCold. Precise. Confident through restraint.  \nThe absence of decoration is the statement.\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime" {
    export const skill = "\n# Skill Group Contract: `enter + datetime`\n\n> Official contract for molecules in the **enter + datetime** group in the Collab Aura system.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + datetime` |\n| **Category** | Data Entry |\n| **Intent** | User wants to provide a **date and/or time** |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. When to Use\n\n- Date selection\n- Time scheduling\n- Deadline definition\n- Date ranges and periods\n- Appointments and bookings\n- Birth dates, expiration dates\n\n---\n\n## 3. When NOT to Use\n\n| Scenario | Use instead |\n|----------|-------------|\n| Generic number | `enter + number` |\n| Duration or elapsed time | `enter + number` with formatting |\n| Free-form text | `enter + text` |\n\n---\n\n## 4. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Prefix` | No | Content before input (calendar icon) |\n| `Suffix` | No | Content after input (clear button, actions) |\n| `Helper` | No | Help text displayed below the field |\n| `Error` | No | Error message (displayed when `error=true`) |\n\n### HTML Structure\n\n```html\n<molecules--date-picker-102020 value=\"2026-04-14\" min=\"2026-01-01\" required>\n  <Label>Event Date</Label>\n  <Prefix><Icon name=\"calendar\" /></Prefix>\n  <Helper>Select a date in 2026</Helper>\n  <e>Invalid date</e>\n</molecules--date-picker-102020>\n```\n\n---\n\n## 5. Properties\n\n### 5.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Current value (ISO format) |\n| `name` | `string` | `''` | `@property` | Field name (for forms) |\n\n#### Value Formats (ISO 8601)\n\n| Mode | Format | Example |\n|------|--------|---------|\n| Date | `YYYY-MM-DD` | `2026-04-14` |\n| Time | `HH:mm` or `HH:mm:ss` | `14:30` or `14:30:00` |\n| DateTime | `YYYY-MM-DDTHH:mm` | `2026-04-14T14:30` |\n| Date Range | `YYYY-MM-DD/YYYY-MM-DD` | `2026-04-14/2026-04-20` |\n| Month | `YYYY-MM` | `2026-04` |\n| Year | `YYYY` | `2026` |\n\n### 5.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `mode` | `string` | `'date'` | `@property` | Selection mode |\n| `min` | `string` | `undefined` | `@property` | Minimum allowed value (ISO) |\n| `max` | `string` | `undefined` | `@property` | Maximum allowed value (ISO) |\n| `placeholder` | `string` | `''` | `@property` | Placeholder text |\n| `format` | `string` | `undefined` | `@property` | Display format (locale-aware) |\n| `locale` | `string` | `undefined` | `@property` | Locale for formatting |\n| `firstDayOfWeek` | `number` | `0` | `@property` | First day of week (0=Sunday, 1=Monday) |\n\n#### Valid values for `mode`\n\n| Value | Description |\n|-------|-------------|\n| `date` | Single date selection |\n| `time` | Time only selection |\n| `datetime` | Date and time selection |\n| `daterange` | Date range (start and end) |\n| `month` | Month and year selection |\n| `year` | Year only selection |\n\n### 5.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@property` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@property` | Field is read-only |\n| `required` | `boolean` | `false` | `@property` | Field is required |\n| `loading` | `boolean` | `false` | `@property` | Loading state |\n| `error` | `boolean` | `false` | `@property` | Error state  |\n| `open` | `boolean` | `false` | `@property` | Picker is open |\n\n---\n\n## 6. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Value changed (after selection or blur) |\n| `input` | `{ value: string | null }` | \u2713 | Value changed (on each interaction) |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n| `open` | `{}` | \u2713 | Picker opened |\n| `close` | `{}` | \u2713 | Picker closed |\n\n### Event Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance, calendar icon |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing allowed, value visible |\n| **Error** | Error visual indicator |\n| **Loading** | Loading indicator visible |\n| **Open** | Picker dropdown visible |\n\n---\n\n## 8. Rendering Logic\n\n```\nRENDER:\n\n1. Main container\n   - Apply state styles (disabled, error, etc.)\n\n2. IF hasSlot('Label'):\n   - Render label above input\n   - IF required: add visual indicator (*)\n\n3. Input wrapper (trigger):\n   a. IF hasSlot('Prefix'):\n      - Render Prefix content on the left\n   ELSE:\n      - Render default calendar icon\n   \n   b. Display element:\n      - Show formatted value or placeholder\n      - Click opens picker\n   \n   c. IF loading:\n      - Render loading indicator\n   ELSE IF hasSlot('Suffix'):\n      - Render Suffix content on the right\n\n4. Picker dropdown (when open):\n   - Calendar grid for date modes\n   - Time selectors for time modes\n   - Navigation controls (prev/next month/year)\n\n5. Below input:\n   IF error AND hasSlot('Error'):\n      - Render error message\n   ELSE IF hasSlot('Helper'):\n      - Render help text\n```\n\n---\n\n## 9. Picker Behavior\n\n### Calendar Navigation\n\n| Action | Behavior |\n|--------|----------|\n| Previous month | Navigate to previous month |\n| Next month | Navigate to next month |\n| Month click | Open month selector |\n| Year click | Open year selector |\n| Today | Jump to current date |\n\n### Date Selection\n\n| Mode | Selection Behavior |\n|------|-------------------|\n| `date` | Single click selects and closes |\n| `time` | Hour/minute selection |\n| `datetime` | Date first, then time |\n| `daterange` | First click = start, second = end |\n| `month` | Month grid selection |\n| `year` | Year grid selection |\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| `ArrowLeft` | Previous day |\n| `ArrowRight` | Next day |\n| `ArrowUp` | Previous week |\n| `ArrowDown` | Next week |\n| `Enter` | Select focused date |\n| `Escape` | Close picker |\n| `Tab` | Move focus within picker |\n\n---\n\n## 10. Validation\n\n| Rule | Condition | Behavior |\n|------|-----------|----------|\n| Min | `value < min` | Date disabled in picker, show error |\n| Max | `value > max` | Date disabled in picker, show error |\n| Required | `value === null && required` | Show error |\n| Invalid | Value doesn't match mode format | Show error |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` or `<label for>` |\n| Error announced | `aria-describedby` pointing to error |\n| Invalid state | `aria-invalid=\"true\"` when error |\n| Required field | `aria-required=\"true\"` |\n| Expanded state | `aria-expanded` on trigger |\n| Popup role | `role=\"dialog\"` on picker |\n| Grid role | `role=\"grid\"` on calendar |\n| Cell role | `role=\"gridcell\"` on dates |\n\n### ID Structure\n\n```html\n<label id=\"date-label-{uid}\">...</label>\n<button \n  aria-labelledby=\"date-label-{uid}\"\n  aria-describedby=\"date-helper-{uid} date-error-{uid}\"\n  aria-expanded=\"false\"\n  aria-haspopup=\"dialog\"\n/>\n<div role=\"dialog\" aria-label=\"Choose date\">\n  <div role=\"grid\" aria-label=\"April 2026\">...</div>\n</div>\n<div id=\"date-helper-{uid}\">...</div>\n<div id=\"date-error-{uid}\">...</div>\n```\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-14 | Initial contract version |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber" {
    export const skill = "\n# Skill Group Contract: `enter + number`\n\n> Official contract for molecules in the **enter + number** group in the Collab Aura system.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + number` |\n| **Category** | Data Entry |\n| **Intent** | User wants to provide a **numeric value** |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. When to Use\n\n- Quantity input\n- Monetary values\n- Measurements and dimensions\n- Numeric configurations\n- Percentages\n- Ages, weights, heights\n\n---\n\n## 3. When NOT to Use\n\n| Scenario | Use instead |\n|----------|-------------|\n| Free-form text | `enter + text` |\n| Date/time | `enter + datetime` |\n| Rating/scoring | `rate + item` |\n| Phone numbers (formatted) | `enter + text` with mask |\n\n---\n\n## 4. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Prefix` | No | Content before input (currency symbol, icons) |\n| `Suffix` | No | Content after input (unit, buttons) |\n| `Helper` | No | Help text displayed below the field |\n| `Error` | No | Error message  |\n\n### HTML Structure\n\n```html\n<molecules--number-input-102020 value=\"1500.00\" min=\"0\" step=\"0.01\" required>\n  <Label>Price</Label>\n  <Prefix>$</Prefix>\n  <Suffix>USD</Suffix>\n  <Helper>Minimum value is $10.00</Helper>\n  <Error>Invalid value</Error>\n</molecules--number-input-102020>\n```\n\n---\n\n## 5. Properties\n\n### 5.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Current numeric value |\n| `name` | `string` | `''` | `@property` | Field name (for forms) |\n\n### 5.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `min` | `number` | `undefined` | `@property` | Minimum allowed value |\n| `max` | `number` | `undefined` | `@property` | Maximum allowed value |\n| `step` | `number` | `1` | `@property` | Increment/decrement step |\n| `precision` | `number` | `undefined` | `@property` | Decimal places (auto-format) |\n| `placeholder` | `string` | `''` | `@property` | Placeholder text |\n| `inputmode` | `string` | `'decimal'` | `@property` | Virtual keyboard mode |\n\n#### Valid values for `inputmode`\n\n| Value | Description |\n|-------|-------------|\n| `numeric` | Numeric keyboard (integers) |\n| `decimal` | Numeric keyboard with decimal separator |\n\n### 5.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@property` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@property` | Field is read-only |\n| `required` | `boolean` | `false` | `@property` | Field is required |\n| `loading` | `boolean` | `false` | `@property` | Loading state |\n\n---\n\n## 6. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Value changed (after blur, enter, or stepper) |\n| `input` | `{ value: number | null }` | \u2713 | Value changed (on each keystroke) |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n| `enter` | `{ value: number | null }` | \u2713 | User pressed Enter |\n| `step` | `{ value: number | null, direction: 'up' | 'down' }` | \u2713 | Stepper button clicked |\n\n### Event Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance, text cursor |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing allowed, text selectable |\n| **Error** | Error visual indicator |\n| **Loading** | Loading indicator visible |\n\n---\n\n## 8. Rendering Logic\n\n```\nRENDER:\n\n1. Main container\n   - Apply state styles (disabled, etc.)\n\n2. IF hasSlot('Label'):\n   - Render label above input\n   - IF required: add visual indicator (*)\n\n3. Input wrapper:\n   a. IF hasSlot('Prefix'):\n      - Render Prefix content on the left\n   \n   b. Input element:\n      - type=\"text\" with numeric filtering\n      - value, placeholder, min, max, step\n      - Events: input, change, blur, focus, keydown\n   \n   c. IF loading:\n      - Render loading indicator\n   ELSE IF hasSlot('Suffix'):\n      - Render Suffix content on the right\n\n4. Below input:\n   IF error AND (error is string OR hasSlot('Error')):\n      - Render error message\n   ELSE IF hasSlot('Helper'):\n      - Render help text\n```\n\n---\n\n## 9. Value Handling\n\n### Input Filtering\n\n- Allow only: digits, decimal separator, minus sign (if min < 0)\n- Prevent multiple decimal separators\n- Prevent minus sign except at start\n\n### Value Parsing\n\n- Parse input string to number on blur/change\n- Return `null` for empty or invalid input\n- Apply precision formatting if defined\n\n### Validation\n\n| Rule | Condition | Behavior |\n|------|-----------|----------|\n| Min | `value < min` | Show error, clamp on blur (optional) |\n| Max | `value > max` | Show error, clamp on blur (optional) |\n| Required | `value === null && required` | Show error |\n\n---\n\n## 10. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` or `<label for>` |\n| Error announced | `aria-describedby` pointing to error |\n| Invalid state | `aria-invalid=\"true\"` when error |\n| Required field | `aria-required=\"true\"` |\n| Value bounds | `aria-valuemin`, `aria-valuemax` |\n| Current value | `aria-valuenow` |\n| Helper text | `aria-describedby` including helper |\n\n### ID Structure\n\n```html\n<label id=\"number-label-{uid}\">...</label>\n<input \n  type=\"text\"\n  inputmode=\"decimal\"\n  aria-labelledby=\"number-label-{uid}\"\n  aria-describedby=\"number-helper-{uid} number-error-{uid}\"\n  aria-invalid=\"true\"\n  aria-required=\"true\"\n  aria-valuemin=\"0\"\n  aria-valuemax=\"100\"\n  aria-valuenow=\"50\"\n/>\n<div id=\"number-helper-{uid}\">...</div>\n<div id=\"number-error-{uid}\">...</div>\n```\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-14 | Initial contract version |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterText.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterText" {
    export const skill = "\n# Skill Group Contract: `enter + text`\n\n> Official contract for molecules in the **enter + text** group in the Collab Aura system.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + text` |\n| **Category** | Data Entry |\n| **Intent** | User wants to provide **free-form text** |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. When to Use\n\n- Arbitrary text input\n- Names, descriptions, comments\n- Any textual data\n- Emails, passwords, phone numbers\n- Short text (single-line) or long text (multi-line)\n\n---\n\n## 3. When NOT to Use\n\n| Scenario | Use instead |\n|----------|-------------|\n| Selection from predefined options | `select + one` or `select + many` |\n| Numbers only | `enter + number` |\n| Date/time | `enter + datetime` |\n| Rating/scoring | `rate + item` |\n\n---\n\n## 4. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Prefix` | No | Content before input (icons, fixed text) |\n| `Suffix` | No | Content after input (buttons, icons, actions) |\n| `Helper` | No | Help text displayed below the field |\n| `Error` | No | Error message \n\n### HTML Structure\n\n```html\n<molecules--input-102020 value=\"john@email.com\" type=\"email\" required>\n  <Label>Email</Label>\n  <Prefix><Icon name=\"mail\" /></Prefix>\n  <Suffix><Button size=\"sm\">Verify</Button></Suffix>\n  <Helper>We'll use this to send notifications</Helper>\n  <Error>Invalid email</Error>\n</molecules--input-102020>\n```\n\n---\n\n## 5. Properties\n\n### 5.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string` | `''` | `@propertyDataSource` | Current field value |\n| `name` | `string` | `''` | `@property` | Field name (for forms) |\n\n### 5.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `type` | `string` | `'text'` | `@property` | Input type |\n| `placeholder` | `string` | `''` | `@property` | Placeholder text |\n| `maxlength` | `number` | `undefined` | `@property` | Maximum character count |\n| `minlength` | `number` | `undefined` | `@property` | Minimum character count |\n| `pattern` | `string` | `undefined` | `@property` | Regex for validation |\n| `autocomplete` | `string` | `undefined` | `@property` | HTML autocomplete value |\n| `inputmode` | `string` | `undefined` | `@property` | Virtual keyboard mode |\n\n#### Valid values for `type`\n\n| Value | Description |\n|-------|-------------|\n| `text` | Standard text |\n| `email` | Email with validation |\n| `password` | Password (hidden characters) |\n| `tel` | Phone number |\n| `url` | URL |\n| `search` | Search field |\n\n#### Valid values for `inputmode`\n\n| Value | Description |\n|-------|-------------|\n| `text` | Standard text keyboard |\n| `email` | Email-optimized keyboard |\n| `tel` | Numeric keyboard for phone |\n| `url` | URL-optimized keyboard |\n| `numeric` | Numeric keyboard |\n| `decimal` | Numeric keyboard with decimal |\n| `search` | Keyboard with search button |\n\n### 5.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@property` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@property` | Field is read-only |\n| `required` | `boolean` | `false` | `@property` | Field is required |\n| `loading` | `boolean` | `false` | `@property` | Loading state |\n\n---\n\n## 6. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string }` | \u2713 | Value changed (after blur or enter) |\n| `input` | `{ value: string }` | \u2713 | Value changed (on each keystroke) |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n| `enter` | `{ value: string }` | \u2713 | User pressed Enter |\n\n### Event Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance, text cursor |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing allowed, text selectable |\n| **Error** | Error visual indicator |\n| **Loading** | Loading indicator visible |\n\n---\n\n## 8. Rendering Logic\n\n```\nRENDER:\n\n1. Main container\n   - Apply state styles (disabled, error, etc.)\n\n2. IF hasSlot('Label'):\n   - Render label above input\n   - IF required: add visual indicator (*)\n\n3. Input wrapper:\n   a. IF hasSlot('Prefix'):\n      - Render Prefix content on the left\n   \n   b. Input element:\n      - type, value, placeholder, maxlength, etc.\n      - Events: input, change, blur, focus, keydown\n   \n   c. IF loading:\n      - Render loading indicator\n   ELSE IF hasSlot('Suffix'):\n      - Render Suffix content on the right\n\n4. Below input:\n   IF error AND (error is string OR hasSlot('Error')):\n      - Render error message\n   ELSE IF hasSlot('Helper'):\n      - Render help text\n```\n\n---\n\n## 9. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` or `<label for>` |\n| Error announced | `aria-describedby` pointing to error |\n| Invalid state | `aria-invalid=\"true\"` when error |\n| Required field | `aria-required=\"true\"` |\n| Helper text | `aria-describedby` including helper |\n| Disabled | `aria-disabled=\"true\"` + `disabled` attr |\n| Readonly | `aria-readonly=\"true\"` + `readonly` attr |\n\n### ID Structure\n\n```html\n<label id=\"input-label-{uid}\">...</label>\n<input \n  aria-labelledby=\"input-label-{uid}\"\n  aria-describedby=\"input-helper-{uid} input-error-{uid}\"\n  aria-invalid=\"true\"\n  aria-required=\"true\"\n/>\n<div id=\"input-helper-{uid}\">...</div>\n<div id=\"input-error-{uid}\">...</div>\n```\n\n---\n\n## 10. Type Variations\n\n| Type | Mobile Keyboard | Validation | Special Behavior |\n|------|-----------------|------------|------------------|\n| `text` | Standard | None | - |\n| `email` | Email (with @) | Email format | Email autocomplete |\n| `password` | Standard | None | Hidden characters, visibility toggle |\n| `tel` | Numeric | Phone format | Optional mask |\n| `url` | URL (with .com) | URL format | URL autocomplete |\n| `search` | With search | None | Clear button, search icon |\n\n---\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-14 | Initial contract version |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupNotifyUser.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupNotifyUser" {
    export const skill = "\n# Skill Group Contract: `notify + user`\n\n> Official contract for molecules in the **notify + user** group in the Collab Aura system.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `notify + user` |\n| **Category** | Feedback |\n| **Intent** | System wants to **inform the user** about an event, status, or result |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. When to Use\n\n- Action feedback (success, error, warning)\n- System alerts and messages\n- Event notifications\n- Important announcements\n- Status updates\n- Connection state changes\n\n---\n\n## 3. When NOT to Use\n\n| Scenario | Use instead |\n|----------|-------------|\n| Requires user decision | `focus + overlay` (Dialog, Alert Dialog) |\n| Persistent item status | `show + status` (Badge, Tag) |\n| Loading/progress indication | `show + progress` |\n| Empty state messaging | `show + empty` |\n\n---\n\n## 4. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Title` | No | Notification title (short, bold) |\n| `Description` | No | Additional details or message body |\n| `Icon` | No | Custom icon (overrides type default) |\n| `Action` | No | Action button (e.g., Undo, View, Retry) |\n| `Close` | No | Custom close button content |\n\n### HTML Structure\n\n```html\n<molecules--toast-102020 type=\"success\" duration=\"5000\">\n  <Title>Changes saved</Title>\n  <Description>Your profile has been updated successfully.</Description>\n  <Action>View profile</Action>\n</molecules--toast-102020>\n```\n\n---\n\n## 5. Properties\n\n### 5.1 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `type` | `string` | `'info'` | `@property` | Notification type/severity |\n| `duration` | `number` | `5000` | `@property` | Auto-dismiss time in ms (0 = persistent) |\n| `position` | `string` | `'bottom-right'` | `@property` | Screen position |\n| `dismissible` | `boolean` | `true` | `@property` | Show close button |\n\n#### Valid values for `type`\n\n| Value | Description | Default Icon |\n|-------|-------------|--------------|\n| `info` | Informational message | Info circle |\n| `success` | Positive/success feedback | Check circle |\n| `warning` | Warning/caution message | Warning triangle |\n| `error` | Error/failure message | X circle |\n\n#### Valid values for `position`\n\n| Value | Description |\n|-------|-------------|\n| `top-left` | Top left corner |\n| `top-center` | Top center |\n| `top-right` | Top right corner |\n| `bottom-left` | Bottom left corner |\n| `bottom-center` | Bottom center |\n| `bottom-right` | Bottom right corner |\n\n### 5.2 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `visible` | `boolean` | `true` | `@property` | Notification visibility |\n| `paused` | `boolean` | `false` | `@property` | Pause auto-dismiss timer |\n\n---\n\n## 6. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `show` | `{}` | \u2713 | Notification became visible |\n| `hide` | `{ reason: string }` | \u2713 | Notification was hidden |\n| `action` | `{}` | \u2713 | Action button clicked |\n| `close` | `{}` | \u2713 | Close button clicked |\n\n### Hide Reasons\n\n| Reason | Description |\n|--------|-------------|\n| `timeout` | Auto-dismissed after duration |\n| `close` | User clicked close button |\n| `action` | User clicked action button |\n| `programmatic` | Hidden via property/method |\n\n### Event Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('hide', {\n  bubbles: true,\n  composed: true,\n  detail: { reason: 'timeout' }\n}));\n```\n\n---\n\n## 7. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Entering** | Slide/fade in animation |\n| **Visible** | Fully visible, timer running |\n| **Paused** | Timer paused (on hover) |\n| **Exiting** | Slide/fade out animation |\n| **Hidden** | Not rendered |\n\n---\n\n## 8. Rendering Logic\n\n```\nRENDER:\n\n1. IF NOT visible:\n   - Return nothing\n\n2. Container (positioned):\n   - Apply type styles (background, border, icon color)\n   - Apply position styles\n   - Apply animation state\n\n3. Content wrapper:\n   a. Icon area:\n      IF hasSlot('Icon'):\n         - Render custom icon\n      ELSE:\n         - Render default icon based on type\n   \n   b. Text area:\n      IF hasSlot('Title'):\n         - Render title (bold, larger)\n      IF hasSlot('Description'):\n         - Render description (normal, smaller)\n   \n   c. Actions area:\n      IF hasSlot('Action'):\n         - Render action button\n      IF dismissible:\n         - Render close button\n\n4. Progress bar (optional):\n   - Show remaining time visually\n```\n\n---\n\n## 9. Timer Behavior\n\n### Auto-Dismiss\n\n| Condition | Behavior |\n|-----------|----------|\n| `duration > 0` | Start countdown timer |\n| `duration === 0` | Persistent until manually closed |\n| Mouse enter | Pause timer |\n| Mouse leave | Resume timer |\n| Action click | Dismiss immediately |\n| Close click | Dismiss immediately |\n\n### Stacking\n\n| Rule | Behavior |\n|------|----------|\n| Multiple notifications | Stack vertically with gap |\n| Same position | Newest on top or bottom based on position |\n| Max visible | Limit visible count, queue others |\n\n---\n\n## 10. Type Styling\n\n| Type | Background | Border | Icon Color | Text Color |\n|------|------------|--------|------------|------------|\n| `info` | Light blue | Blue | Blue | Dark |\n| `success` | Light green | Green | Green | Dark |\n| `warning` | Light yellow | Yellow/Orange | Orange | Dark |\n| `error` | Light red | Red | Red | Dark |\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Role | `role=\"alert\"` or `role=\"status\"` |\n| Live region | `aria-live=\"polite\"` (info) or `aria-live=\"assertive\"` (error) |\n| Atomic | `aria-atomic=\"true\"` |\n| Close button | `aria-label=\"Close notification\"` |\n| Action button | Descriptive label |\n| Focus management | Don't steal focus from user |\n\n### Role Selection\n\n| Type | Role | Aria-Live |\n|------|------|-----------|\n| `info` | `status` | `polite` |\n| `success` | `status` | `polite` |\n| `warning` | `alert` | `polite` |\n| `error` | `alert` | `assertive` |\n\n### Structure\n\n```html\n<div \n  role=\"status\"\n  aria-live=\"polite\"\n  aria-atomic=\"true\"\n>\n  <div class=\"icon\">...</div>\n  <div class=\"content\">\n    <div class=\"title\">...</div>\n    <div class=\"description\">...</div>\n  </div>\n  <button aria-label=\"Close notification\">\u00D7</button>\n</div>\n```\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-14 | Initial contract version |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectOne" {
    export const skill = "\n\n# Skill: select + one\n\n## Metadata\n\n- **Name:** selectOne\n- **Version:** 1.0.0\n- **Category:** Data Entry\n- **Last Updated:** 04/01/2026\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to choose **exactly one option** from several available.\n\n### When to Use\n\n- User must make an exclusive choice\n- Only one answer is valid at a time\n- Options are mutually exclusive\n\n### When NOT to Use\n\n- User can select multiple options \u2192 use **select + many**\n- There is only one option (on/off) \u2192 use **toggle + state**\n- Input is free/textual \u2192 use **enter + text**\n\n### Possible Implementations\n\n- Select (Dropdown)\n- Radio Group\n- Segmented Control\n- Native Select\n- Toggle Group (exclusive)\n- Combobox\n- List Picker\n- Selectable Cards\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| 'value' | 'string | number | null' | 'null' | \u2713 | '@propertyDataSource' | Value of the selected option |\n| 'disabled' | 'boolean' | 'false' | | '@property' | Disables the entire component |\n| 'readonly' | 'boolean' | 'false' | | '@property' | Displays value but prevents changes |\n| 'loading' | 'boolean' | 'false' | | '@property' | Indicates asynchronous loading |\n| 'error' | 'boolean | string' | 'false' | | '@property' | Error state or message |\n| 'required' | 'boolean' | 'false' | | '@property' | Indicates mandatory selection |\n| 'name' | 'string' | '''' | | '@property' | Field name for forms |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| '@propertyDataSource' | Binds to a single dynamic state | '{{page1.selectedId}}' |\n| '@propertyCompositeDataSource' | Binds to multiple composed states | 'Select a {{page1.itemType}}' |\n| '@property' | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| 'change' | '{ value: string | number, option: Object }' | Fired when selection changes |\n| 'blur' | \u2014 | Fired when component loses focus |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| '<Trigger>' | | Element that opens/activates the selection |\n| '<Value>' | | Displays the selected value |\n| '<Content>' | \u2713 | Container for options |\n| '<Group>' | | Groups options with a label |\n| '<Item>' | \u2713 (min. 1) | A selectable option |\n| '<Empty>' | | Displayed when no options available |\n\n---\n\n### '<Trigger>'\n\nElement that opens/activates the selection.\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| 'placeholder' | 'string' | | Text when nothing selected |\n\n**Accepts:** Any content (text, icons, '<Value>')\n\n'''html\n<Trigger placeholder=\"Select...\">\n  <Icon name=\"chevron-down\" />\n  <Value />\n</Trigger>\n'''\n\n---\n\n### '<Value>'\n\nDisplays the selected value. Usually used inside '<Trigger>'.\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| 'placeholder' | 'string' | | Text when nothing selected |\n\n**Accepts:** None (self-closing)\n\n'''html\n<Value placeholder=\"None selected\" />\n'''\n\n---\n\n### '<Content>'\n\nContainer for options. **Required.**\n\n**Accepts:** '<Group>', '<Item>', '<Empty>'\n\n'''html\n<Content>\n  <Item value=\"a\">Option A</Item>\n  <Item value=\"b\">Option B</Item>\n</Content>\n'''\n\n---\n\n### '<Group>'\n\nGroups options with a label.\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| 'label' | 'string' | \u2713 | Group title |\n\n**Accepts:** '<Item>'\n\n'''html\n<Group label=\"Fruits\">\n  <Item value=\"apple\">Apple</Item>\n  <Item value=\"banana\">Banana</Item>\n</Group>\n'''\n\n---\n\n### '<Item>'\n\nA selectable option. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| 'value' | 'string | number' | \u2713 | Unique option value |\n| 'disabled' | 'boolean' | | Disables this option |\n\n**Accepts:** Any content (text, icons, images, badges)\n\n'''html\n<Item value=\"user-1\">\n  <Avatar src=\"photo.jpg\" />\n  <span>John Doe</span>\n  <Badge>Admin</Badge>\n</Item>\n\n<Item value=\"user-2\" disabled>\n  <Avatar src=\"photo2.jpg\" />\n  <span>Jane (inactive)</span>\n</Item>\n'''\n\n---\n\n### '<Empty>'\n\nDisplayed when no options available or search has no results.\n\n**Accepts:** Any content\n\n'''html\n<Empty>\n  <Icon name=\"search-x\" />\n  <span>No results found</span>\n</Empty>\n'''\n\n---\n\n## Slot Hierarchy\n\n'''\ncomponent (root)\n\u251C\u2500\u2500 <Trigger>\n\u2502   \u2514\u2500\u2500 <Value>\n\u2514\u2500\u2500 <Content>\n    \u251C\u2500\u2500 <Group>\n    \u2502   \u2514\u2500\u2500 <Item>\n    \u251C\u2500\u2500 <Item>\n    \u2514\u2500\u2500 <Empty>\n'''\n\n| Tag | Valid Parents |\n|-----|---------------|\n| '<Trigger>' | root |\n| '<Value>' | '<Trigger>' |\n| '<Content>' | root |\n| '<Group>' | '<Content>' |\n| '<Item>' | '<Content>', '<Group>' |\n| '<Empty>' | '<Content>' |\n\n---\n\n## Validation Rules\n\n### Slot Validation\n\n| Rule | Type | Message |\n|------|------|---------|\n| '<Content>' missing | error | 'Missing required slot <Content>' |\n| No '<Item>' present | error | 'At least 1 <Item> is required inside <Content>' |\n| '<Item>' without 'value' | error | '<Item> requires attribute \"value\"' |\n| '<Group>' without 'label' | error | '<Group> requires attribute \"label\"' |\n| Unknown tag found | warning | 'Unknown slot <TagName> ignored' |\n| Tag in invalid position | warning | '<TagName> is not valid inside <ParentTag>, ignored' |\n\n### Data Validation\n\n| Rule | Condition | Suggested Message |\n|------|-----------|-------------------|\n| required | 'required === true && value === null' | \"Please select an option\" |\n| invalidOption | 'value' not found in '<Item>' values | \"Invalid option\" |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Initial/neutral state | Interactive, awaiting action |\n| **hover** | Cursor over the component | Visual feedback of interactivity |\n| **focus** | Component has focus | Visual focus indicator (outline) |\n| **disabled** | Component is disabled | Non-interactive, visually dimmed |\n| **readonly** | Read-only mode | Displays value, prevents changes |\n| **loading** | Loading options | Displays loading indicator |\n| **error** | Error state | Visual error feedback (color, icon) |\n\n### Item States\n\n| State | Description |\n|-------|-------------|\n| **default** | Option available for selection |\n| **selected** | Currently selected option |\n| **disabled** | Option cannot be selected |\n| **hover** | Cursor over the option |\n| **focus** | Option has focus (keyboard navigation) |\n\n---\n\n## Accessibility (Recommended)\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| 'Tab' | Moves focus to/from the component |\n| 'Arrow Up/Down' | Navigates between options |\n| 'Arrow Left/Right' | Navigates between options (horizontal variants) |\n| 'Enter' / 'Space' | Selects focused option |\n| 'Escape' | Closes dropdown (if applicable) |\n| 'Home' | Moves to first option |\n| 'End' | Moves to last option |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| 'role=\"listbox\"' | Options container |\n| 'role=\"option\"' | Each individual option |\n| 'aria-selected' | Indicates selected option |\n| 'aria-disabled' | Indicates disabled option/component |\n| 'aria-required' | Indicates required field |\n| 'aria-invalid' | Indicates error state |\n| 'aria-expanded' | Indicates if dropdown is open |\n\n---\n\n## Interchangeability\n\nAll components implementing 'select + one' accept the same slot tag structure. To switch the visual implementation, simply change the parent component tag:\n\nEach implementation decides internally:\n- Which tags it uses\n- Which tags it ignores\n- How it renders each tag\n\nThe contract ensures **structural compatibility** across all implementations in the group.\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 04/01/2026 | Initial contract with slot tags definition |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewData.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupViewData" {
    export const skill = "\n# Skill: view + data\n\n## Metadata\n\n- **Name:** viewData\n- **Version:** 1.1.0\n- **Category:** Data Display\n- **Last Updated:** 13/04/2026\n\n---\n\n## Short Description\n\n> **view + data**: Adaptive visualization of data collection. Display multiple records with defined fields and rich content. The component implementation decides the best presentation format.\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize a collection of data**. The group defines the data structure (columns, rows, cells), and each component implementation decides how to render it.\n\n### When to Use\n\n- Display collection of records\n- Multiple fields per record\n- Rich content in cells (badges, actions, composed layouts)\n- When you need a standardized data structure\n\n### When NOT to Use\n\n- Single metrics \u2192 use **view + metric**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Charts/graphs \u2192 use **view + chart**\n\n### Possible Implementations\n\n- Data Table\n- Card Grid\n- List View\n- Responsive View (adapts to viewport)\n- Compact Table\n- Kanban Board\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `selectable` | `boolean` | `false` | | `@property` | Enables row/item selection |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight on hover |\n\n> **Note:** Additional properties may be added by specific implementations (e.g., `striped`, `bordered` for table implementations).\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, data: Element }` | Fired when a row/item is clicked |\n| `selection-change` | `{ selected: number[] }` | Fired when selection changes |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n**Important:** Use ONLY the tags defined below. Do NOT create custom tags.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<Columns>` | \u2713 | Container for column definitions |\n| `<Column>` | \u2713 (min. 1) | Defines a column/field |\n| `<Rows>` | \u2713 | Container for data rows |\n| `<Row>` | \u2713 (min. 1) | A data row/item |\n| `<Cell>` | \u2713 | A data cell |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n---\n\n### `<Columns>`\n\nContainer for column definitions. **Required.**\n\n**Accepts:** `<Column>`\n\n```html\n<Columns>\n  <Column field=\"id\" header=\"ID\" />\n  <Column field=\"name\" header=\"Name\" />\n</Columns>\n```\n\n---\n\n### `<Column>`\n\nDefines a column/field. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `field` | `string` | \u2713 | Field identifier (for reference) |\n| `header` | `string` | \u2713 | Header/label text |\n| `width` | `string` | | Suggested width (e.g., \"100px\", \"20%\") |\n| `align` | `'left' | 'center' | 'right'` | | Content alignment |\n| `hidden` | `boolean` | | Hides the column |\n\n**Accepts:** None (self-closing)\n\n```html\n<Column field=\"id\" header=\"Order ID\" width=\"120px\" />\n<Column field=\"status\" header=\"Status\" align=\"center\" />\n<Column field=\"internal\" header=\"Internal\" hidden />\n```\n\n---\n\n### `<Rows>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<Row>`\n\n```html\n<Rows>\n  <Row>...</Row>\n  <Row>...</Row>\n</Rows>\n```\n\n---\n\n### `<Row>`\n\nA data row/item. **Required** (minimum 1 for non-empty state).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `selected` | `boolean` | | Marks row as selected |\n| `disabled` | `boolean` | | Disables row interaction |\n\n**Accepts:** `<Cell>`\n\n```html\n<Row>\n  <Cell>Value 1</Cell>\n  <Cell>Value 2</Cell>\n</Row>\n\n<Row selected>\n  <Cell>Selected Row</Cell>\n</Row>\n\n<Row disabled>\n  <Cell>Disabled Row</Cell>\n</Row>\n```\n\n---\n\n### `<Cell>`\n\nA data cell. **Required** (should match number of Columns).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n\n**Accepts:** Any content (text, elements, components)\n\n```html\n<!-- Simple text -->\n<Cell>John Doe</Cell>\n\n<!-- Composed content -->\n<Cell>\n  <div class=\"font-medium\">William Little</div>\n  <div class=\"text-sm text-slate-500\">william@email.com</div>\n</Cell>\n\n<!-- Badge -->\n<Cell>\n  <span class=\"badge badge-success\">Active</span>\n</Cell>\n\n<!-- Actions -->\n<Cell>\n  <div class=\"flex gap-2\">\n    <button>Edit</button>\n    <button>Delete</button>\n  </div>\n</Cell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <div class=\"text-center py-8\">\n    <span class=\"text-4xl\">\uD83D\uDCED</span>\n    <p class=\"mt-2 text-slate-500\">No records found</p>\n  </div>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when `loading` property is true.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <div class=\"text-center py-8\">\n    <Spinner />\n    <p class=\"mt-2\">Loading...</p>\n  </div>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Columns>\n\u2502   \u2514\u2500\u2500 <Column>\n\u251C\u2500\u2500 <Rows>\n\u2502   \u2514\u2500\u2500 <Row>\n\u2502       \u2514\u2500\u2500 <Cell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Columns>` | root |\n| `<Column>` | `<Columns>` |\n| `<Rows>` | root |\n| `<Row>` | `<Rows>` |\n| `<Cell>` | `<Row>` |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<Columns>` missing | error | `Missing required slot <Columns>` |\n| `<Rows>` missing | error | `Missing required slot <Rows>` |\n| No `<Column>` in Columns | error | `At least 1 <Column> is required inside <Columns>` |\n| `<Column>` without `field` | error | `<Column> requires attribute \"field\"` |\n| `<Column>` without `header` | error | `<Column> requires attribute \"header\"` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n\n---\n\n## Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal state |\n| **hover** | Mouse over (if hoverable) |\n| **selected** | Row is selected |\n| **disabled** | Row interaction disabled |\n\n---\n\n## Accessibility (Recommended)\n\n| Attribute | Application |\n|-----------|-------------|\n| `aria-busy` | When loading is true |\n| `aria-selected` | On selected rows |\n| `aria-disabled` | On disabled rows |\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 13/04/2026 | Initial contract definition |\n| 1.1.0 | 13/04/2026 | Removed view-specific properties. Focus on data structure only |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewTable.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupViewTable" {
    export const skill = "\n\n# Skill: view + table\n\n## Metadata\n\n- **Name:** viewTable\n- **Version:** 1.0.0\n- **Category:** Data Display\n- **Last Updated:** 04/02/2026\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize structured data** in tabular format.\n\n### When to Use\n\n- Display list of records\n- Compare data across columns\n- Show structured information\n- CRUD interfaces\n\n### When NOT to Use\n\n- Few items with visual identity \u2192 use **view + cards**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Single metrics \u2192 use **view + metric**\n\n### Possible Implementations\n\n- Data Table (full-featured)\n- Table (simple display)\n- Editable Grid\n- Virtualized Table\n- Tree Table\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `striped` | `boolean` | `false` | | `@property` | Zebra-striped rows |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight row on hover |\n| `bordered` | `boolean` | `false` | | `@property` | Borders on all cells |\n| `compact` | `boolean` | `false` | | `@property` | Reduced padding |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| `@property` | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, row: Element }` | Fired when a row is clicked |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<TableHeader>` | \u2713 | Header section container |\n| `<TableBody>` | \u2713 | Body section container |\n| `<TableRow>` | \u2713 | A table row |\n| `<TableHead>` | \u2713 | Header cell |\n| `<TableCell>` | \u2713 | Data cell |\n| `<TableFooter>` | | Footer section container |\n| `<Caption>` | | Table caption/title |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n\n### `<Caption>`\n\nTable caption or title. Usually displayed above the table.\n\n**Accepts:** Any content (text, elements)\n\n```html\n<Caption>List of Users</Caption>\n```\n\n---\n\n### `<TableHeader>`\n\nContainer for header rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableHeader>\n  <TableRow>\n    <TableHead>Name</TableHead>\n    <TableHead>Email</TableHead>\n  </TableRow>\n</TableHeader>\n```\n\n---\n\n### `<TableBody>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableBody>\n  <TableRow>\n    <TableCell>John Doe</TableCell>\n    <TableCell>john@email.com</TableCell>\n  </TableRow>\n</TableBody>\n```\n\n---\n\n### `<TableFooter>`\n\nContainer for footer rows.\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableFooter>\n  <TableRow>\n    <TableCell colspan=\"2\">Total: 100 records</TableCell>\n  </TableRow>\n</TableFooter>\n```\n\n---\n\n### `<TableRow>`\n\nA table row. **Required** (minimum 1 in header and body).\n\n**Accepts:** `<TableHead>` (inside TableHeader) or `<TableCell>` (inside TableBody/TableFooter)\n\n```html\n<TableRow>\n  <TableCell>Data 1</TableCell>\n  <TableCell>Data 2</TableCell>\n</TableRow>\n```\n\n---\n\n### `<TableHead>`\n\nA header cell. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, icons, sort indicators)\n\n```html\n<TableHead>Name</TableHead>\n<TableHead colspan=\"2\">Contact Info</TableHead>\n```\n\n---\n\n### `<TableCell>`\n\nA data cell. **Required** (minimum 1 per row).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, badges, buttons, etc.)\n\n```html\n<TableCell>John Doe</TableCell>\n<TableCell>\n  <Badge>Active</Badge>\n</TableCell>\n<TableCell>\n  <Button size=\"sm\">Edit</Button>\n</TableCell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows in the table.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <Icon name=\"inbox\" />\n  <span>No records found</span>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when the table is in loading state.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <Spinner />\n  <span>Loading data...</span>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u2502\u2500\u2500 <Caption>\n\u2502\u2500\u2500 <TableHeader>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableHead>\n\u2502\u2500\u2500 <TableBody>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableCell>\n\u2502\u2500\u2500 <TableFooter>\n\u2502       \u2514\u2500\u2500 <TableRow>\n\u2502           \u2514\u2500\u2500 <TableCell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Caption>` | `<Table>` |\n| `<TableHeader>` | `<Table>` |\n| `<TableBody>` | `<Table>` |\n| `<TableFooter>` | `<Table>` |\n| `<TableRow>` | `<TableHeader>`, `<TableBody>`, `<TableFooter>` |\n| `<TableHead>` | `<TableRow>` (inside TableHeader) |\n| `<TableCell>` | `<TableRow>` (inside TableBody or TableFooter) |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n### Slot Validation\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<TableHeader>` missing | error | `Missing required slot <TableHeader>` |\n| `<TableBody>` missing | error | `Missing required slot <TableBody>` |\n| No `<TableRow>` in header | error | `At least 1 <TableRow> is required inside <TableHeader>` |\n| No `<TableHead>` in header row | error | `At least 1 <TableHead> is required inside header <TableRow>` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n| Tag in invalid position | warning | `<TagName> is not valid inside <ParentTag>, ignored` |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Normal display | Shows table with data |\n| **loading** | Loading data | Shows loading indicator, hides body |\n| **empty** | No data | Shows empty state message |\n| **striped** | Zebra rows | Alternating row background colors |\n| **hoverable** | Row hover | Highlight row on mouse over |\n\n### Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal row |\n| **hover** | Mouse over row |\n| **selected** | Row is selected (if selection enabled) |\n\n### Cell States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal cell |\n| **truncated** | Content overflow with ellipsis |\n\n---\n\n## Accessibility (Recommended)\n\n### Semantic Structure\n\n| Element | Renders As |\n|---------|------------|\n| `<Caption>` | `<caption>` |\n| `<TableHeader>` | `<thead>` |\n| `<TableBody>` | `<tbody>` |\n| `<TableFooter>` | `<tfoot>` |\n| `<TableRow>` | `<tr>` |\n| `<TableHead>` | `<th scope=\"col\">` |\n| `<TableCell>` | `<td>` |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| `role=\"table\"` | Applied automatically via semantic HTML |\n| `aria-busy` | When loading is true |\n| `aria-rowcount` | Total number of rows (if known) |\n| `aria-colcount` | Total number of columns |\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| `Tab` | Move between interactive elements in cells |\n| `Arrow Keys` | Navigate between cells (if cell navigation enabled) |\n\n---\n\nEach implementation decides internally:\n- Visual styling (spacing, borders, colors)\n- Additional features (sorting, filtering, pagination)\n- How it renders each slot tag\n\nThe contract ensures **structural compatibility** across all implementations in the group.\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 04/02/2026 | Initial contract definition |\n";
}
declare module "_102020_/l2/skills/molecules/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/index" {
    export const skills: {
        name: string;
        description: string;
        skillReference: string;
    }[];
}
declare module "_102020_/l2/skills/molecules/playgroundGenerator.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/playgroundGenerator" {
    export const skill = "\n# Skill \u2014 Molecule Playground Generator\n> Gera p\u00E1ginas HTML interativas de demonstra\u00E7\u00E3o para Molecules do sistema Collab Aura.\n\n---\n\n## 1. Metadata\n\n| Field       | Value                              |\n|-------------|------------------------------------|\n| **Name**    | `moleculePlaygroundGenerator`    |\n| **Version** | `2.4.0`                          |\n\n---\n\n## 2. Tag Name \u2014 CRITICAL RULE\n\n**The component tag name MUST be copied verbatim from the `@customElement(...)` decorator in the `.ts` file.**\n\n```typescript\n// In the .ts file:\n@customElement('molecules--group-enter-datetime--datetime-popup-picker-102020')\n```\n\n```html\n<!-- In the playground \u2014 use EXACTLY the same string, opening AND closing tag: -->\n<molecules--group-enter-datetime--datetime-popup-picker-102020 ...>\n</molecules--group-enter-datetime--datetime-popup-picker-102020>\n```\n\n### Rules\n\n- **Never derive** the tag name from the file name, class name, or folder path\n- **Never reconstruct** the tag name using the naming convention formula\n- **Always read** the `@customElement(...)` value from the `.ts` source\n- Opening tag and closing tag MUST be **identical strings**\n\n### Why\n\nThe naming convention formula (`kebab-case(folder)--kebab-case(component)-(projectId)`) is used when **creating** a new molecule. When **generating a playground** for an existing molecule, the tag already exists in the `.ts` \u2014 use it directly.\n\n---\n\n## 3. Property Analysis (was \u00A72)\n\n### 2.1 Classifica\u00E7\u00E3o por Decorator\n\n| Decorator | Vai no State? | Binding |\n|-----------|---------------|---------|\n| `@propertyDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@propertyCompositeDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@property` | \u2717 N\u00C3O | Valor direto |\n| `@state` | \u2717 N\u00C3O | N\u00E3o aparece |\n\n---\n\n## 4. State\n\n### 3.1 Formato\n\n```html\n<widget-playground-state-102020 state='{\"playground\":{\"basic\":{\"value\":0,\"error\":\"\"}}}'>\n</widget-playground-state-102020>\n```\n\n### 3.2 Posi\u00E7\u00E3o no HTML\n\nO `widget-playground-state-102020` DEVE vir ANTES de qualquer demo no HTML.\n\n### 3.3 Regras\n\n- JSON v\u00E1lido\n- Uma linha\n- Apenas propriedades @propertyDataSource\n- Sempre usar valores default (nunca null ou undefined)\n\n### 3.4 Valores Default por Tipo\n\n| Tipo | Default |\n|------|---------|\n| string | `\"\"` |\n| number | `0` |\n| boolean | `false` |\n\n---\n\n## 5. Property Editors\n\n### 4.1 Widget por Tipo\n\n| Tipo da Propriedade | Widget |\n|---------------------|--------|\n| string | `widget-playground-state-text-102020` |\n| string \\| null | `widget-playground-state-text-102020` |\n| number | `widget-playground-state-number-102020` |\n| number \\| null | `widget-playground-state-number-102020` |\n| boolean | `widget-playground-state-boolean-102020` |\n\n### 4.2 Exemplos\n\n**String:**\n```html\n<widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n```\n\n**Number:**\n```html\n<widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n```\n\n**Boolean:**\n```html\n<widget-playground-state-boolean-102020 label=\"showIcon\" value=\"{{playground.basic.showIcon}}\"></widget-playground-state-boolean-102020>\n```\n\n---\n\n## 6. Styling (Tailwind)\n\n| Elemento | Classes |\n|----------|---------|\n| Container | `mx-auto p-8 font-sans` |\n| Header | `text-center mb-12` |\n| Title | `text-3xl font-semibold text-slate-800 mb-2` |\n| Badge | `inline-block px-3 py-1 bg-sky-100 text-sky-700 rounded-full text-sm font-medium` |\n| Grid | `grid grid-cols-1 md:grid-cols-2 gap-6 mb-12` |\n| Card | `bg-white border border-slate-200 rounded-xl p-6` |\n| Card Title | `text-lg font-semibold text-slate-800 mb-4` |\n| Details | `mt-4` |\n| Summary | `cursor-pointer text-sm font-medium text-slate-500` |\n| Details Content | `mt-2 p-4 border border-slate-200 rounded-lg` |\n\n---\n\n## 7. HTML Structure\n\n### 6.1 Ordem dos Elementos\n\n1. Container\n2. Header\n3. `widget-playground-state-102020` (SEMPRE antes das demos)\n4. Section com demos\n\n### 6.2 Demo Card\n\n```html\n<div class=\"mx-auto p-8 font-sans\">\n\n  <header class=\"text-center mb-12\">\n    <h1 class=\"text-3xl font-semibold text-slate-800 mb-2\">Component Name</h1>\n    <span class=\"inline-block px-3 py-1 bg-sky-100 text-sky-700 rounded-full text-sm font-medium\">skill group</span>\n  </header>\n\n  <widget-playground-state-102020 state='{\"playground\":{\"basic\":{\"value\":0,\"error\":\"\"}}}'>\n  </widget-playground-state-102020>\n\n  <section class=\"grid grid-cols-1 md:grid-cols-2 gap-6 mb-12\">\n    <article class=\"bg-white border border-slate-200 rounded-xl p-6\">\n      <h3 class=\"text-lg font-semibold text-slate-800 mb-4\">Basic</h3>\n      <demo id=\"demo-basic\">\n        <molecules--component-102020 \n          value=\"{{playground.basic.value}}\"\n          error=\"{{playground.basic.error}}\"\n          disabled=\"false\"\n          isEditing=\"true\">\n          <Label>Field</Label>\n        </molecules--component-102020>\n      </demo>\n      <details class=\"mt-4\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500\">Properties</summary>\n        <div class=\"mt-2 p-4 border border-slate-200 rounded-lg\">\n          <widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n          <widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n        </div>\n      </details>\n      <details class=\"mt-2\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500\">HTML</summary>\n        <div class=\"mt-2\">\n          <widget-playground-state-preview-code-102020 target=\"demo-basic\">\n            <template>\n<molecules--component-102020 \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\"\n  disabled=\"false\"\n  isEditing=\"true\">\n  <Label>Field</Label>\n</molecules--component-102020>\n            </template>\n          </widget-playground-state-preview-code-102020>\n        </div>\n      </details>\n    </article>\n  </section>\n\n</div>\n```\n\n### 6.3 Demo Element\n\nO elemento `<demo>` DEVE:\n- Ter um `id` \u00FAnico (ex: demo-basic, demo-disabled)\n- Conter o HTML do componente (funciona independente do editor)\n\n```html\n<demo id=\"demo-basic\">\n  <molecules--component-102020 \n    value=\"{{playground.basic.value}}\"\n    error=\"{{playground.basic.error}}\">\n    <Label>Field</Label>\n  </molecules--component-102020>\n</demo>\n```\n\n### 6.4 HTML Editor Widget\n\nO `widget-playground-state-preview-code-102020` recebe:\n- `target`: id do elemento demo (para atualizar ao editar)\n- `<template>`: c\u00F3digo HTML fonte (para exibir formatado no editor)\n\n**IMPORTANTE:** O HTML deve estar duplicado - no `<demo>` E no `<template>`.\n\n```html\n<widget-playground-state-preview-code-102020 target=\"demo-basic\">\n  <template>\n<molecules--component-102020 \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\">\n  <Label>Field</Label>\n</molecules--component-102020>\n  </template>\n</widget-playground-state-preview-code-102020>\n```\n\nO widget:\n1. L\u00EA o HTML do `<template>` (c\u00F3digo fonte, n\u00E3o compilado)\n2. Exibe formatado no editor com syntax highlighting\n3. Ao editar, atualiza o innerHTML do `<demo>` target em tempo real\n\n---\n\n## 8. Demos\n\n| Demo | Namespace | @property |\n|------|-----------|-----------|\n| Basic | playground.basic | defaults |\n| Disabled | playground.disabled | disabled=\"true\" |\n| Loading | playground.loading | loading=\"true\" |\n| Error | playground.error | defaults |\n| View Mode | playground.viewMode | isEditing=\"false\" |\n\n---\n\n## 9. Checklist\n\n- [ ] Tag name copied verbatim from `@customElement(...)` in the `.ts` file\n- [ ] Opening tag and closing tag are identical strings\n- [ ] State cont\u00E9m APENAS @propertyDataSource\n- [ ] State \u00E9 JSON v\u00E1lido\n- [ ] State usa valores default (string=\"\", number=0, boolean=false)\n- [ ] State NUNCA usa null ou undefined\n- [ ] widget-playground-state-102020 vem ANTES das demos\n- [ ] Cada demo tem namespace pr\u00F3prio\n- [ ] Cada `<demo>` tem id \u00FAnico e cont\u00E9m o HTML do componente\n- [ ] string \u2192 widget-playground-state-text-102020\n- [ ] number \u2192 widget-playground-state-number-102020\n- [ ] boolean \u2192 widget-playground-state-boolean-102020\n- [ ] HTML duplicado: no `<demo>` E no `<template>` do editor\n- [ ] `<demo>` sem class/style\n\n---\n\n## 10. Changelog\n\n| Version | Date       | Description |\n|---------|------------|-------------|\n| 2.1.0   | 2026-04-15 | Using dedicated widgets with -102020 suffix |\n| 2.2.0   | 2026-04-16 | Added HTML editor widget for live code editing |\n| 2.3.0   | 2026-04-16 | HTML editor uses template element for source code |\n| 2.4.0   | 2026-04-16 | HTML duplicated in demo AND template - demo works independently |\n| 2.5.0   | 2026-04-17 | Added \u00A72 explicit rule: tag name must be copied from @customElement, never derived |\n\n";
}
