declare module "_102020_/l2/aura.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/aura" {
    export class Aura {
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
}
declare module "_102020_/l2/auraOrganismBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/auraOrganismBase" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class AuraOrganismBase extends CollabLitElement {
    }
}
declare module "_102020_/l2/build.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/build" {
    export const DISTFOLDER = "wwwroot";
    export function buildModule(project: number, moduleName: string): Promise<boolean>;
}
declare module "_102020_/l2/buildFile.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/buildFile" {
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
    export function getDependenciesByHtml(file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean): Promise<IJSONDependence>;
}
declare module "_102020_/l2/collabAuraLiveView.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/collabAuraLiveView" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    import '/_100554_/l2/collabNav4Menu.js';
    interface ITab {
        moduleName: string;
        modulePath: string;
        project: number;
        pageInitial: string;
        actualPage: string;
        icon: string | undefined;
        target: string;
        iframe: HTMLIFrameElement | undefined;
    }
    export class CollabAuraLiveView102020 extends CollabLitElement {
        private msg;
        mode: 'develpoment' | 'production';
        actualTab: number;
        tabsMenu: any;
        lastInit: number;
        container?: HTMLElement;
        tabs: ITab[];
        private liveViewReady;
        get iframe(): HTMLIFrameElement | null;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        init(project: number, shortName: string, folder: string): Promise<void>;
        private setEvents;
        private onTabSelected;
        private onTabClosed;
        private checkToLoadPage;
        private setInitialTabInfos;
        private setActualTabInfos;
        private openTab;
        private closeTab;
        private addTab;
        private load;
        private toogleLoading;
        private loadPage;
        private loadInProduction;
        private loadInDevelopment;
        private APP_ID;
        private clearOldPageScripts;
        private injectHTML;
        private injectJS;
        private injectScriptRunTime;
        private injectGlobalStyle;
        private functionReplaceAnchor;
        private addStyleApp;
        private addScript;
    }
}
declare module "_102020_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102020_/l2/enhancementAura.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_102020_/l2/moleculeBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/moleculeBase" {
    import { StateLitElement } from '_102027_/l2/stateLitElement';
    export class MoleculeAuraElement extends StateLitElement {
        protected slotTags: string[];
        connectedCallback(): void;
        /**
         * Hides all slot tags defined in slotTags array
         */
        private hideSlotTags;
        /**
         * Returns a single slot tag element by name
         */
        protected getSlot(tag: string): Element | null;
        /**
         * Returns all elements of a slot tag
         */
        protected getSlots(tag: string): Element[];
        /**
         * Returns an attribute value from a slot tag
         */
        protected getSlotAttr(tag: string, attr: string): string | null;
        /**
         * Returns the innerHTML of a slot tag
         */
        protected getSlotContent(tag: string): string;
        /**
         * Checks if a slot tag exists
         */
        protected hasSlot(tag: string): boolean;
    }
}
declare module "_102020_/l2/pluginCollabCoreIndex.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from '_102027_/l2/pluginBaseIndex';
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default: PluginCollabCoreIndex;
    export default _default;
}
declare module "_102020_/l2/previewModeAura.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/previewModeAura" {
    import { IJSONDependence } from '_102027_/l2/libCompile';
    export class PreviewModeAura {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        private esbuild;
        private needAwait;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        buildJS(other: string[]): Promise<any>;
        private configIframe;
        private _buildJS;
        private parseImportsMap;
        private findWidgets;
        private loadEsbuild;
        private initializeEsBuild;
        private loadCache;
        private mountJSImporMap;
        private mountLinks;
        /**
         * Injects Tailwind v4 dark mode configuration into the iframe.
         *
         * Tailwind v4 uses `prefers-color-scheme` by default.
         * This overrides it to use the `dark` class on <html>,
         * so toggleDarkLight() in servicePreview can control it via classList.
         *
         * Must be called BEFORE Tailwind processes the DOM (before the script runs).
         */
        private mountTailwindDarkMode;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private addJsReference;
    }
}
declare module "_102020_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102020_/l2/servicePreview.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/servicePreview" {
    import '/_102025_/l2/collabMessagesPrompt.js';
    import '/_102027_/l2/collabSpliterVerticalVarFixed.js';
    import '/_102027_/l2/collabSpliterHorizontalVarFixed.js';
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from '_102027_/l2/serviceBase';
    export class ServicePreview extends ServiceBase {
        private msg;
        private languages;
        elPreview: HTMLIFrameElement | undefined;
        modePreview: PreviewMode;
        watch: boolean;
        light: boolean;
        msize: string;
        lang: string;
        actualFiles: mls.stor.IInfo | undefined;
        actualModels: mls.editor.IModels;
        actualTheme: string;
        project: number;
        shortName: string;
        folder: string;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onClickTools(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        private toogleWatch;
        private toggleDarkLight;
        private changeLanguage;
        private getIframePreviewHTML;
        private onStyleChanged;
        private onFileAction;
        private setActualFileInfos;
        private setLastOpenedFile;
        private setActualFiles;
        private setActualModels;
        private createPreview;
        private writePreviewContentBlank;
        private writePreviewContent;
        private modeSinglePage;
        private updatePreviewMode;
        private clearPreview;
        private setLanguages;
        private configureTools;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
        handleSend(value: string, opt: {
            isSpecialMention: boolean;
            agentName: string;
        }): Promise<void>;
    }
    type PreviewMode = 'Desktop' | 'Mobile';
}
declare module "_102020_/l2/start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/start" {
    export function start(): void;
}
declare module "_102020_/l2/utils.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102020_/l2/widgetGenoma.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetGenoma" {
    import { StateLitElement } from '_102027_/l2/stateLitElement';
    import '/_102027_/l2/collabSelectKnob.js';
    export class WidgetGenoma102020 extends StateLitElement {
        private currentView;
        private selectedGroup;
        private mutations;
        private knobIndex;
        private filterCategory;
        private isLoadingMutations;
        private importedTags;
        private categoryMeta;
        private handleGroupSelect;
        private handleBackToGrid;
        private importAndRenderWidget;
        private updateDemoContainer;
        private handleKnobChange;
        private handlePillClick;
        private handleFilterChange;
        private getFilteredGroups;
        private getActiveCategories;
        render(): any;
        private renderGridView;
        private renderGroupCard;
        private renderKnobView;
    }
}
declare module "_102020_/l2/widgetPlaygroundState.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateBoolean.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateBoolean" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WcInputBoolean102020 extends CollabLitElement {
        value: boolean;
        name: string | undefined;
        label: string | undefined;
        disabled: boolean;
        hint: string | undefined;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateNumber.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateNumber" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WcInputNumber102020 extends CollabLitElement {
        value: number | undefined;
        name: string | undefined;
        label: string | undefined;
        min: number | undefined;
        max: number | undefined;
        step: number | undefined;
        placeholder: string | undefined;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        hint: string | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/widgetPlaygroundStatePreviewCode.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStatePreviewCode" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class PlaygroundStatePreviewCode extends MoleculeAuraElement {
        target: string;
        language: string;
        private code;
        private targetElement;
        private hljsLoaded;
        private codeEditor;
        firstUpdated(): Promise<void>;
        private loadHljs;
        private getSourceCode;
        private initContent;
        private formatHtml;
        private highlightCode;
        private debounceTimer;
        private handleInput;
        private updateDemo;
        private setStateDeep;
        private savedRange;
        private savedOffset;
        private saveSelection;
        private restoreSelection;
        private handleKeyDown;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/widgetPlaygroundStateText.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/widgetPlaygroundStateText" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class WidgetPlaygroundStateText extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autocorrect: 'off' | 'on' | undefined;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_102020_/l2/agents/agentNewMolecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMolecule" {
    import { IAgentAsync } from '_102027_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        ts: string;
    };
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export function updateDefs(skill: string, fileReference: string, group: string): Promise<void>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        group: string;
        skillMd: string;
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner" {
    import { IAgentMeta } from '_102027_/l2/aiAgentBase';
    export function createAgent(): {
        agentName: string;
        agentProject: number;
        agentFolder: string;
        agentDescription: string;
        visibility: string;
        beforePromptImplicit: typeof beforePromptImplicit;
        afterPromptStep: typeof afterPromptStep;
    };
    function beforePromptImplicit(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
    function afterPromptStep(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    export type Output = {
        type: "flexible";
        result: {
            group: string;
            prompt: string;
        };
    } | {
        type: "result";
        result: string;
    };
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner2" {
    import { IAgentAsync } from '_102027_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: TClarification;
    };
    export interface TClarification {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlannerClarification.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlannerClarification" {
    import { StateLitElement } from '_102027_/l2/stateLitElement';
    export interface ClarificationData {
        fileReference: string;
        description: string;
        prompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
    export class AgentNewMoleculePlannerClarification102020 extends StateLitElement {
        private msg;
        data: ClarificationData;
        private _editingField;
        private _editingIndex;
        private _tempValue;
        private _expandedSections;
        private _startEdit;
        private _cancelEdit;
        private _saveEdit;
        private _dispatchChange;
        private _toggleSection;
        private _addRequirement;
        private _removeRequirement;
        private _handleKeydown;
        private _renderEditableField;
        private _renderRequirementsList;
        render(): any;
        private onAction;
    }
}
declare module "_102020_/l2/agents/agentNewMoleculePlayground.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlayground" {
    import { IAgentAsync } from '_102027_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export function getSource(file: mls.stor.IFileInfo): Promise<string>;
    export type Output = {
        type: "flexible";
        result: IResult;
    };
    interface IResult {
        fileReference: string;
        html: string;
    }
}
declare module "_102020_/l2/molecules/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/index" {
    export type SkillCategory = 'dataEntry' | 'dataDiscovery' | 'dataDisplay' | 'actions' | 'navigation' | 'feedback' | 'identity';
    export interface MutationGroupEntry {
        name: string;
        category: SkillCategory;
        icon: string;
        label: string;
        shortDescription: string;
        mutationIndex: string;
    }
    export interface MutationWidget {
        name: string;
        tag: string;
        label: string;
        description: string;
    }
    export interface MutationGroup {
        widgets: MutationWidget[];
        demo: string;
        state: Record<string, any>;
    }
    export const mutationGroups: MutationGroupEntry[];
    export function getEnrichedGroups(): {
        description: any;
        skillReference: any;
        name: string;
        category: SkillCategory;
        icon: string;
        label: string;
        shortDescription: string;
        mutationIndex: string;
    }[];
    export function renderIcon(icon: string, size?: number): string;
}
declare module "_102020_/l2/molecules/groupEnterDate/datePicker.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-date--date-picker-102020\n\n# Objective\nPermitir que usu\u00E1rios selecionem e informem uma data (somente data, sem hor\u00E1rio) em formul\u00E1rios, por digita\u00E7\u00E3o ou por sele\u00E7\u00E3o em um calend\u00E1rio, com valida\u00E7\u00E3o, estados de intera\u00E7\u00E3o e emiss\u00E3o de eventos.\n\n# Responsibilities\n- Permitir definir, visualizar e atualizar um valor de data sem capturar ou exibir hor\u00E1rio.\n- Aceitar e expor o valor como string em formato consistente (por exemplo, YYYY-MM-DD) e manter consist\u00EAncia ao refletir mudan\u00E7as externas e ao emitir eventos.\n- Exibir um campo de entrada que permita digita\u00E7\u00E3o direta de data.\n- Disponibilizar abertura e fechamento de um painel de calend\u00E1rio para sele\u00E7\u00E3o de um dia.\n- Permitir sele\u00E7\u00E3o de um dia espec\u00EDfico no calend\u00E1rio quando dispon\u00EDvel.\n- Destacar visualmente o dia selecionado e o dia atual quando o calend\u00E1rio estiver vis\u00EDvel.\n- Indicar e impedir intera\u00E7\u00E3o com dias fora das restri\u00E7\u00F5es configuradas.\n- Permitir configura\u00E7\u00E3o de data m\u00EDnima e m\u00E1xima e aplicar as restri\u00E7\u00F5es tanto na digita\u00E7\u00E3o quanto na sele\u00E7\u00E3o via calend\u00E1rio.\n- Suportar estados: disabled, readonly, required e loading, alterando o comportamento de intera\u00E7\u00E3o e a apresenta\u00E7\u00E3o conforme o estado.\n- Bloquear intera\u00E7\u00E3o quando estiver disabled ou loading.\n- Impedir altera\u00E7\u00E3o de valor quando estiver readonly.\n- Permitir limpar o valor quando n\u00E3o for required e quando n\u00E3o estiver disabled nem readonly.\n- Validar a entrada digitada quanto a formato e sinalizar erro quando inv\u00E1lida.\n- N\u00E3o substituir automaticamente o \u00FAltimo valor v\u00E1lido por um valor inv\u00E1lido digitado.\n- Validar e sinalizar erro para viola\u00E7\u00F5es de required, min e max.\n- Expor estado/mensagem de erro configur\u00E1veis e tamb\u00E9m apresentar erros gerados por valida\u00E7\u00F5es internas.\n- Fornecer placeholder quando n\u00E3o houver valor.\n- Emitir evento de mudan\u00E7a quando a data for alterada com sucesso, contendo o novo valor e o valor anterior quando dispon\u00EDvel.\n- Emitir evento de blur quando o componente perder foco.\n- Reagir a mudan\u00E7as externas do valor (propriedade/atributo), atualizando a exibi\u00E7\u00E3o e a sele\u00E7\u00E3o no calend\u00E1rio.\n- Suportar intera\u00E7\u00F5es por teclado no calend\u00E1rio aberto, incluindo navega\u00E7\u00E3o, confirma\u00E7\u00E3o e cancelamento, mantendo comportamento previs\u00EDvel de foco.\n- Suportar intera\u00E7\u00F5es por ponteiro para abrir/fechar o calend\u00E1rio e selecionar datas.\n- Ao clicar fora com o calend\u00E1rio aberto, fechar o painel sem alterar o valor, a menos que a sele\u00E7\u00E3o j\u00E1 tenha sido confirmada.\n- Permitir internacionaliza\u00E7\u00E3o b\u00E1sica de r\u00F3tulos e mensagens exibidas (por exemplo, placeholder e mensagens de erro) conforme configura\u00E7\u00E3o/idioma do ambiente.\n- Manter compatibilidade com formul\u00E1rios, expondo um nome identificador (quando aplic\u00E1vel) e um valor serializ\u00E1vel para submiss\u00E3o equivalente a um campo de data.\n\n# Constraints\n- O componente deve tratar o valor exclusivamente como data; n\u00E3o deve coletar, armazenar, exibir ou emitir informa\u00E7\u00F5es de hor\u00E1rio.\n- Em estado disabled:\n  - N\u00E3o deve aceitar foco para altera\u00E7\u00E3o, nem permitir abrir o calend\u00E1rio, nem permitir limpar ou modificar o valor.\n- Em estado readonly:\n  - Deve exibir o valor, mas n\u00E3o deve permitir mudan\u00E7as por digita\u00E7\u00E3o, calend\u00E1rio ou limpeza.\n- Em estado loading:\n  - Deve bloquear qualquer intera\u00E7\u00E3o que altere estado/valor e indicar indisponibilidade tempor\u00E1ria.\n- Quando required estiver ativo:\n  - N\u00E3o deve permitir que o valor seja deixado vazio sem sinalizar erro de obrigatoriedade.\n- Se min e/ou max estiverem configurados:\n  - N\u00E3o deve permitir sele\u00E7\u00E3o de datas fora do intervalo.\n  - Deve sinalizar erro quando um valor informado estiver fora do intervalo.\n- Em caso de entrada com formato inv\u00E1lido:\n  - Deve sinalizar erro.\n  - N\u00E3o deve substituir o \u00FAltimo valor v\u00E1lido automaticamente.\n- Ao fechar o calend\u00E1rio por perda de foco/clique fora:\n  - N\u00E3o deve alterar o valor caso n\u00E3o exista confirma\u00E7\u00E3o de altera\u00E7\u00E3o.\n- O valor emitido em eventos e fornecido para submiss\u00E3o deve manter o formato consistente definido para o componente.\n\n# Notes\n- \u201CConfirma\u00E7\u00E3o\u201D de sele\u00E7\u00E3o deve ser interpretada como uma a\u00E7\u00E3o clara do usu\u00E1rio que finalize a escolha (por exemplo, selecionar um dia quando isso j\u00E1 for considerado confirma\u00E7\u00E3o, ou usar uma a\u00E7\u00E3o expl\u00EDcita de confirmar), mantendo consist\u00EAncia de comportamento.\n- As mensagens internacionalizadas devem cobrir, no m\u00EDnimo, placeholder e mensagens relacionadas a inv\u00E1lido e fora do intervalo.";
}
declare module "_102020_/l2/molecules/groupEnterDate/datePicker.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterDate/datePicker" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class DatePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private displayValue;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private emitChange;
        private emitMonthChange;
        private emitBlur;
        private emitFocus;
        private getEffectiveLocale;
        private pad2;
        private isIsoDate;
        private isoToDate;
        private dateToIso;
        private compareIso;
        private isWithinRange;
        private clampIsoToRange;
        private formatValueForDisplay;
        private getMonthLabel;
        private getWeekdayHeaders;
        private getGridStartDate;
        private getDaysInMonth;
        private getMonthKey;
        private getMinMonthKey;
        private getMaxMonthKey;
        private canNavigateTo;
        private clampViewToAllowedRange;
        private syncViewToValueOrToday;
        private getTodayIso;
        private getCellIso;
        private getWeekNumberIso;
        private handleToggleOpen;
        private handleClose;
        private handleDocumentPointerDown;
        private handleKeyDown;
        private handleOpenStateEffects;
        private handleSelectDay;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private handleTriggerBlur;
        private handleTriggerFocus;
        private renderLabel;
        private renderHelperOrError;
        private getTriggerClasses;
        private getIconClasses;
        private renderCalendarIcon;
        private renderLoading;
        private renderCalendarPanel;
        private renderViewMode;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupEnterDateTimeInterval/meetingDateTimeInterval.defs" {
    export const group = "groupEnterDateTimeInterval";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-date-time-interval--meeting-date-time-interval-102020\n\n# Objective\nPermitir que o usu\u00E1rio defina um intervalo de data e hora de uma reuni\u00E3o, informando in\u00EDcio e fim, com valida\u00E7\u00F5es de consist\u00EAncia e limites, e com emiss\u00E3o de eventos para integra\u00E7\u00E3o com valida\u00E7\u00E3o e fluxos externos.\n\n# Responsibilities\n- Exibir um campo/conjunto de campos para informar data+hora de in\u00EDcio e um campo/conjunto de campos para informar data+hora de fim.\n- Exibir r\u00F3tulos claros para os valores de \u201CIn\u00EDcio\u201D e \u201CFim\u201D.\n- Aceitar valores iniciais fornecidos externamente para in\u00EDcio e fim e refletir imediatamente esses valores na interface.\n- Atualizar a interface imediatamente quando os valores de in\u00EDcio e/ou fim forem alterados externamente.\n- Permitir que o usu\u00E1rio edite os valores de in\u00EDcio e fim quando o componente n\u00E3o estiver em modo desabilitado ou somente leitura.\n- Emitir um evento de mudan\u00E7a quando o usu\u00E1rio alterar in\u00EDcio ou fim, contendo sempre os valores atuais de in\u00EDcio e fim.\n- Emitir um evento espec\u00EDfico quando o usu\u00E1rio executar a a\u00E7\u00E3o de limpar valores, informando que o intervalo foi limpo.\n- Emitir evento de blur quando o usu\u00E1rio sair do campo ou do conjunto de campos do intervalo.\n- Validar e expor o estado de validade do componente conforme:\n  - Obrigatoriedade (quando configurada): in\u00EDcio e fim ausentes devem tornar o componente inv\u00E1lido.\n  - Consist\u00EAncia do intervalo: in\u00EDcio n\u00E3o pode ser posterior ao fim.\n  - Limites configurados: valores fora do m\u00EDnimo/m\u00E1ximo configurados devem tornar o componente inv\u00E1lido.\n- Expor indica\u00E7\u00E3o de erro e/ou mensagem de erro configur\u00E1vel e refletir o estado inv\u00E1lido para integra\u00E7\u00E3o com valida\u00E7\u00E3o externa.\n- Exibir placeholders configur\u00E1veis para in\u00EDcio e fim quando n\u00E3o houver valores.\n- Exibir texto auxiliar opcional (ajuda) quando fornecido.\n- Indicar visualmente estados de erro, desabilitado e somente leitura.\n- Manter layout compacto e leg\u00EDvel em formul\u00E1rios, incluindo em telas estreitas.\n\n# Constraints\n- Em estado desabilitado:\n  - Deve impedir qualquer intera\u00E7\u00E3o de edi\u00E7\u00E3o e a a\u00E7\u00E3o de limpar.\n  - N\u00E3o deve emitir eventos de mudan\u00E7a nem evento de limpar.\n- Em estado somente leitura:\n  - Deve exibir os valores sem permitir edi\u00E7\u00E3o nem limpar.\n  - N\u00E3o deve emitir eventos de mudan\u00E7a nem evento de limpar.\n- Em estado obrigat\u00F3rio:\n  - Deve considerar inv\u00E1lido quando in\u00EDcio e/ou fim estiverem ausentes.\n  - Deve expor estado de erro/invalidade de forma observ\u00E1vel.\n- Valida\u00E7\u00E3o de consist\u00EAncia:\n  - Deve considerar inv\u00E1lido quando in\u00EDcio for posterior ao fim.\n  - N\u00E3o deve alterar automaticamente os valores do usu\u00E1rio para corrigir inconsist\u00EAncias.\n- Limites m\u00EDnimo/m\u00E1ximo:\n  - Deve considerar inv\u00E1lido quando in\u00EDcio e/ou fim estiverem fora dos limites configurados.\n  - N\u00E3o deve ajustar automaticamente valores para \u201Ccaber\u201D nos limites.\n- Incrementos (step) de minutos/horas:\n  - Deve restringir a sele\u00E7\u00E3o/entrada de hora para respeitar o incremento configurado.\n- Emiss\u00E3o de eventos:\n  - Eventos de mudan\u00E7a devem ser emitidos apenas por intera\u00E7\u00E3o do usu\u00E1rio (n\u00E3o por atualiza\u00E7\u00F5es externas).\n  - Eventos de mudan\u00E7a devem incluir sempre ambos os valores (in\u00EDcio e fim), mesmo quando apenas um deles tiver sido alterado.\n\n# Notes\n- A indica\u00E7\u00E3o de erro pode incluir mensagem textual e/ou sinaliza\u00E7\u00E3o visual, conforme configura\u00E7\u00E3o.\n- O componente deve suportar placeholders distintos para in\u00EDcio e para fim.\n- O evento de blur destina-se \u00E0 integra\u00E7\u00E3o com valida\u00E7\u00E3o externa (por exemplo, valida\u00E7\u00E3o ao perder foco).";
}
declare module "_102020_/l2/molecules/groupEnterDateTimeInterval/meetingDateTimeInterval.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterDateTimeInterval/meetingDateTimeInterval" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class MeetingDateTimeIntervalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private draftStartValue;
        private draftEndValue;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private emitFocus;
        private emitBlur;
        private emitStartChange;
        private emitEndChange;
        private emitChange;
        private getEffectiveLocale;
        private pad2;
        private parseIsoLocalSeconds;
        private toIsoFromInputValue;
        private isoToInputValue;
        private compareIso;
        private isRangeValid;
        private computeDurationMinutes;
        private isDurationValid;
        private formatDateTimeForDisplay;
        private formatTimeForDisplay;
        private getDateKey;
        private formatRangeForView;
        private snapToMinuteStep;
        private getMinForStartInput;
        private getMaxForStartInput;
        private getMinForEndInput;
        private getMaxForEndInput;
        private canInteract;
        private handleOpen;
        private handleClose;
        private handleDraftStartInput;
        private handleDraftEndInput;
        private handleClear;
        private handleConfirm;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderInputCard;
        private renderPickerPanel;
        private renderLoading;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupEnterDatetime/datetimePopupPicker.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-datetime--datetime-popup-picker-102020\n\n# Objective\nPermitir que o usu\u00E1rio visualize, selecione e confirme um valor \u00FAnico de data e hora (datetime) por meio de um campo de entrada que abre um popup com calend\u00E1rio e seletor de hora, respeitando regras de passo de minutos, estados do componente e regras de fechamento.\n\n# Responsibilities\n- Exibir um campo de entrada que represente um valor de data+hora (datetime) em um \u00FAnico controle.\n- Abrir um popup de sele\u00E7\u00E3o ao clicar no campo ou ao receber foco por teclado (quando permitido).\n- Apresentar no popup duas \u00E1reas funcionais: um seletor de data (calend\u00E1rio) e um seletor de hora (horas e minutos).\n- Permitir selecionar uma data no calend\u00E1rio e refletir essa escolha como valor pendente no popup.\n- Permitir selecionar hora e minutos e refletir essa escolha como valor pendente no popup.\n- Manter a sele\u00E7\u00E3o de hora/minutos ao alterar apenas a data, e manter a data ao alterar apenas a hora/minutos.\n- Disponibilizar uma a\u00E7\u00E3o de \u201CConfirmar\u201D no popup para aplicar o valor pendente como valor final do componente.\n- Fechar o popup automaticamente ap\u00F3s a confirma\u00E7\u00E3o.\n- Fechar o popup automaticamente ao detectar clique fora do componente/popup.\n- Ao fechar por clique externo, descartar altera\u00E7\u00F5es pendentes e manter o \u00FAltimo valor confirmado.\n- Disponibilizar uma a\u00E7\u00E3o de \u201CCancelar\u201D opcional (quando habilitada/configurada) que fecha o popup sem confirmar altera\u00E7\u00F5es pendentes.\n- Permitir limpar o valor (quando habilitado), definindo o componente como vazio/nulo e refletindo isso no campo.\n- Exibir e manter sincronizados: (a) o valor no campo e (b) a sele\u00E7\u00E3o inicial do popup ao abrir.\n- Atualizar o valor exibido e a refer\u00EAncia usada pelo popup quando o valor for alterado externamente.\n- Emitir evento de mudan\u00E7a ao confirmar um novo valor.\n- Emitir evento de blur quando o campo perder foco.\n\n# Constraints\n- minuteStep deve controlar o incremento permitido/mostrado para minutos.\n- Minutos devem ser selecion\u00E1veis apenas quando forem m\u00FAltiplos de minuteStep; valores fora do passo n\u00E3o podem ser selecionados.\n- Enquanto o popup estiver aberto, mudan\u00E7as de data/hora devem afetar somente o valor pendente; o valor final s\u00F3 pode mudar mediante confirma\u00E7\u00E3o expl\u00EDcita.\n- A mesma inst\u00E2ncia n\u00E3o pode manter mais de um popup aberto simultaneamente.\n- Regras de teclado:\n  - Esc deve fechar o popup sem confirmar altera\u00E7\u00F5es pendentes.\n  - Enter no contexto do popup deve confirmar quando houver um valor pendente confirm\u00E1vel.\n- Estados do componente:\n  - disabled deve impedir foco, abertura do popup e qualquer intera\u00E7\u00E3o.\n  - readonly deve impedir altera\u00E7\u00E3o do valor; a possibilidade de abrir apenas para visualiza\u00E7\u00E3o deve seguir o contrato do grupo.\n  - required deve ser respeitado para integra\u00E7\u00E3o com valida\u00E7\u00E3o/formul\u00E1rios.\n  - error deve ser refletido como estado de erro do componente (sem alterar regras de confirma\u00E7\u00E3o/fechamento).\n- Valor e formato:\n  - value deve ser aceito como valor inicial/controlado e refletido no campo e no popup.\n  - O valor deve ser representado como string datetime em formato consistente (por exemplo, ISO 8601) ou null quando vazio, conforme contrato do grupo.\n- Limites (quando suportados pelo contrato do grupo):\n  - min e max devem restringir a sele\u00E7\u00E3o, impedindo escolhas fora do intervalo.\n  - Op\u00E7\u00F5es indispon\u00EDveis por min/max devem permanecer n\u00E3o selecion\u00E1veis.\n- Abertura do popup:\n  - Ao abrir, a sele\u00E7\u00E3o inicial deve refletir o value atual.\n  - Se o value estiver vazio, o popup deve iniciar com uma data/hora padr\u00E3o sem confirmar automaticamente.\n- Atualiza\u00E7\u00E3o din\u00E2mica de minuteStep:\n  - Se minuteStep mudar enquanto o popup estiver aberto, as op\u00E7\u00F5es/sele\u00E7\u00E3o de minutos devem se ajustar.\n  - O valor pendente s\u00F3 pode ser mantido se continuar v\u00E1lido; caso contr\u00E1rio, deve ser ajustado para um m\u00FAltiplo v\u00E1lido de acordo com uma regra determin\u00EDstica definida pelo contrato do grupo.\n\n# Notes\n- O popup deve ser ancorado ao campo de entrada e sobrepor o conte\u00FAdo adjacente quando aberto.\n- Itens/valores indispon\u00EDveis (por disabled, min/max ou regra de passo) devem ser n\u00E3o interativos e visualmente distingu\u00EDveis.\n- O fechamento do popup n\u00E3o deve depender de anima\u00E7\u00F5es para cumprir as regras funcionais.";
}
declare module "_102020_/l2/molecules/groupEnterDatetime/datetimePopupPicker.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterDatetime/datetimePopupPicker" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class DatetimePopupPickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private displayValue;
        private draftDate;
        private draftHour;
        private draftMinute;
        private viewMonthY;
        private viewMonthM;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private syncDerivedFromValue;
        private emitChange;
        private emitFocus;
        private emitBlur;
        private handleTriggerClick;
        private handleTriggerFocus;
        private handleTriggerBlur;
        private handleDocumentMouseDown;
        private handleDocumentKeyDown;
        private handlePrevMonth;
        private handleNextMonth;
        private handleSelectDay;
        private handleSelectHour;
        private handleSelectMinute;
        private handleClear;
        private handleConfirm;
        private getLocaleSafe;
        private getMinuteStepSafe;
        private pad2;
        private formatYmd;
        private parseIsoLocal;
        private isoToDateLocal;
        private formatValueForDisplay;
        private addMonths;
        private daysInMonth;
        private weekdayOfFirst;
        private normalizeIsoOrEmpty;
        private isDateAllowed;
        private isDatetimeAllowed;
        private adjustTimeToBoundaryIfNeeded;
        private getAllowedMinutesForDraftDate;
        private getAllowedHoursForDraftDate;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private getTriggerClasses;
        private renderTrigger;
        private renderCalendar;
        private renderTimeColumns;
        private renderActions;
        private renderPickerPanel;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupEnterDatetime/enterDatetimeField.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-datetime--enter-datetime-field-102020\n\n# Objective\nProvide a datetime entry field that allows users to enter and edit a date, a time, or a combined date-time value (based on a configurable mode), validate it against optional rules, and report user-driven changes and focus loss to a host form in a normalized, consistent format.\n\n# Responsibilities\n- Accept a single value that represents either a date-only, time-only, or date-time value, depending on the configured mode.\n- Allow configuration of the editable mode: date, time, or datetime.\n- Display an empty state and accept an optional placeholder appropriate to the configured mode.\n- Allow typed user entry and support committing edits via keyboard.\n- When available, allow picker-based selection without changing the value until a selection is confirmed.\n- Support clearing the value when clearing is allowed.\n- Validate the current value according to configured required and min/max constraints.\n- Expose an invalid/error indication; when an error message is provided, make the message available to the user.\n- Expose a disabled state that prevents user interaction and prevents user-driven value changes.\n- Expose a readonly state that allows focus/selection but prevents modification.\n- Expose a name identifier so a host can associate the value with a form field name.\n- Normalize user input to a consistent output format for the current mode.\n- Emit a bubbling, composed change event when the user changes the value to a valid normalized value; include the normalized value in the event detail.\n- Emit a bubbling, composed blur event when the field loses focus due to user interaction.\n- Re-evaluate validity and update invalid/error indication when constraints change or when the host updates the external value.\n\n# Constraints\n- Mode constraint: Only one of the supported modes (date, time, datetime) may be active at a time, and the value must correspond to that mode.\n- Required constraint: When required is true, an empty value must be treated as invalid.\n- Empty value rule: When not required, the field must allow and preserve an empty value as a valid state.\n- Bounds constraint: When min and/or max are provided, values outside the bounds must be treated as invalid.\n- Disabled constraint: When disabled, the field must not allow user edits, clearing, or picker selection, and must not emit user-driven change events.\n- Readonly constraint: When readonly, the field must allow focus/selection but must not allow modifications, clearing, or picker selection that changes the value, and must not emit user-driven change events.\n- Invalid input rule: When the user enters an invalid value, the field must indicate invalid/error state and must not emit a change event containing an invalid normalized value.\n- Picker confirmation rule: Opening or closing a picker must not change the value unless a selection is explicitly confirmed.\n- Time zone rule: A configurable time zone handling mode must be applied consistently to both normalization and min/max comparisons (local handling by default, with an option to treat the value as an explicit offset/UTC representation).\n- Clear action rule: A clear/reset action may be offered only when the field is not required, not disabled, and not readonly.\n- Scope limitation: The field must not apply business-specific scheduling rules (such as working days, holidays, or domain-specific calendar constraints).\n\n# Notes\n- The host may provide either a boolean error flag or an error message; both must result in an invalid indication, and an error message must be presented to the user.\n- Keyboard interaction must support typing, committing edits (e.g., via Enter), and clearing when clearing is allowed.";
}
declare module "_102020_/l2/molecules/groupEnterDatetime/enterDatetimeField.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterDatetime/enterDatetimeField" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class EnterDatetimeFieldMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private displayValue;
        private draftDate;
        private draftTime;
        private viewYear;
        private viewMonth;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private handleGlobalPointerDown;
        private handleGlobalKeyDown;
        private normalizeMinuteStep;
        private pad2;
        private parseIsoLocal;
        private toIsoLocal;
        private formatForDisplay;
        private syncDraftFromValue;
        private clampViewMonth;
        private getDaysInMonth;
        private getFirstWeekday;
        private getLabelId;
        private getHelperOrErrorId;
        private getHasError;
        private getMinParts;
        private getMaxParts;
        private compareLocal;
        private isDayDisabled;
        private isTimeDisabledForDate;
        private getMinuteOptions;
        private getTriggerAriaLabel;
        private emitChange;
        private emitFocus;
        private emitBlur;
        private handleTriggerClick;
        private handleTriggerFocus;
        private handleTriggerBlur;
        private handlePrevMonth;
        private handleNextMonth;
        private handlePickDay;
        private handlePickHour;
        private handlePickMinute;
        private handleClear;
        private handleConfirm;
        private renderLabel;
        private renderViewMode;
        private getTriggerClasses;
        private renderTrigger;
        private renderBelow;
        private getDayCellClasses;
        private renderCalendar;
        private getOptionClasses;
        private renderTimePickers;
        private renderActions;
        private renderPanel;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupEnterMoney/inputCurrency.defs" {
    export const group = "groupEnterMoney";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-money--input-currency-102020\n\n# Objective\nPermitir ao usu\u00E1rio inserir valores monet\u00E1rios com formata\u00E7\u00E3o autom\u00E1tica conforme moeda e locale definidos, garantindo entrada e exibi\u00E7\u00E3o amig\u00E1veis e consistentes para opera\u00E7\u00F5es financeiras.\n\n# Responsibilities\n- Permitir a digita\u00E7\u00E3o de valores monet\u00E1rios com suporte a casas decimais e separadores de milhar.\n- Formatar automaticamente o valor exibido conforme o locale e moeda definidos.\n- Exibir o s\u00EDmbolo da moeda de acordo com a configura\u00E7\u00E3o recebida.\n- Aceitar propriedades para definir o locale e o c\u00F3digo da moeda.\n- Permitir configura\u00E7\u00E3o do n\u00FAmero m\u00EDnimo e m\u00E1ximo de casas decimais.\n- Permitir configura\u00E7\u00E3o de valor m\u00EDnimo e m\u00E1ximo aceito.\n- Permitir estado desabilitado e somente leitura.\n- Permitir exibi\u00E7\u00E3o de mensagem de erro e estado de valida\u00E7\u00E3o.\n- Disparar evento de altera\u00E7\u00E3o ao modificar o valor.\n- Disparar evento de perda de foco ao sair do campo.\n- Permitir valor inicial via propriedade.\n- Permitir configura\u00E7\u00E3o de placeholder.\n- Permitir estado de carregamento.\n- Permitir marca\u00E7\u00E3o de campo obrigat\u00F3rio.\n\n# Constraints\n- O valor inserido deve respeitar o formato da moeda e locale definidos.\n- N\u00E3o deve aceitar valores fora dos limites m\u00EDnimo e m\u00E1ximo configurados.\n- N\u00E3o deve permitir edi\u00E7\u00E3o quando estiver em estado desabilitado ou somente leitura.\n- Deve exibir mensagem de erro apenas quando houver erro de valida\u00E7\u00E3o.\n- O s\u00EDmbolo da moeda deve ser exibido conforme o locale e moeda configurados.\n- O campo deve indicar visualmente quando estiver em estado de erro, desabilitado, somente leitura, carregando ou obrigat\u00F3rio.\n- O placeholder deve ser exibido apenas quando o campo estiver vazio.\n\n# Notes\n- A formata\u00E7\u00E3o deve ser atualizada em tempo real durante a digita\u00E7\u00E3o.\n- O s\u00EDmbolo da moeda pode aparecer antes ou depois do valor, conforme o locale.\n";
}
declare module "_102020_/l2/molecules/groupEnterMoney/inputCurrency.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterMoney/inputCurrency" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupEnterMoneyInputCurrencyMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private isFocused;
        handleIcaStateChange(key: string, value: any): void;
        private handleFocus;
        private handleInput;
        private handleBlur;
        private getLocale;
        private getCurrency;
        private getDecimals;
        private getPlaceholder;
        private getSymbol;
        private formatToRaw;
        private formatToDisplay;
        private parseLocaleNumber;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupEnterNumber/inputStepper.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-number--input-stepper-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar e ajustar um valor num\u00E9rico inteiro utilizando controles de incremento e decremento, respeitando limites definidos e estados do campo.\n\n# Responsibilities\n- Exibir o valor num\u00E9rico atual de forma clara entre os controles de incremento e decremento.\n- Permitir ao usu\u00E1rio aumentar ou diminuir o valor utilizando bot\u00F5es dedicados.\n- Respeitar os limites m\u00EDnimo e m\u00E1ximo definidos para o valor.\n- Aceitar e exibir um valor inicial configur\u00E1vel.\n- Permitir atualiza\u00E7\u00E3o controlada do valor por meio de propriedade externa.\n- Emitir um evento de mudan\u00E7a sempre que o valor for alterado pelo usu\u00E1rio.\n- Emitir um evento ao perder o foco.\n- Suportar estados desabilitado e somente leitura, impedindo qualquer altera\u00E7\u00E3o do valor nesses casos.\n- Suportar estado de carregamento, bloqueando intera\u00E7\u00F5es e exibindo um indicativo visual.\n- Suportar exibi\u00E7\u00E3o de erro, apresentando mensagem ou estado visual de erro quando informado.\n- Permitir configura\u00E7\u00E3o do passo de incremento/decremento.\n- Permitir configura\u00E7\u00E3o de nome para integra\u00E7\u00E3o com formul\u00E1rios.\n- Permitir marca\u00E7\u00E3o como campo obrigat\u00F3rio.\n\n# Constraints\n- O valor nunca pode ser menor que o m\u00EDnimo nem maior que o m\u00E1ximo definidos.\n- Quando desabilitado ou somente leitura, nenhuma intera\u00E7\u00E3o do usu\u00E1rio pode alterar o valor.\n- Quando em estado de carregamento, todas as intera\u00E7\u00F5es devem ser bloqueadas.\n- O evento de mudan\u00E7a s\u00F3 deve ser emitido quando o valor for alterado por a\u00E7\u00E3o do usu\u00E1rio.\n- O evento de perda de foco s\u00F3 deve ser emitido quando o campo realmente perder o foco.\n- O componente deve sempre refletir visualmente seus estados: erro, desabilitado, somente leitura e carregando.\n- O passo de incremento/decremento deve ser respeitado em todas as altera\u00E7\u00F5es de valor.\n- O campo obrigat\u00F3rio deve ser indicado quando configurado.\n\n# Notes\n- O componente pode ser utilizado em cen\u00E1rios como sele\u00E7\u00E3o de quantidade de produtos, unidades ou outros contextos que exijam ajuste r\u00E1pido de valores inteiros.\n";
}
declare module "_102020_/l2/molecules/groupEnterNumber/inputStepper.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterNumber/inputStepper" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupEnterNumberInputStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        private formatToDisplay;
        private parseRawToNumber;
        private roundToDecimals;
        private clamp;
        private emitChange;
        private emitInput;
        private emitBlur;
        private emitFocus;
        private increment;
        private decrement;
        private handleInput;
        private handleBlur;
        private handleFocus;
        render(): any;
        private renderViewMode;
        private renderEditMode;
    }
}
declare module "_102020_/l2/molecules/groupEnterText/textareaWithCounter.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-text--textarea-with-counter-102020\n\n# Objective\nPermitir que o usu\u00E1rio insira e edite descri\u00E7\u00F5es longas em uma \u00E1rea de texto, exibindo dinamicamente a contagem de caracteres digitados e respeitando limites definidos.\n\n# Responsibilities\n- Permitir inser\u00E7\u00E3o e edi\u00E7\u00E3o de texto livre em m\u00FAltiplas linhas.\n- Exibir a contagem de caracteres digitados de forma din\u00E2mica.\n- Permitir configura\u00E7\u00E3o de um limite m\u00E1ximo de caracteres.\n- Impedir a digita\u00E7\u00E3o al\u00E9m do limite m\u00E1ximo de caracteres, se definido.\n- Disparar evento de mudan\u00E7a sempre que o texto for alterado.\n- Permitir estados desabilitado e somente leitura.\n- Permitir exibi\u00E7\u00E3o de mensagem de erro e estado obrigat\u00F3rio.\n- Permitir configura\u00E7\u00E3o de valor inicial, nome do campo e placeholder.\n- Disparar evento ao perder o foco.\n\n# Constraints\n- N\u00E3o permitir inser\u00E7\u00E3o de caracteres al\u00E9m do limite m\u00E1ximo, caso definido.\n- O contador de caracteres deve ser sempre vis\u00EDvel ao usu\u00E1rio.\n- O formato do contador deve ser 'X/Y' quando houver limite, ou apenas 'X' se n\u00E3o houver.\n- O campo deve indicar visualmente quando o limite de caracteres for atingido.\n- Mensagem de erro deve ser exibida apenas quando configurada.\n- Os estados desabilitado, somente leitura e obrigat\u00F3rio devem ser indicados visualmente e respeitados funcionalmente.\n- O placeholder deve ser exibido apenas quando o campo estiver vazio.\n\n# Notes\n- O evento de mudan\u00E7a deve ser disparado para qualquer altera\u00E7\u00E3o no texto.\n- O evento de perda de foco deve ser disparado ao sair do campo.\n";
}
declare module "_102020_/l2/molecules/groupEnterText/textareaWithCounter.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterText/textareaWithCounter" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class TextareaWithCounterMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isFocused;
        private rawDisplay;
        connectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private getDisplayValue;
        private applyMask;
        private extractRawFromMask;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
        private renderLoading;
        private renderCharCounter;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupEnterTimeInterval/workShiftMolecule.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: molecules--group-enter-time-interval--work-shift-molecule-102020\n\n# Objective\nPermitir que o usu\u00E1rio configure um intervalo de turno de trabalho apenas com hora inicial e hora final, incluindo suporte opcional a turnos que atravessam a meia-noite, valida\u00E7\u00E3o configur\u00E1vel e emiss\u00E3o de eventos de intera\u00E7\u00E3o e mudan\u00E7a.\n\n# Responsibilities\n- Exibir dois campos de entrada/sele\u00E7\u00E3o de tempo: hora inicial e hora final, sem componente de data.\n- Permitir definir e atualizar um intervalo de tempo com base nos valores de hora inicial e hora final.\n- Representar e aceitar intervalos que atravessam a meia-noite quando a permiss\u00E3o de \u201Covernight\u201D estiver ativada.\n- Fornecer um valor de sa\u00EDda normalizado do intervalo contendo, no m\u00EDnimo, start (HH:mm), end (HH:mm) e um indicador de overnight (boolean) ou equivalente infer\u00EDvel.\n- Aplicar granularidade m\u00EDnima configur\u00E1vel (step, em minutos) \u00E0s entradas/sele\u00E7\u00F5es de tempo.\n- Aplicar limites configur\u00E1veis de hor\u00E1rio m\u00EDnimo e m\u00E1ximo permitidos para ambos os campos.\n- Validar preenchimento obrigat\u00F3rio quando required=true, exigindo start e end.\n- Validar formato e faixa de hor\u00E1rio (HH:mm dentro de 00:00\u201323:59), indicando erro quando inv\u00E1lido.\n- Validar consist\u00EAncia do intervalo, incluindo impedir/indicar erro para dura\u00E7\u00E3o zero (start == end) quando n\u00E3o permitido.\n- Validar dura\u00E7\u00E3o m\u00EDnima e/ou m\u00E1xima do turno quando configuradas, considerando corretamente intervalos overnight quando permitidos.\n- Permitir limpar o intervalo (torn\u00E1-lo vazio/nulo) por a\u00E7\u00E3o do usu\u00E1rio quando required=false.\n- Manter sincroniza\u00E7\u00E3o entre o valor recebido externamente e o que \u00E9 exibido; ao receber novo valor, atualizar a apresenta\u00E7\u00E3o sem exigir intera\u00E7\u00E3o do usu\u00E1rio.\n- Emitir evento de mudan\u00E7a quando um intervalo v\u00E1lido for alterado por a\u00E7\u00E3o do usu\u00E1rio, incluindo no detail o valor normalizado completo e, quando aplic\u00E1vel, durationMinutes.\n- Emitir evento incremental de edi\u00E7\u00E3o durante altera\u00E7\u00F5es, incluindo no detail os valores atuais, um indicador de validade e informa\u00E7\u00F5es de erro quando existirem.\n- Emitir evento de blur quando o componente (como um todo) perder foco.\n- Expor e refletir estado de erro via propriedade error (boolean|string), apresentando mensagem quando for string.\n- Quando a valida\u00E7\u00E3o interna detectar erro, refletir visualmente o estado inv\u00E1lido e disponibilizar informa\u00E7\u00F5es de erro nos eventos emitidos.\n- Suportar propriedade name para integra\u00E7\u00E3o com formul\u00E1rios/serializa\u00E7\u00E3o, associando-a ao valor do intervalo.\n- Indicar visualmente quando o intervalo configurado \u00E9 overnight (quando aplic\u00E1vel).\n- Apresentar placeholders configur\u00E1veis para campos vazios e manter consist\u00EAncia de formata\u00E7\u00E3o em HH:mm.\n- Apresentar estados visuais distintos para normal, foco, hover (quando aplic\u00E1vel), disabled, readonly e loading.\n- Exibir feedback de valida\u00E7\u00E3o destacando campos inv\u00E1lidos e exibindo mensagem de erro quando aplic\u00E1vel.\n- Manter legibilidade e usabilidade em diferentes larguras de container, acomodando r\u00F3tulos e mensagens de erro.\n\n# Constraints\n- Quando disabled=true:\n  - Deve bloquear intera\u00E7\u00F5es do usu\u00E1rio.\n  - N\u00E3o deve emitir eventos de mudan\u00E7a por a\u00E7\u00E3o do usu\u00E1rio.\n- Quando readonly=true:\n  - Deve exibir os valores.\n  - Deve impedir altera\u00E7\u00E3o por a\u00E7\u00E3o do usu\u00E1rio.\n  - N\u00E3o deve emitir eventos de mudan\u00E7a por a\u00E7\u00E3o do usu\u00E1rio.\n- Quando loading=true:\n  - Deve indicar estado de carregamento.\n  - Deve impedir intera\u00E7\u00E3o do usu\u00E1rio enquanto o estado estiver ativo.\n- Quando overnight n\u00E3o for permitido:\n  - Deve tratar end < start como inv\u00E1lido.\n- Quando overnight for permitido:\n  - Deve considerar end < start como um intervalo overnight v\u00E1lido.\n- Deve rejeitar/indicar erro para hor\u00E1rios fora de 00:00\u201323:59 e para formatos que n\u00E3o correspondam ao esperado.\n- Deve aplicar step e limites m\u00EDnimo/m\u00E1ximo de hor\u00E1rio \u00E0s entradas/sele\u00E7\u00F5es em ambos os campos.\n- Deve impedir/indicar erro para intervalo de dura\u00E7\u00E3o zero quando a configura\u00E7\u00E3o n\u00E3o permitir.\n- Deve considerar corretamente intervalos overnight ao avaliar dura\u00E7\u00E3o m\u00EDnima e m\u00E1xima, quando tais restri\u00E7\u00F5es estiverem configuradas.\n- N\u00E3o deve for\u00E7ar um valor inicial quando nenhum valor externo for fornecido, exceto quando um valor padr\u00E3o tiver sido explicitamente configurado.\n\n# Notes\n- O indicador de overnight pode ser fornecido explicitamente no valor de sa\u00EDda ou ser infer\u00EDvel a partir de start/end conforme as regras configuradas.\n- Eventos incrementais podem ocorrer com valores incompletos; nesses casos, o detail deve indicar validade e expor os campos atuais para suportar valida\u00E7\u00E3o e rea\u00E7\u00F5es do consumidor.";
}
declare module "_102020_/l2/molecules/groupEnterTimeInterval/workShiftMolecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupEnterTimeInterval/workShiftMolecule" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class WorkShiftMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private draftStart;
        private draftEnd;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private getLang;
        private getEffectiveLocale;
        private normalizeTimeValue;
        private coerceToTimeInput;
        private toMinutes;
        private isOvernight;
        private formatForDisplay;
        private formatRangeForView;
        private isTimeWithinMinMax;
        private calcDurationMinutes;
        private isEndValidAgainstStart;
        private buildTimeOptions;
        private emitFocus;
        private emitBlur;
        private emitStartChange;
        private emitEndChange;
        private emitChange;
        private handleOpen;
        private handleBackdropClick;
        private handleDraftInput;
        private handleClear;
        private handleConfirm;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private getContainerClasses;
        private getFieldButtonClasses;
        private renderFieldHeader;
        private renderTimeText;
        private renderOvernightBadge;
        private renderLoading;
        private renderPicker;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupLocatePosition/mapGps.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: molecules--group-locate-position--map-gps-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar e visualizar a localiza\u00E7\u00E3o de uma ocorr\u00EAncia, utilizando o GPS do dispositivo e exibindo a posi\u00E7\u00E3o em um mapa interativo.\n\n# Responsibilities\n- Permitir ao usu\u00E1rio capturar a localiza\u00E7\u00E3o atual utilizando o GPS do dispositivo.\n- Exibir a posi\u00E7\u00E3o selecionada em um mapa interativo para visualiza\u00E7\u00E3o.\n- Permitir ao usu\u00E1rio confirmar ou ajustar a posi\u00E7\u00E3o marcada no mapa.\n- Exibir o endere\u00E7o correspondente \u00E0 posi\u00E7\u00E3o selecionada, se dispon\u00EDvel.\n- Emitir evento ao selecionar ou alterar a localiza\u00E7\u00E3o, informando os dados de latitude, longitude e endere\u00E7o em formato JSON.\n- Permitir redefinir ou limpar a localiza\u00E7\u00E3o selecionada.\n- Indicar visualmente quando a localiza\u00E7\u00E3o est\u00E1 sendo obtida.\n- Permitir desabilitar ou tornar somente leitura o componente, impedindo altera\u00E7\u00F5es pelo usu\u00E1rio.\n- Suportar valor inicial informado externamente (posi\u00E7\u00E3o j\u00E1 definida).\n\n# Constraints\n- N\u00E3o deve permitir altera\u00E7\u00F5es quando estiver desabilitado ou em modo somente leitura.\n- Deve informar claramente ao usu\u00E1rio estados de carregamento, erro ou permiss\u00E3o negada ao tentar obter a localiza\u00E7\u00E3o.\n- Deve garantir que apenas uma posi\u00E7\u00E3o esteja selecionada por vez.\n- N\u00E3o deve emitir eventos de localiza\u00E7\u00E3o se n\u00E3o houver posi\u00E7\u00E3o v\u00E1lida selecionada.\n- Deve aceitar apenas valores de latitude e longitude v\u00E1lidos.\n- Deve permitir redefinir a sele\u00E7\u00E3o para estado vazio.\n\n# Notes\n- O endere\u00E7o exibido pode ser omitido caso n\u00E3o esteja dispon\u00EDvel para a posi\u00E7\u00E3o selecionada.\n- O componente deve ser responsivo a mudan\u00E7as externas no valor inicial.";
}
declare module "_102020_/l2/molecules/groupLocatePosition/mapGps.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupLocatePosition/mapGps" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupLocatePositionMapGpsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        suggestions: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private isFocused;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleSuggestionClick;
        private handleGeolocation;
        private parseLocation;
        private parseSuggestions;
        private getInputClasses;
        private getSuggestionClasses;
        private renderMapPreview;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupLocatePosition/positionOccurrence.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: molecules--group-locate-position--position-occurrence-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar e visualizar a localiza\u00E7\u00E3o de uma ocorr\u00EAncia, utilizando o GPS do dispositivo para capturar a posi\u00E7\u00E3o atual e exibindo essa posi\u00E7\u00E3o em um mapa interativo.\n\n# Responsibilities\n- Permitir ao usu\u00E1rio marcar a localiza\u00E7\u00E3o de uma ocorr\u00EAncia.\n- Oferecer op\u00E7\u00E3o para capturar a localiza\u00E7\u00E3o atual utilizando o GPS do dispositivo.\n- Exibir a posi\u00E7\u00E3o selecionada em um mapa interativo.\n- Permitir ao usu\u00E1rio visualizar a localiza\u00E7\u00E3o selecionada antes de confirmar.\n- Permitir ajuste manual da posi\u00E7\u00E3o no mapa.\n- Emitir evento ao selecionar ou alterar a localiza\u00E7\u00E3o, informando latitude, longitude e endere\u00E7o (quando dispon\u00EDvel).\n- Permitir inicializa\u00E7\u00E3o com uma localiza\u00E7\u00E3o pr\u00E9-definida, se fornecida.\n- Indicar visualmente quando a localiza\u00E7\u00E3o est\u00E1 sendo obtida via GPS.\n- Permitir ao usu\u00E1rio remover ou redefinir a localiza\u00E7\u00E3o selecionada.\n\n# Constraints\n- A localiza\u00E7\u00E3o s\u00F3 pode ser confirmada ap\u00F3s sele\u00E7\u00E3o ou captura v\u00E1lida.\n- O componente deve impedir m\u00FAltiplas solicita\u00E7\u00F5es simult\u00E2neas de localiza\u00E7\u00E3o via GPS.\n- O usu\u00E1rio n\u00E3o pode confirmar uma localiza\u00E7\u00E3o enquanto a captura via GPS estiver em andamento.\n- O componente deve exibir mensagem de erro caso a obten\u00E7\u00E3o da localiza\u00E7\u00E3o via GPS falhe.\n- O componente deve aceitar apenas coordenadas v\u00E1lidas para sele\u00E7\u00E3o ou inicializa\u00E7\u00E3o.\n- O componente deve sempre refletir visualmente o estado atual da sele\u00E7\u00E3o (selecionada, carregando, erro, removida).\n\n# Notes\n- A sele\u00E7\u00E3o manual deve ser poss\u00EDvel mesmo sem acesso ao GPS.\n- O endere\u00E7o pode ser exibido quando dispon\u00EDvel, mas n\u00E3o \u00E9 obrigat\u00F3rio para confirma\u00E7\u00E3o da sele\u00E7\u00E3o.";
}
declare module "_102020_/l2/molecules/groupLocatePosition/positionOccurrence.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupLocatePosition/positionOccurrence" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupLocatePositionPositionOccurrenceMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private gpsLoading;
        private gpsError;
        handleIcaStateChange(key: string, value: any): void;
        private parseValue;
        private getSuggestions;
        private getLabelForValue;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleSelectSuggestion;
        private handleGeolocate;
        private handleRemoveLocation;
        private renderLabel;
        private renderHelperOrError;
        private renderGeolocateButton;
        private renderRemoveButton;
        private renderSuggestions;
        private renderMap;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupRateItem/emojiSatisfaction.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: molecules--group-rate-item--emoji-satisfaction-102020\n\n# Objective\nPermitir que o usu\u00E1rio avalie sua satisfa\u00E7\u00E3o com o atendimento selecionando um emoji que representa seu n\u00EDvel de satisfa\u00E7\u00E3o.\n\n# Responsibilities\n- Exibir uma lista de op\u00E7\u00F5es de avalia\u00E7\u00E3o representadas por emojis.\n- Permitir que o usu\u00E1rio selecione apenas uma op\u00E7\u00E3o de emoji por vez.\n- Registrar o valor selecionado como um n\u00FAmero correspondente \u00E0 op\u00E7\u00E3o escolhida.\n- Permitir configura\u00E7\u00E3o das op\u00E7\u00F5es de emoji por meio de propriedades ou slots.\n- Emitir um evento de mudan\u00E7a ao selecionar uma op\u00E7\u00E3o, incluindo o valor selecionado.\n- Permitir ativa\u00E7\u00E3o dos estados desabilitado e somente leitura, impedindo intera\u00E7\u00E3o quando ativos.\n- Permitir exibi\u00E7\u00E3o de mensagem de erro e estado obrigat\u00F3rio.\n- Permitir configura\u00E7\u00E3o de valor inicial e nome para integra\u00E7\u00E3o com formul\u00E1rios.\n- Permitir exibi\u00E7\u00E3o de estado de carregamento, desabilitando intera\u00E7\u00F5es enquanto ativo.\n- Permitir navega\u00E7\u00E3o e sele\u00E7\u00E3o por teclado.\n- Emitir evento de perda de foco quando o componente perde o foco.\n\n# Constraints\n- Apenas uma op\u00E7\u00E3o de emoji pode ser selecionada por vez.\n- Quando desabilitado ou em modo somente leitura, n\u00E3o deve permitir intera\u00E7\u00E3o do usu\u00E1rio.\n- Quando em estado de carregamento, todas as intera\u00E7\u00F5es devem ser bloqueadas.\n- O valor selecionado deve ser sempre um n\u00FAmero v\u00E1lido correspondente a uma das op\u00E7\u00F5es exibidas.\n- Mensagem de erro s\u00F3 deve ser exibida se houver erro configurado.\n- O componente deve ser acess\u00EDvel por teclado e indicar visualmente o foco.\n- N\u00E3o deve permitir sele\u00E7\u00E3o de op\u00E7\u00F5es fora do intervalo configurado.\n\n# Notes\n- As op\u00E7\u00F5es de emoji e seus r\u00F3tulos podem ser personalizadas.\n- O componente pode exibir r\u00F3tulo ou legenda opcional, se fornecido.\n- Pode exibir tooltip ou descri\u00E7\u00E3o acess\u00EDvel para cada emoji, se configurado.";
}
declare module "_102020_/l2/molecules/groupRateItem/emojiSatisfaction.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupRateItem/emojiSatisfaction" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupRateItemEmojiSatisfactionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private hoverValue;
        private focusIndex;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private getItems;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleClick;
        private handleBlur;
        private handleFocus;
        private handleKeyDown;
        private getOptionElements;
        private getAriaLabelledById;
        private getAriaDescribedById;
        private isOptionHighlighted;
        private getOptionTabIndex;
        render(): any;
        private renderViewValue;
    }
}
declare module "_102020_/l2/molecules/groupRateItem/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupRateItem/index" {
    import { MutationGroup } from '_102020_/l2/molecules/index';
    export const mutations: MutationGroup;
}
declare module "_102020_/l2/molecules/groupRateItem/npsScale.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: molecules--group-rate-item--nps-scale-102020\n\n# Objective\nPermitir que o usu\u00E1rio avalie um item, servi\u00E7o ou experi\u00EAncia selecionando uma nota \u00FAnica de 0 a 10 em uma escala NPS (Net Promoter Score).\n\n# Responsibilities\n- Exibir uma escala de sele\u00E7\u00E3o com op\u00E7\u00F5es de 0 a 10.\n- Permitir sele\u00E7\u00E3o de apenas uma op\u00E7\u00E3o por vez.\n- Aceitar e exibir um valor inicial definido.\n- Emitir um evento de mudan\u00E7a ao selecionar uma nova nota.\n- Suportar estado desabilitado, impedindo qualquer intera\u00E7\u00E3o.\n- Suportar estado somente leitura, exibindo a sele\u00E7\u00E3o sem permitir altera\u00E7\u00E3o.\n- Exibir mensagens auxiliares, como descri\u00E7\u00E3o ou instru\u00E7\u00E3o, quando fornecidas.\n- Indicar visualmente estados de erro e obrigat\u00F3rio.\n- Permitir navega\u00E7\u00E3o e sele\u00E7\u00E3o por teclado (tab, setas, enter/space).\n- Emitir evento ao perder o foco (blur).\n- Permitir customiza\u00E7\u00E3o de r\u00F3tulos laterais (ex: \"Nada prov\u00E1vel\" e \"Muito prov\u00E1vel\").\n\n# Constraints\n- O valor selecionado deve ser um n\u00FAmero inteiro entre 0 e 10.\n- N\u00E3o permitir sele\u00E7\u00E3o m\u00FAltipla.\n- Quando desabilitado ou somente leitura, n\u00E3o deve permitir altera\u00E7\u00E3o do valor.\n- Deve ser poss\u00EDvel definir o componente como obrigat\u00F3rio.\n- Deve ser poss\u00EDvel exibir mensagens de erro quando necess\u00E1rio.\n- Mensagens auxiliares e r\u00F3tulos laterais devem ser exibidos apenas se fornecidos.\n- Deve ser acess\u00EDvel para navega\u00E7\u00E3o e sele\u00E7\u00E3o por teclado.\n- N\u00E3o deve permitir estados inv\u00E1lidos, como valores fora do intervalo permitido.\n\n# Notes\n- O componente deve ser responsivo e manter legibilidade em diferentes larguras.\n- Deve fornecer feedback visual ao passar o mouse ou navegar com teclado sobre as op\u00E7\u00F5es.";
}
declare module "_102020_/l2/molecules/groupRateItem/npsScale.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupRateItem/npsScale" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupRateItemNpsScaleMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private getItems;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleClick;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private focusOption;
        private getAriaLabel;
        private isHighlighted;
        private isSelected;
        private getLabelId;
        private getErrorId;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupRateItem/rateHearts.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: molecules--group-rate-item--rate-hearts-102020\n\n# Objective\nPermitir que o usu\u00E1rio avalie algo selecionando uma nota por meio de \u00EDcones de cora\u00E7\u00F5es, com suporte a diferentes estados e op\u00E7\u00F5es customizadas.\n\n# Responsibilities\n- Permitir ao usu\u00E1rio selecionar uma nota utilizando \u00EDcones de cora\u00E7\u00E3o.\n- Garantir que o valor selecionado seja sempre um n\u00FAmero inteiro dentro do intervalo permitido.\n- Exibir visualmente o valor selecionado por meio de cora\u00E7\u00F5es preenchidos e vazios.\n- Permitir configura\u00E7\u00E3o da quantidade m\u00EDnima, m\u00E1xima e do passo para o n\u00FAmero de cora\u00E7\u00F5es exibidos.\n- Aceitar op\u00E7\u00F5es customizadas para cada cora\u00E7\u00E3o (como r\u00F3tulos ou emojis) via Slot Tag Item.\n- Suportar os estados: desabilitado, somente leitura, obrigat\u00F3rio, erro e carregando.\n- Permitir limpar a sele\u00E7\u00E3o, exceto quando o campo for obrigat\u00F3rio.\n- Aceitar valor inicial definido pelo usu\u00E1rio.\n- Emitir evento de mudan\u00E7a ao selecionar um valor.\n- Emitir evento de perda de foco quando o componente perde o foco.\n- Suportar acessibilidade, incluindo navega\u00E7\u00E3o por teclado, foco e descri\u00E7\u00F5es acess\u00EDveis.\n\n# Constraints\n- O valor selecionado deve sempre respeitar os limites m\u00EDnimo e m\u00E1ximo definidos.\n- N\u00E3o deve permitir intera\u00E7\u00E3o quando estiver desabilitado ou em modo somente leitura.\n- N\u00E3o deve permitir limpar a sele\u00E7\u00E3o se o campo for obrigat\u00F3rio.\n- Deve indicar visualmente os estados: desabilitado, somente leitura, obrigat\u00F3rio, erro e carregando.\n- Deve garantir que apenas valores v\u00E1lidos possam ser selecionados.\n- Deve garantir que op\u00E7\u00F5es customizadas n\u00E3o quebrem a experi\u00EAncia de avalia\u00E7\u00E3o.\n- Deve garantir que a sele\u00E7\u00E3o seja clara e facilmente compreendida pelo usu\u00E1rio.\n\n# Notes\n- O componente deve ser responsivo e se adaptar ao espa\u00E7o dispon\u00EDvel.\n- A personaliza\u00E7\u00E3o visual dos cora\u00E7\u00F5es deve ser poss\u00EDvel sem comprometer a funcionalidade.\n";
}
declare module "_102020_/l2/molecules/groupRateItem/rateHearts.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupRateItem/rateHearts" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupRateItemRateHeartsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        handleIcaStateChange(key: string, value: any): void;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleOptionClick;
        private handleBlur;
        private handleFocus;
        private handleKeyDown;
        private getParsedItems;
        private getHeartIcon;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
    }
}
declare module "_102020_/l2/molecules/groupRateItem/rateStars.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: molecules--group-rate-item--rate-stars-102020\n\n# Objective\nPermitir que o usu\u00E1rio avalie algo selecionando uma nota inteira de 1 a 5, utilizando uma interface visual de estrelas.\n\n# Responsibilities\n- Exibir visualmente 5 estrelas representando as op\u00E7\u00F5es de nota.\n- Permitir ao usu\u00E1rio selecionar uma nota inteira entre 1 e 5 clicando em qualquer estrela.\n- Destacar visualmente as estrelas selecionadas e todas as anteriores \u00E0 nota escolhida.\n- Permitir alterar a nota selecionada a qualquer momento, enquanto n\u00E3o estiver desabilitado ou em modo somente leitura.\n- Permitir limpar a sele\u00E7\u00E3o, caso a nota n\u00E3o seja obrigat\u00F3ria.\n- Emitir um evento de altera\u00E7\u00E3o ao selecionar uma nova nota, informando o valor selecionado.\n- Permitir navega\u00E7\u00E3o e sele\u00E7\u00E3o por teclado (setas esquerda/direita, espa\u00E7o, enter).\n- Emitir evento de perda de foco (blur) ao perder o foco.\n- Permitir estado desabilitado, impedindo qualquer intera\u00E7\u00E3o do usu\u00E1rio.\n- Permitir estado somente leitura, exibindo o valor sem permitir altera\u00E7\u00F5es.\n- Permitir exibir estado de erro, com indica\u00E7\u00E3o visual e mensagem de erro quando fornecida.\n- Permitir exibir estado obrigat\u00F3rio, indicando visualmente que o campo \u00E9 requerido.\n- Permitir exibir estado de carregamento, desabilitando intera\u00E7\u00F5es enquanto estiver ativo.\n- Aceitar valor inicial (nota j\u00E1 selecionada).\n- Aceitar nome para integra\u00E7\u00E3o com formul\u00E1rios.\n\n# Constraints\n- Sempre exibir exatamente 5 estrelas, representando as op\u00E7\u00F5es de nota de 1 a 5.\n- O valor m\u00EDnimo permitido \u00E9 1, o m\u00E1ximo \u00E9 5, e o passo \u00E9 1.\n- N\u00E3o permitir sele\u00E7\u00E3o de valores fora do intervalo de 1 a 5.\n- N\u00E3o permitir intera\u00E7\u00E3o quando estiver desabilitado, em modo somente leitura ou carregando.\n- O campo pode ser obrigat\u00F3rio ou opcional, conforme configura\u00E7\u00E3o.\n- Deve ser responsivo, adaptando o layout para diferentes larguras de tela.\n- Deve garantir acessibilidade, incluindo contraste adequado, foco vis\u00EDvel e suporte a leitores de tela (labels, aria).\n\n# Notes\n- O destaque visual ao passar o mouse sobre as estrelas deve indicar qual nota ser\u00E1 selecionada.\n- A indica\u00E7\u00E3o visual dos estados (erro, obrigat\u00F3rio, desabilitado, somente leitura, carregando) deve ser clara e percept\u00EDvel.\n";
}
declare module "_102020_/l2/molecules/groupRateItem/rateStars.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupRateItem/rateStars" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupRateItemRateStarsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private hoverValue;
        private focusedIndex;
        connectedCallback(): void;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleClick;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private getStarButton;
        private getRatingItems;
        private isHighlighted;
        private getAriaLabel;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupSelectFileForUpload/dragDropPreview.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: molecules--group-select-file-for-upload--drag-drop-preview-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar m\u00FAltiplas imagens para upload utilizando uma \u00E1rea interativa de drag-and-drop ou sele\u00E7\u00E3o manual, exibindo previews visuais das imagens escolhidas e fornecendo feedback visual durante a intera\u00E7\u00E3o.\n\n# Responsibilities\n- Permitir sele\u00E7\u00E3o de m\u00FAltiplos arquivos de imagem por drag-and-drop e/ou clique em \u00E1rea interativa.\n- Exibir miniaturas (previews) de todas as imagens selecionadas antes do upload.\n- Emitir evento de mudan\u00E7a contendo a lista de arquivos selecionados.\n- Validar e rejeitar arquivos que n\u00E3o sejam imagens, emitindo evento de rejei\u00E7\u00E3o para arquivos inv\u00E1lidos.\n- Permitir remo\u00E7\u00E3o individual de imagens da sele\u00E7\u00E3o, atualizando os previews imediatamente.\n- Fornecer feedback visual ao usu\u00E1rio ao arrastar arquivos sobre a \u00E1rea de drop.\n- Permitir limpar toda a sele\u00E7\u00E3o de arquivos (reset).\n- Indicar visualmente o estado vazio quando nenhuma imagem estiver selecionada.\n\n# Constraints\n- Aceitar apenas arquivos de imagem (ex: JPEG, PNG, GIF).\n- N\u00E3o realizar upload autom\u00E1tico dos arquivos selecionados.\n- Permitir sele\u00E7\u00E3o de m\u00FAltiplos arquivos em uma \u00FAnica intera\u00E7\u00E3o.\n- Exibir mensagem de erro ou destaque visual para arquivos rejeitados.\n- Garantir que a \u00E1rea de drag-and-drop seja claramente destacada e responsiva a diferentes tamanhos de tela.\n- Integrar bot\u00E3o ou link para sele\u00E7\u00E3o manual de arquivos \u00E0 \u00E1rea de drop.\n- Impedir sele\u00E7\u00E3o de arquivos inv\u00E1lidos e prevenir estados inconsistentes na sele\u00E7\u00E3o.\n\n# Notes\n- O componente deve ser responsivo e acess\u00EDvel.\n- O feedback visual deve ser claro durante todas as etapas de intera\u00E7\u00E3o do usu\u00E1rio.";
}
declare module "_102020_/l2/molecules/groupSelectFileForUpload/dragDropPreview.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupSelectFileForUpload/dragDropPreview" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class SelectFileForUploadDragDropImagePreviewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private inputId;
        private onZoneClick;
        private onZoneKeyDown;
        private onDragOver;
        private onDragLeave;
        private onDrop;
        private onInputChange;
        private handleFiles;
        private isAcceptedType;
        private handleRemoveFile;
        private handleRemoveAll;
        private renderLabel;
        private renderHelperOrError;
        private renderDropZone;
        private renderFileList;
        private renderImagePreview;
        private formatSize;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupSelectOne/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupSelectOne/index" {
    import { MutationGroup } from '_102020_/l2/molecules/index';
    export const mutations: MutationGroup;
}
declare module "_102020_/l2/molecules/groupSelectOne/radioGroupSelect.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: molecules--group-select-one--radio-group-select-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar exatamente uma op\u00E7\u00E3o entre v\u00E1rias apresentadas, utilizando radio buttons, com suporte a orienta\u00E7\u00E3o vertical ou horizontal.\n\n# Responsibilities\n- Exibir uma lista de op\u00E7\u00F5es, cada uma representada por um radio button.\n- Permitir a sele\u00E7\u00E3o de apenas uma op\u00E7\u00E3o por vez.\n- Suportar orienta\u00E7\u00E3o vertical (op\u00E7\u00F5es empilhadas) e horizontal (op\u00E7\u00F5es lado a lado), configur\u00E1vel.\n- Receber a lista de op\u00E7\u00F5es como entrada.\n- Permitir definir qual op\u00E7\u00E3o est\u00E1 selecionada inicialmente.\n- Emitir um evento ao alterar a sele\u00E7\u00E3o, informando o valor selecionado.\n- Suportar estados desabilitado e somente leitura, aplicando-os a todas as op\u00E7\u00F5es.\n- Permitir marcar o componente como obrigat\u00F3rio (required).\n- Exibir mensagem de erro quando fornecida.\n- Permitir atribuir um nome ao grupo de radio buttons para integra\u00E7\u00E3o com formul\u00E1rios.\n- Suportar estado de carregamento (loading), exibindo indica\u00E7\u00E3o visual apropriada.\n- Permitir customiza\u00E7\u00E3o do conte\u00FAdo de cada op\u00E7\u00E3o via Slot Tag 'Item'.\n\n# Constraints\n- Apenas uma op\u00E7\u00E3o pode ser selecionada por vez.\n- Quando desabilitado ou somente leitura, nenhuma op\u00E7\u00E3o pode ser alterada pelo usu\u00E1rio.\n- Quando obrigat\u00F3rio, n\u00E3o permitir estado sem sele\u00E7\u00E3o ao submeter.\n- A mensagem de erro deve ser exibida apenas quando fornecida.\n- O estado de carregamento deve impedir intera\u00E7\u00E3o com as op\u00E7\u00F5es.\n- O nome do grupo deve ser \u00FAnico dentro do contexto do formul\u00E1rio para evitar conflitos.\n- A orienta\u00E7\u00E3o (vertical ou horizontal) deve ser aplicada de forma consistente a todas as op\u00E7\u00F5es.\n\n# Notes\n- O estado selecionado, desabilitado, erro e carregamento devem ser refletidos visualmente de forma clara.\n- A customiza\u00E7\u00E3o do conte\u00FAdo de cada op\u00E7\u00E3o permite flexibilidade na apresenta\u00E7\u00E3o das op\u00E7\u00F5es.";
}
declare module "_102020_/l2/molecules/groupSelectOne/radioGroupSelect.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupSelectOne/radioGroupSelect" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class RadioGroupSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        orientation: 'vertical' | 'horizontal';
        private searchQuery;
        private _radioName;
        private handleRadioChange;
        private handleBlur;
        private handleFocus;
        private handleSearchInput;
        private getParsedItems;
        private getParsedGroups;
        private getAllItems;
        private getSelectedLabel;
        private getRadioName;
        private getFilteredItems;
        private getFilteredGroups;
        render(): any;
        private renderRadioItem;
    }
}
declare module "_102020_/l2/molecules/groupSelectOne/segmentedControl.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: molecules--group-select-one--segmented-control-102020\n\n# Objective\nPermitir ao usu\u00E1rio selecionar exatamente um item entre 2 a 5 op\u00E7\u00F5es apresentadas lado a lado, destacando visualmente a op\u00E7\u00E3o escolhida e suportando estados como desabilitado, somente leitura, obrigat\u00F3rio, erro e carregamento.\n\n# Responsibilities\n- Exibir simultaneamente todas as op\u00E7\u00F5es dispon\u00EDveis como bot\u00F5es segmentados.\n- Permitir a sele\u00E7\u00E3o de apenas uma op\u00E7\u00E3o por vez.\n- Destacar visualmente o item atualmente selecionado.\n- Permitir altera\u00E7\u00E3o da sele\u00E7\u00E3o ao interagir com outra op\u00E7\u00E3o.\n- Emitir notifica\u00E7\u00E3o de mudan\u00E7a ao selecionar uma nova op\u00E7\u00E3o.\n- Permitir que toda a barra ou op\u00E7\u00F5es individuais estejam desabilitadas.\n- Permitir estado somente leitura, impedindo altera\u00E7\u00F5es na sele\u00E7\u00E3o.\n- Indicar visualmente quando o campo for obrigat\u00F3rio.\n- Exibir mensagem de erro quando houver estado de erro.\n- Permitir defini\u00E7\u00E3o de nome para integra\u00E7\u00E3o com formul\u00E1rios.\n- Exibir indicador visual de carregamento quando necess\u00E1rio.\n\n# Constraints\n- Deve apresentar entre 2 e 5 op\u00E7\u00F5es, n\u00E3o mais nem menos.\n- Apenas uma op\u00E7\u00E3o pode estar selecionada ao mesmo tempo.\n- N\u00E3o deve permitir sele\u00E7\u00E3o m\u00FAltipla.\n- N\u00E3o deve permitir altera\u00E7\u00E3o quando em estado somente leitura ou desabilitado.\n- N\u00E3o deve emitir evento de mudan\u00E7a se a sele\u00E7\u00E3o n\u00E3o for alterada.\n- Deve impedir intera\u00E7\u00E3o quando em estado de carregamento.\n- Deve exibir indica\u00E7\u00E3o visual clara para estados de erro, desabilitado, obrigat\u00F3rio e carregamento.\n\n# Notes\n- O componente deve ser responsivo, adaptando o layout para diferentes larguras.\n- O espa\u00E7amento entre bot\u00F5es deve ser consistente e agrad\u00E1vel visualmente.\n";
}
declare module "_102020_/l2/molecules/groupSelectOne/segmentedControl.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupSelectOne/segmentedControl" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupSelectOneSegmentedControlMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private handleSelect;
        private handleBlur;
        private handleFocus;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupSelectOne/selectDropdown.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupSelectOne/selectDropdown" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class SelectDropdownMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private handleDocumentClick;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleBlur;
        private handleSearchInput;
        private handleItemClick;
        private handlePanelKeydown;
        private getTriggerLabel;
        private getPlaceholder;
        private getPanelItems;
        private getPanelGroups;
        private getAllItems;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderLoading;
        private renderPanel;
        private renderPanelItem;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupShowProgress/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupShowProgress/index" {
    import { MutationGroup } from '_102020_/l2/molecules/index';
    export const mutations: MutationGroup;
}
declare module "_102020_/l2/molecules/groupShowProgress/progressBar.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: molecules--group-show-progress--progress-bar-102020\n\n# Objective\nDisplay a progress bar that visually and textually indicates the progress of file uploads, supporting both known and unknown progress states, and providing real-time feedback to users.\n\n# Responsibilities\n- Display a horizontal progress bar that fills according to the provided progress percentage (0 to 100).\n- Show the current progress percentage as text (e.g., '57%') visible to the user.\n- Support an indeterminate state when progress is unknown, with a distinct visual indication.\n- Indicate when the upload is complete (e.g., when progress reaches 100%).\n- Allow for a label or description to be displayed with the progress bar.\n- Support a disabled or inactive state to reflect paused or canceled uploads.\n- Emit an event or notification when progress reaches 100% (upload complete).\n- Ensure accessibility, including appropriate ARIA attributes for progress indication.\n\n# Constraints\n- Progress percentage input must be a number between 0 and 100; values outside this range must be ignored or clamped.\n- Indeterminate state must not display a specific percentage value.\n- Disabled or inactive state must prevent user interaction and visually indicate inactivity.\n- Completion state must be clearly distinguishable from other states.\n- Label or description must be optional and not required for basic operation.\n- Accessibility requirements must be met for all states (determinate, indeterminate, disabled, complete).\n- Only one state (determinate, indeterminate, disabled) can be active at a time.\n\n# Notes\n- The molecule is intended for use in upload flows but can be used for other progress indications.\n- Visual feedback for each state must be clear and unambiguous to users.";
}
declare module "_102020_/l2/molecules/groupShowProgress/progressBar.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupShowProgress/progressBar" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupShowProgressProgressBarMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: any[];
        /**
         * Progress value (0–100). null = indeterminate.
         */
        value: number | null;
        /**
         * Visual size: 'xs', 'sm', 'md', 'lg'
         */
        size: string;
        /**
         * Accessible label
         */
        label: string;
        /**
         * Show numeric percentage
         */
        showValue: boolean;
        /**
         * Clamp value to [0, 100] if not null
         */
        private getClampedValue;
        /**
         * Map size prop to Tailwind height classes
         */
        private getBarHeightClass;
        /**
         * Map size prop to text size for value label
         */
        private getTextSizeClass;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupShowProgress/progressRing.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: molecules--group-show-progress--progress-ring-102020\n\n# Objective\nExibir visualmente o andamento da gera\u00E7\u00E3o de relat\u00F3rios por meio de um anel circular de progresso, suportando modos determinado e indeterminado.\n\n# Responsibilities\n- Exibir o progresso de uma opera\u00E7\u00E3o em formato de anel circular.\n- Permitir altern\u00E2ncia entre modo determinado (percentual conhecido) e indeterminado (progresso desconhecido).\n- Permitir exibi\u00E7\u00E3o opcional de valor percentual ou texto centralizado no anel.\n- Aceitar propriedades para controlar valor do progresso, estado indeterminado, tamanho do anel e estado desabilitado.\n- Emitir evento ao atingir 100% de progresso.\n- Fornecer informa\u00E7\u00F5es de progresso acess\u00EDveis para tecnologias assistivas.\n\n# Constraints\n- O valor de progresso no modo determinado deve estar entre 0 e 100.\n- No modo indeterminado, n\u00E3o deve exibir valor percentual fixo.\n- O componente deve apresentar estados visuais distintos para ativo, completo (100%), desabilitado e indeterminado.\n- N\u00E3o deve permitir valores fora do intervalo permitido no modo determinado.\n- O texto ou n\u00FAmero centralizado \u00E9 opcional e deve ser configur\u00E1vel.\n- Deve garantir acessibilidade, incluindo informa\u00E7\u00F5es relevantes para leitores de tela.\n\n# Notes\n- O componente deve ser visualmente neutro para se adaptar a diferentes contextos de relat\u00F3rios.\n";
}
declare module "_102020_/l2/molecules/groupShowProgress/progressRing.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupShowProgress/progressRing" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupShowProgressProgressRingMolecule extends MoleculeAuraElement {
        slotTags: any[];
        /**
         * Progress value (0–100). null = indeterminate
         */
        value: number | null;
        /**
         * Visual size: 'xs', 'sm', 'md', 'lg'
         */
        size: string;
        /**
         * Accessible label
         */
        label: string;
        /**
         * Show value in center
         */
        showValue: boolean;
        private msg;
        private getSizeProps;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/groupShowProgress/spinner.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: molecules--group-show-progress--spinner-102020\n\n# Objective\nFornecer um indicador visual de carregamento em formato de spinner, adequado para uso em bot\u00F5es e \u00E1reas pequenas, sinalizando ao usu\u00E1rio que um processo est\u00E1 em andamento.\n\n# Responsibilities\n- Exibir uma anima\u00E7\u00E3o visual cont\u00EDnua para indicar estado de carregamento.\n- Suportar modo indeterminado, mostrando apenas o estado de carregamento sem progresso percentual.\n- Permitir ativa\u00E7\u00E3o ou desativa\u00E7\u00E3o da exibi\u00E7\u00E3o do spinner por meio de uma propriedade booleana.\n- Permitir defini\u00E7\u00E3o de r\u00F3tulo acess\u00EDvel (aria-label) para leitores de tela.\n- Emitir evento de mudan\u00E7a de estado quando a propriedade de carregamento for alterada.\n- Permitir customiza\u00E7\u00E3o de tamanho (pequeno, m\u00E9dio, grande) por meio de propriedade.\n- Permitir customiza\u00E7\u00E3o de cor por meio de propriedade.\n\n# Constraints\n- N\u00E3o deve capturar foco nem permitir intera\u00E7\u00E3o direta do usu\u00E1rio.\n- Deve ser compat\u00EDvel para uso dentro de bot\u00F5es, campos de formul\u00E1rio ou \u00E1reas pequenas, sem alterar a estrutura ou comportamento do elemento pai.\n- N\u00E3o deve exibir texto ou outros elementos al\u00E9m da anima\u00E7\u00E3o visual do carregamento.\n- A anima\u00E7\u00E3o deve ser suave e cont\u00EDnua.\n- O tamanho padr\u00E3o deve ser pequeno, com possibilidade de ajuste.\n- A cor deve ser configur\u00E1vel e garantir contraste suficiente para ser vis\u00EDvel em diferentes fundos.\n\n# Notes\n- O componente deve ser visualmente discreto, adequado para espa\u00E7os reduzidos.\n- O r\u00F3tulo acess\u00EDvel \u00E9 obrigat\u00F3rio para garantir acessibilidade.";
}
declare module "_102020_/l2/molecules/groupShowProgress/spinner.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupShowProgress/spinner" {
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    export class GroupShowProgressSpinnerMolecule extends MoleculeAuraElement {
        slotTags: any[];
        /**
         * Progress value (0–100). null = indeterminate.
         */
        value: number | null;
        /**
         * Visual size: 'xs', 'sm', 'md', 'lg'
         */
        size: string;
        /**
         * Accessible label for screen readers
         */
        label: string;
        /**
         * Show numeric value (only in determinate mode)
         */
        showValue: boolean;
        /**
         * Spinner color (Tailwind color class, e.g. 'text-sky-500')
         */
        color: string;
        private clampedValue;
        handleIcaStateChange(key: string, value: any): void;
        connectedCallback(): void;
        render(): any;
        /**
         * Indeterminate spinner (animated SVG ring)
         */
        private renderIndeterminateSpinner;
        /**
         * Determinate spinner (progress ring)
         */
        private renderDeterminateSpinner;
        private getSizeClass;
    }
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView.defs" {
    export const group = "groupViewData";
    export const skill = "# Objective\nDisplay a data collection with adaptive layout that automatically switches between Table and Cards based on viewport size.\n\n# Responsibilities\n- Render data as Table on larger screens and Cards on smaller screens.\n- Automatically switch presentation based on configurable breakpoint.\n- Support row/card selection (none, single, multiple).\n- Display visual feedback for hover, selected, and disabled states.\n- Display empty and loading states.\n- Emit events for row clicks and selection changes.\n- Provide keyboard navigation and accessibility support.\n\n# Constraints\n- Must switch between Table and Cards based on viewport width.\n- Must respect selection mode configured.\n- Must block interactions when loading or disabled.\n- Must apply appropriate ARIA attributes for each presentation mode.\n\n# Notes\n- In Card mode, use first column as card title and remaining columns as field/value pairs.\n- Column `hidden` attribute can be used to hide specific fields in certain contexts.\n";
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupViewData/adaptiveDataView" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    type SelectionMode = 'none' | 'single' | 'multiple';
    export class AdaptiveDataViewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        hoverable: boolean;
        selectable: boolean;
        /** When true, blocks all interactions (click/keyboard/selection). */
        disabled: boolean;
        /** Selection mode: none | single | multiple */
        selectionMode: SelectionMode;
        /** Breakpoint (px). Below this width -> cards, otherwise table. */
        breakpointPx: number;
        private isCardMode;
        private selectedIndexes;
        private activeIndex;
        private resizeObserver;
        private mediaQueryList;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changed: Map<string, unknown>): void;
        private setupResponsiveMode;
        private teardownResponsiveMode;
        private parseColumns;
        private parseRows;
        private getVisibleColumnIndexes;
        private syncSelectionFromSlots;
        private syncActiveIndex;
        private isInteractiveBlocked;
        private isRowSelected;
        private emitRowClick;
        private emitSelectionChange;
        private handleToggleSelection;
        private handleRowActivate;
        private handleKeyDown;
        private focusActiveRow;
        private getRowClasses;
        private getCardClasses;
        private getCellAlignClass;
        private renderLoadingState;
        private renderEmptyState;
        private renderSelectionHint;
        private renderTable;
        private renderCards;
        private renderContractValidation;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable.defs" {
    export const group = "groupViewTable";
    export const skill = "# Objective\nExibir uma tabela de dados responsiva em formato tradicional, permitindo que o sistema apresente registros com colunas configur\u00E1veis e c\u00E9lulas com conte\u00FAdo rico, com suporte a sele\u00E7\u00E3o de linhas e emiss\u00E3o de eventos de intera\u00E7\u00E3o.\n\n# Responsibilities\n- Renderizar os dados em um layout de tabela tradicional, com cabe\u00E7alho e corpo, adaptando-se a telas pequenas com rolagem horizontal quando necess\u00E1rio.\n- Aceitar a defini\u00E7\u00E3o de colunas por meio de Slot Tags, permitindo configurar r\u00F3tulo, alinhamento e largura por coluna.\n- Aceitar a defini\u00E7\u00E3o de linhas por meio de Slot Tags, garantindo associa\u00E7\u00E3o est\u00E1vel entre linha (id) e suas c\u00E9lulas (key).\n- Exibir conte\u00FAdo rico dentro das c\u00E9lulas conforme fornecido pelo desenvolvedor, preservando a estrutura e a sem\u00E2ntica do conte\u00FAdo apresentado.\n- Oferecer sele\u00E7\u00E3o de linhas conforme modo configurado: nenhuma, sele\u00E7\u00E3o \u00FAnica ou sele\u00E7\u00E3o m\u00FAltipla.\n- Exibir, quando configurado, uma coluna dedicada de sele\u00E7\u00E3o (checkbox ou radio) alinhada ao modo de sele\u00E7\u00E3o.\n- Refletir visualmente os estados de intera\u00E7\u00E3o: hover de linha, linha selecionada e foco de teclado.\n- Permitir intera\u00E7\u00E3o por teclado para sele\u00E7\u00E3o de linha (Enter/Espa\u00E7o) quando a linha estiver focada e a sele\u00E7\u00E3o estiver habilitada.\n- Emitir eventos de intera\u00E7\u00E3o:\n  - Ao selecionar ou desselecionar linhas.\n  - Ao clicar em uma linha (quando habilitado).\n  - Ao acionar um elemento marcado como a\u00E7\u00E3o dentro de uma c\u00E9lula.\n  - Opcionalmente, ao interagir com o cabe\u00E7alho quando necess\u00E1rio para delegar comportamentos a camadas superiores.\n- Exibir um estado vazio quando n\u00E3o houver linhas, usando conte\u00FAdo fornecido via Slot Tag espec\u00EDfica.\n\n# Constraints\n- N\u00E3o deve implementar pagina\u00E7\u00E3o, ordena\u00E7\u00E3o ou filtragem; quando aplic\u00E1vel, deve apenas sinalizar intera\u00E7\u00F5es por eventos para que camadas superiores decidam o comportamento.\n- Quando em estado disabled ou readonly:\n  - N\u00E3o deve permitir altera\u00E7\u00F5es de sele\u00E7\u00E3o.\n  - Deve impedir affordances de intera\u00E7\u00E3o relacionadas \u00E0 sele\u00E7\u00E3o.\n  - Deve manter a capacidade de visualiza\u00E7\u00E3o e rolagem do conte\u00FAdo.\n- A sele\u00E7\u00E3o deve respeitar o modo configurado:\n  - Em modo \"none\", nenhuma a\u00E7\u00E3o deve alterar sele\u00E7\u00E3o.\n  - Em modo \"single\", no m\u00E1ximo uma linha pode ficar selecionada.\n  - Em modo \"multiple\", m\u00FAltiplas linhas podem ficar selecionadas.\n- Quando uma sele\u00E7\u00E3o controlada for fornecida externamente:\n  - A tabela deve refletir o estado informado.\n  - Intera\u00E7\u00F5es do usu\u00E1rio devem apenas emitir eventos solicitando mudan\u00E7a, sem assumir que a sele\u00E7\u00E3o foi efetivada.\n- Deve garantir acessibilidade:\n  - Linhas selecionadas devem expor estado selecionado por atributos apropriados.\n  - Controles de sele\u00E7\u00E3o devem ter r\u00F3tulos acess\u00EDveis.\n  - A navega\u00E7\u00E3o por teclado deve ser poss\u00EDvel, com indicadores de foco vis\u00EDveis.\n\n# Notes\n- O conte\u00FAdo de c\u00E9lulas \u00E9 considerado fornecido pelo desenvolvedor; a tabela apenas apresenta o conte\u00FAdo e reporta intera\u00E7\u00F5es.\n- Uma legenda (caption) pode ser exibida quando fornecida, melhorando a compreens\u00E3o e acessibilidade do conjunto de dados.";
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/groupViewTable/responsiveRichDataTable" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102020_/l2/moleculeBase';
    type SelectionMode = 'none' | 'single' | 'multiple';
    export class ResponsiveRichDataTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        striped: boolean;
        hoverable: boolean;
        bordered: boolean;
        compact: boolean;
        disabled: boolean;
        readonly: boolean;
        /** Enables emitting row-click event on row click */
        rowClickable: boolean;
        /** none | single | multiple */
        selectionMode: SelectionMode;
        /** Whether to render a dedicated selection control column */
        showSelectionColumn: boolean;
        /** Controlled selection: comma-separated ids OR array-like string. Recommended: comma-separated. */
        selectedIds: string | null;
        /** When true, the component will compute and apply selection changes internally. Default: false (controlled). */
        uncontrolledSelection: boolean;
        private internalSelected;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseSelectedIds;
        private getEffectiveSelectedSet;
        private getSelectionEnabled;
        private parseColumns;
        private parseRows;
        private getTextAlignClass;
        private getCellPaddingClasses;
        private getTableBaseClasses;
        private getCellBorderClasses;
        private getHeadCellClasses;
        private getBodyRowClasses;
        private getBodyCellClasses;
        private getColumnStyle;
        private getSelectionHeaderCellTemplate;
        private getSelectionBodyCellTemplate;
        private emitRowClick;
        private emitSelectionChange;
        private emitHeaderInteract;
        private emitCellAction;
        private requestToggleRowSelection;
        private requestToggleAllSelection;
        private handleRootClick;
        private handleRootKeyDown;
        private renderCaption;
        private renderLoadingState;
        private renderEmptyState;
        private renderHeader;
        private renderBody;
        private renderFooter;
        render(): TemplateResult;
    }
}
declare module "_102020_/l2/skills/aura/design.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/design" {
    export const skill = "\n\n---\nname: interface-design\ndescription: Interface design for organism and molecules implemented using Lit Web Components and Tailwind CSS.\n---\n\n# Tailwind Ui\n\n## Identity\n\nYou are a Tailwind CSS expert. You understand utility-first CSS, responsive\ndesign patterns, dark mode implementation, and how to build consistent,\nmaintainable component styles.\n\nYour core principles:\n1. Utility-first - compose styles from utilities, extract components when patterns repeat\n2. Responsive mobile-first - start with mobile, add breakpoint modifiers\n3. Design system consistency - use the theme, extend don't override\n4. Performance - purge unused styles, avoid arbitrary values when possible\n5. Accessibility - proper contrast, focus states, reduced motion\n\n# Implementation Stack\n\nAll interfaces must be implemented using:\n\n- **Lit 3.0 Web Components**\n- **Tailwind CSS**\n- **Semantic tokens mapped in Tailwind config**\n\n# Designing Frontend\n\n## Workflow\n\n1. **Conceptualize**\n   - Identify purpose and user context\n   - Choose a bold aesthetic direction (brutally minimal, maximalist, retro-futuristic, organic, luxury, brutalist, etc.)\n   - Define the one unforgettable element\n   - Note technical constraints (framework, performance, accessibility)\n\n2. **Implement**\n   - Write production-grade code (HTML/CSS/JS.)\n   - Apply aesthetic guidelines below\n\n3. **Verify**\n   - Check visual hierarchy and cohesion\n   - Test interactions and animations\n   - Validate accessibility requirements\n   - Confirm no generic patterns emerged\n\n4. **Iterate**\n   - Refine details based on verification\n   - Enhance distinctiveness where needed\n\n## Aesthetic Guidelines\n\n**Typography**\n- Use distinctive, characterful fonts (avoid Inter, Roboto, Arial, system fonts)\n- Pair expressive display fonts with refined body fonts\n\n**Color & Theme**\n- Build cohesive palettes with CSS variables\n- Use dominant colors with sharp accents, not evenly-distributed schemes\n- Avoid clich\u00E9d combinations (purple gradients on white)\n\n**Motion**\n- Create high-impact moments with orchestrated page loads and staggered reveals\n- Use CSS animations for HTML; Motion library for React\n- Add surprising hover states and scroll-triggered effects\n\n**Spatial Composition**\n- Break from grid conventions: asymmetry, overlap, diagonal flow\n- Use generous negative space OR intentional density\n\n**Backgrounds & Visual Effects**\n- Layer gradient meshes, noise textures, geometric patterns\n- Apply contextual effects: layered transparencies, dramatic shadows, decorative borders\n- Add atmosphere through depth and texture\n\n## Implementation Principles\n\n- **Match complexity to vision**: Maximalist designs require elaborate code; minimalist designs demand precision in spacing and typography\n- **Vary every design**: Different fonts, themes, aesthetics for each project\n- **Never converge**: Avoid repeated choices (Space Grotesk, common layouts)\n- **Context-specific**: Design should feel genuinely crafted for its purpose\n\n## Every Choice Must Be A Choice\n\nFor every decision, you must be able to explain WHY.\n\n- Why this layout and not another?\n- Why this color temperature?\n- Why this typeface?\n- Why this spacing scale?\n- Why this information hierarchy?\n\nIf your answer is \"it's common\" or \"it's clean\" or \"it works\" \u2014 you haven't chosen. You've defaulted. Defaults are invisible. Invisible choices compound into generic output.\n\n**The test:** If you swapped your choices for the most common alternatives and the design didn't feel meaningfully different, you never made real choices.\n";
}
declare module "_102020_/l2/skills/aura/moleculeGeneration2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/moleculeGeneration2" {
    export const skill = "# Molecule Generation Skill\n\n> Skill for generating UI Molecule components in the Collab system.\n\n---\n\n\n## 1. Metadata\n\n| Field       | Value                                                           |\n|-------------|-----------------------------------------------------------------|\n| **Name**    | moleculeGeneration                                              |\n| **Version** | 2.6.0                                                           |\n| **Category**| ui-generation                                                   |\n\n---\n\n## 2. Core Principles\n\nMolecules are **UI-first** components that follow these rules:\n\n| Principle              | Description                                                      |\n|------------------------|------------------------------------------------------------------|\n| **No Business Logic**  | Molecules do NOT contain business logic                          |\n| **No Shadow DOM**      | Molecules do NOT use Shadow Root                                 |\n| **Independence**       | Molecules must function independently                            |\n| **Data Flow**          | Data flows DOWN from Organisms via properties; events flow UP    |\n| **Slot Tags**          | Use Slot Tags (unknown HTML elements) for internal structure     |\n| **Contract-Based**     | Each molecule belongs to a Skill Group with a defined contract   |\n| **Interchangeable**    | Molecules in the same group can be swapped without breaking      |\n\n---\n\n## 3. Naming Conventions\n\n### Tag Name (Custom Element)\n```\nkebab-case(folder)--kebab-case(component)-(projectId)\n```\n**Example:** folder/subfolder/molecule1 => 'folder--subfolder--molecule1-102020'\n\n### Class Name\n```\nPascalCase + Molecule\n```\n**Example:** `SelectMolecule`\n\n### File Name\n```\ncamelCase.ts\n```\n**Example:** `selectMolecule.ts`\n\n---\n\n## 4. Import Structure\n\n```typescript\n// Lit and directives \u2014 ALWAYS from 'lit'\nimport {\n    html,\n    TemplateResult,\n    ifDefined,\n    nothing,\n    unsafeHTML,\n    ...\n} from 'lit';\n\n// Lit decorators\nimport { customElement, property, state } from 'lit/decorators';\n\n// Data Binding decorators\nimport { propertyDataSource, propertyCompositeDataSource } from '_102027_/l2/collabDecorators';\n\n// Base Class\nimport { MoleculeAuraElement } from '/_102020_/l2/moleculeBase';\n```\n\n### Import Rules \u2014 CRITICAL\n\n```typescript\n// \u274C WRONG \u2014 Do NOT import directives from separate paths\nimport { unsafeHTML } from 'lit/directives/unsafe-html';\nimport { ifDefined } from 'lit/directives/if-defined';\nimport { classMap } from 'lit/directives/class-map';\nimport { repeat } from 'lit/directives/repeat';\n\n// \u2705 CORRECT \u2014 Import ALL directives from 'lit'\nimport { html, nothing, unsafeHTML, ifDefined, repeat } from 'lit';\n```\n\n> **Note:** Do NOT import `classMap`. Use template strings for CSS classes instead (see Section 7).\n\n---\n\n\n## 5. Property Decorators\n\n### `@propertyDataSource`\nBinds the property to a **single dynamic state**.\n\n```typescript\n@propertyDataSource({ type: String }) \nvalue: string | undefined;\n```\n**Binding:** `{{page1.selectedId}}`\n\n---\n\n### `@propertyCompositeDataSource`\nBinds the property to **multiple composed states**.\n\n```typescript\n@propertyCompositeDataSource({ type: String }) \nlabel: string = '';\n```\n**Binding:** `Hello {{page1.userId}} - {{page1.userName}}`\n\n### Attribute mapping (important for non-string types)\n\nAll properties with **camelCase names** (more than one word) and type `Boolean`, `Number`, or `Object` **must** declare the `attribute` explicitly in kebab-case to ensure correct attribute reflection across all environments.\n\n```typescript\n@propertyDataSource({ type: Boolean, attribute: 'is-editing' })\nisEditing: boolean = false;\n\n@propertyDataSource({ type: Number, attribute: 'max-length' })\nmaxLength: number | null = null;\n\n@propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })\nminDurationMinutes: number = 0;\n```\n\nRule: `camelCase` property name \u2192 `kebab-case` attribute name, always.\n\nSingle-word properties of any type can omit the `attribute` field.\n\n---\n\n### `@@state`\nStandard Lit state for ** local UI state**.\n\n```typescript\n@state({ type: Boolean }) \nloading = false;\n```\n\n---\n\n### `@state`\n**Internal** reactive state (not exposed as an attribute).\n\n```typescript\n@state() \nprivate isOpen = false;\n```\n\n---\n\n## 6. Slot Tags\n\n### What are Slot Tags?\n\nSlot Tags are **unknown HTML elements** that define the molecule's internal structure. The user writes them declaratively, and the molecule reads and interprets them.\n\n```html\n<molecules--example-102020 attr1=\"a\">\n  <SlotTagExampe></SlotTagExampe>\n  <SlotTagExampe2></SlotTagExampe2>\n  \n</molecules--example-102020>\n```\n\n### Defining Slot Tags\nEach molecule must declare which Slot Tags it uses. Use ONLY the tags defined in the group contract. Do NOT create new tags.\n\n```typescript\nslotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n```\n\nThe base class automatically hides these tags so they don't appear on screen.\n\n### Reading Slot Tags\n\nUse the helper methods from `MoleculeAuraElement`:\n\n| Method | Returns | Description |\n|--------|---------|-------------|\n| `getSlot(tag)` | `Element \\| null` | Single slot tag element |\n| `getSlots(tag)` | `Element[]` | All elements of a slot tag |\n| `getSlotAttr(tag, attr)` | `string \\| null` | Attribute value from a slot tag |\n| `getSlotContent(tag)` | `string` | innerHTML of a slot tag |\n| `hasSlot(tag)` | `boolean` | Check if slot tag exists |\n\n---\n\n## 7. Naming Rules\n\n### Do NOT use `protected` or `override` in herdeded functions\n\nAll methods and properties should be `private` or without access modifier:\n\n```typescript\n// \u274C WRONG\nprotected firstUpdated() { }\nprotected override updated() { }\n\n// \u2705 CORRECT\n\nfirstUpdated() {\n  // ...\n}\n\nprivate handleSelect(value: string) {\n  // ...\n}\n```\n\n### Reserved Method Names - Do NOT Use\n\nThese names are used by Lit internally. Using them for other purposes will cause errors:\n\n| Reserved Name | Reason |\n|---------------|--------|\n| `renderOptions` | Lit internal |\n| `renderRoot` | Lit internal |\n| `createRenderRoot` | Lit internal |\n| `connectedCallback` | Lifecycle (use only for override) |\n| `disconnectedCallback` | Lifecycle (use only for override) |\n| `attributeChangedCallback` | Lifecycle (use only for override) |\n| `requestUpdate` | Lit internal |\n| `performUpdate` | Lit internal |\n| `shouldUpdate` | Lit internal |\n| `willUpdate` | Lit internal |\n| `update` | Lit internal |\n| `updated` | Lifecycle (use only for override) |\n| `firstUpdated` | Lifecycle (use only for override) |\n\n### Use descriptive prefixes for custom methods\n\n```typescript\n// \u274C WRONG - may conflict with Lit\nrenderOptions() { }\nupdateValue() { }\n\n// \u2705 CORRECT - clear custom method names\nrenderItemList() { }\nrenderDropdownContent() { }\nrenderTriggerButton() { }\nhandleValueChange() { }\nonItemSelect() { }\n```\n\n---\n\n## 8. CSS Classes Pattern\n\n### Do NOT use `classMap` with multiple classes\n\nThe `classMap` directive expects **one class per key**. Using multiple classes as a key causes errors:\n\n```typescript\n// \u274C WRONG - causes DOMTokenList error\nclassMap({\n  'border-slate-300 bg-white': !isSelected,  // Multiple classes as key\n})\n\n// \u274C WRONG - same problem with variable\nconst base = 'w-full rounded-md px-3 py-2';\nclassMap({\n  [base]: true,  // Multiple classes as key\n})\n```\n\n### Use template strings instead\n\nBuild CSS classes using arrays and `join()`:\n\n```typescript\n// \u2705 CORRECT - template strings\nconst classes = [\n  // Base classes (always applied)\n  'w-full rounded-md px-3 py-2 text-sm border transition',\n  // Conditional classes\n  isSelected ? 'border-sky-500 bg-sky-50 text-sky-900' : 'border-slate-200 bg-white hover:bg-slate-50',\n  // State classes\n  disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',\n].join(' ');\n\nreturn html\\`<button class=\\${classes}>...</button>\\`;\n```\n\n### Pattern for complex states\n\n```typescript\nprivate getItemClasses(item: ParsedItem, isSelected: boolean): string {\n  return [\n    // Base\n    'w-full rounded-md px-3 py-2 text-sm border transition',\n    // Selection state\n    isSelected \n      ? 'border-sky-500 bg-sky-50 text-sky-900' \n      : 'border-slate-200 bg-white text-slate-900',\n    // Hover (only when not disabled)\n    !item.disabled && !isSelected ? 'hover:bg-slate-50' : '',\n    // Disabled state\n    item.disabled ? 'opacity-50 cursor-not-allowed' : '',\n    // Focus state\n    !item.disabled ? 'focus:outline-none focus:ring-2 focus:ring-sky-500' : '',\n  ].filter(Boolean).join(' ');\n}\n\n```\n\n---\n## 9. Using `nothing` Correctly\n\n### Understanding Lit's `nothing`\n\nThe `nothing` sentinel from Lit is **NOT** a `TemplateResult`. It has its own type: `typeof nothing`.\n\n**Type definitions:**\n- `TemplateResult` \u2014 returned by `html` tagged template\n- `typeof nothing` \u2014 the type of the `nothing` constant\n\n### Do NOT return `nothing` directly from methods typed as `TemplateResult`\n\nSolution 1: Wrap`nothing` in `html` template\n\n\n---\n\n## 10. Rendering Slot Tag Content\n\nSlot Tag content may contain HTML. To render it properly, use `unsafeHTML` directive.\n\n### Do NOT use dynamic template strings\n\n```typescript\n// \u274C WRONG - causes \"invalid template strings array\" error\nhtml([content] as unknown as TemplateStringsArray)\n\n// \u274C WRONG - same error\nhtml(content)\n\n// \u274C WRONG - HTML will be escaped, not rendered\nconst content = '<strong>Bold</strong>';\nhtml\\`\\${content}\\`  // Outputs: \"<strong>Bold</strong>\" as text\n```\n\n### Use `unsafeHTML` for Slot Tag content\n\n```typescript\n\n// \u2705 CORRECT - HTML is rendered properly\nprivate renderItem(item: ParsedItem): TemplateResult {\n  return html\\`\n    <div class=\"item\">\n      \\${unsafeHTML(item.label)}\n    </div>\n  \\`;\n}\n\n// \u2705 CORRECT - with fallback\nprivate renderEmpty(): TemplateResult {\n  const content = this.getSlotContent('Empty') || this.msg.noResults;\n  return html\\`\n    <div class=\"text-slate-500 dark:text-slate-400\">\n      \\${unsafeHTML(content)}\n    </div>\n  \\`;\n}\n```\n\n### When to use each approach\n\n| Content Type | Approach | Example |\n|--------------|----------|---------|\n| Plain text (i18n messages) | Direct interpolation | `\\${this.msg.loading}` |\n| Slot Tag content (may have HTML) | `unsafeHTML` | `\\${unsafeHTML(item.label)}` |\n| User input (untrusted) | Never render as HTML | Always escape |\n\n> **Note:** Slot Tag content comes from the developer (trusted), so `unsafeHTML` is safe to use.\n\n```typescript\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n  pt: {\n    placeholder: 'Selecione uma op\u00E7\u00E3o',\n    noResults: 'Nenhum resultado encontrado',\n    loading: 'Carregando...',\n  },\n};\n/// **collab_i18n_end**\n```\n\n### Usage\n```typescript\nrender() {\n  const lang = this.getMessageKey(messages);\n  this.msg = messages[lang];\n  \n  return html\\`\\${this.msg.placeholder}\\`;\n}\n```\n\n---\n\n## 11. Derived State and `handleIcaStateChange`\n\n### The Problem\n\nWhen a property is bound to a state via `@propertyDataSource`, and you have a **derived value** (a value computed from that property), the derived value won't automatically update when the state changes externally.\n\n**Example:** In an `enter-money` component:\n- `value` is bound to state: `value=\"{{playground.basic.value}}\"`\n- `rawValue` is derived from `value`: `this.rawValue = this.formatNumberToRaw(this.value)`\n- When state changes externally, `value` updates but `rawValue` does NOT recalculate\n\n### Why It Happens\n\nThe `@propertyDataSource` decorator updates the property value when state changes, but it doesn't trigger Lit's `willUpdate` or `updated` lifecycle hooks automatically.\n\n### The Solution: `handleIcaStateChange`\n\nOverride `handleIcaStateChange` to recalculate derived values when state changes:\n\n```typescript\n// ===========================================================================\n// STATE CHANGE HANDLER\n// ===========================================================================\n\nhandleIcaStateChange(key: string, value: any) {\n  // Check if this state key is bound to 'value' property\n  const valueAttr = this.getAttribute('value');\n  if (valueAttr === \\`{{\\${key}}}\\`) {\n    // Recalculate derived value\n    this.rawValue = this.formatNumberToRaw(value);\n  }\n  \n  // Always request update to re-render\n  this.requestUpdate();\n}\n```\n\n### When to Use\n\nUse `handleIcaStateChange` when your molecule has:\n\n| Situation | Example | Action |\n|-----------|---------|--------|\n| Derived/computed values | `rawValue` from `value` | Recalculate in handler |\n| Formatted display values | `displayText` from `value` | Recalculate in handler |\n| Internal state that depends on props | `isOpen` based on `value` | Update in handler |\n\n### When NOT to Use\n\nDo NOT use `handleIcaStateChange` for:\n\n| Situation | Why |\n|-----------|-----|\n| Simple property \u2192 render | Lit handles this automatically |\n| No derived values | No need for the handler |\n| Business logic | Molecules should NOT have business logic |\n\n### Complete Example\n\n```typescript\n@customElement('molecules--enter-money-102020')\nexport class EnterMoneyMolecule extends MoleculeAuraElement {\n\n  // Property bound to state\n  @propertyDataSource({ type: Number }) \n  value: number | null = null;\n\n  // Derived value (formatted for input display)\n  @state()\n  private rawValue: string = '';\n\n  // ===========================================================================\n  // STATE CHANGE HANDLER\n  // ===========================================================================\n\n  handleIcaStateChange(key: string, value: any) {\n    // Check if 'value' property changed\n    const valueAttr = this.getAttribute('value');\n    if (valueAttr === \\`{{\\${key}}}\\`) {\n      this.rawValue = this.formatNumberToRaw(value);\n    }\n    \n    this.requestUpdate();\n  }\n\n  // ===========================================================================\n  // HELPER METHODS\n  // ===========================================================================\n\n  private formatNumberToRaw(num: number | null): string {\n    if (num === null || num === undefined) return '';\n    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2 });\n  }\n\n  private parseRawToNumber(raw: string): number | null {\n    const cleaned = raw.replace(/\\./g, '').replace(',', '.');\n    const num = parseFloat(cleaned);\n    return isNaN(num) ? null : num;\n  }\n\n  // ===========================================================================\n  // RENDER\n  // ===========================================================================\n\n  render() {\n    return html\\`\n      <input \n        type=\"text\"\n        .value=\\${this.rawValue}\n        @input=\\${this.handleInput}\n      />\n    \\`;\n  }\n\n  private handleInput(e: Event) {\n    const input = e.target as HTMLInputElement;\n    this.rawValue = input.value;\n    this.value = this.parseRawToNumber(input.value);\n  }\n}\n```\n\n### Multiple Derived Values\n\nIf you have multiple properties with derived values:\n\n```typescript\nhandleIcaStateChange(key: string, value: any) {\n  // Check each property that might have derived values\n  const valueAttr = this.getAttribute('value');\n  const minAttr = this.getAttribute('min');\n  const maxAttr = this.getAttribute('max');\n  \n  if (valueAttr === \\`{{\\${key}}}\\`) {\n    this.rawValue = this.formatNumberToRaw(value);\n  }\n  \n  if (minAttr === \\`{{\\${key}}}\\`) {\n    this.minDisplay = this.formatNumberToRaw(value);\n  }\n  \n  if (maxAttr === \\`{{\\${key}}}\\`) {\n    this.maxDisplay = this.formatNumberToRaw(value);\n  }\n  \n  this.requestUpdate();\n}\n```\n\n---\n\n## 12. Dark Mode\n\nMolecules MUST support dark mode using Tailwind's `dark:` variant classes. The platform toggles dark mode via the `dark` class on a parent element (class-based strategy).\n\n### Rules\n\n- **Never use hardcoded light-only colors.** Every color class (`bg-*`, `text-*`, `border-*`, `ring-*`, `shadow-*`) MUST have a `dark:` counterpart.\n- **Do not use inline styles** for colors \u2014 only Tailwind classes so dark mode variants work.\n- Follow the **semantic color pairing** table below consistently across all molecules.\n\n### Semantic Color Pairing\n\n| Role | Light | Dark |\n|------|-------|------|\n| Surface (default) | `bg-white` | `dark:bg-slate-800` |\n| Surface (sunken/input bg) | `bg-slate-50` | `dark:bg-slate-900` |\n| Surface (overlay/dropdown) | `bg-white` | `dark:bg-slate-800` |\n| Border (default) | `border-slate-200` | `dark:border-slate-700` |\n| Border (focus) | `border-sky-500` | `dark:border-sky-400` |\n| Border (error) | `border-red-500` | `dark:border-red-400` |\n| Text (primary) | `text-slate-900` | `dark:text-slate-100` |\n| Text (secondary/label) | `text-slate-600` | `dark:text-slate-400` |\n| Text (placeholder) | `text-slate-400` | `dark:text-slate-500` |\n| Text (disabled) | `text-slate-400` | `dark:text-slate-600` |\n| Text (error) | `text-red-600` | `dark:text-red-400` |\n| Text (helper) | `text-slate-500` | `dark:text-slate-400` |\n| Accent (selected bg) | `bg-sky-50` | `dark:bg-sky-900/40` |\n| Accent (selected text) | `text-sky-700` | `dark:text-sky-300` |\n| Accent (selected border) | `border-sky-500` | `dark:border-sky-400` |\n| Hover (item) | `hover:bg-slate-50` | `dark:hover:bg-slate-700` |\n| Focus ring | `focus:ring-sky-500` | `dark:focus:ring-sky-400` |\n| Disabled overlay | `opacity-50` | `opacity-50` (same) |\n\n### Example \u2014 input field with dark mode\n\n```typescript\nprivate getInputClasses(): string {\n  return [\n    'w-full rounded-lg px-3 py-2 text-sm border transition',\n    'bg-white dark:bg-slate-900',\n    'text-slate-900 dark:text-slate-100',\n    'placeholder:text-slate-400 dark:placeholder:text-slate-500',\n    this.error\n      ? 'border-red-500 dark:border-red-400'\n      : 'border-slate-200 dark:border-slate-700',\n    'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',\n    this.disabled ? 'opacity-50 cursor-not-allowed' : '',\n  ].filter(Boolean).join(' ');\n}\n```\n\n### Example \u2014 dropdown item list with dark mode\n\n```typescript\nprivate getItemClasses(item: ParsedItem, isSelected: boolean): string {\n  return [\n    'w-full rounded-md px-3 py-2 text-sm transition cursor-pointer',\n    isSelected\n      ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-500 dark:border-sky-400'\n      : 'text-slate-900 dark:text-slate-100 border border-transparent',\n    !item.disabled && !isSelected\n      ? 'hover:bg-slate-50 dark:hover:bg-slate-700'\n      : '',\n    item.disabled ? 'opacity-50 cursor-not-allowed' : '',\n  ].filter(Boolean).join(' ');\n}\n```\n\n### Example \u2014 error and helper text\n\n```typescript\nprivate renderFeedback(): TemplateResult {\n  if (this.error) {\n    return html\\`<p class=\"mt-1 text-xs text-red-600 dark:text-red-400\">\\${unsafeHTML(String(this.error))}</p>\\`;\n  }\n  if (this.hasSlot('Helper')) {\n    return html\\`<p class=\"mt-1 text-xs text-slate-500 dark:text-slate-400\">\\${unsafeHTML(this.getSlotContent('Helper'))}</p>\\`;\n  }\n  return html\\`\\`;\n}\n```\n\n---\n\n## 13. Component Template\n\n```typescript\n/// <mls fileReference=\"[file-reference]\" enhancement=\"_102020_/l2/enhancementAura\"/>\n\n// =============================================================================\n// [COMPONENT NAME] MOLECULE\n// =============================================================================\n// Skill Group: [group-name] (e.g., select + one)\n// This molecule does NOT contain business logic.\n\nimport { html, TemplateResult, classMap, nothing, unsafeHTML, ...(anothers if need) } from 'lit';\nimport { customElement, property, state } from 'lit/decorators';\nimport { propertyDataSource } from '_102027_/l2/collabDecorators';\nimport { MoleculeAuraElement } from '/_102020_/l2/moleculeBase';\n\n/// **collab_i18n_start**\nconst message_en = {\n  placeholder: 'Select an option',\n  noResults: 'No results found',\n  loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record<string, MessageType> = {\n  en: message_en,\n};\n/// **collab_i18n_end**\n\n@customElement('molecules--[component-name]-102020')\nexport class [ComponentName]Molecule extends MoleculeAuraElement {\n\n  private msg: MessageType = messages.en;\n\n  // ===========================================================================\n  // SLOT TAGS\n  // ===========================================================================\n\n  slotTags = ['Trigger', 'Value', 'Content', 'Group', 'Item', 'Empty'];\n\n  // ===========================================================================\n  // PROPERTIES \u2014 From Contract\n  // ===========================================================================\n  \n  @propertyDataSource({ type: String }) \n  value: string | null = null;\n\n  @property({ type: Boolean }) \n  disabled = false;\n\n  @property({ type: Boolean }) \n  readonly = false;\n\n  @property({ type: Boolean }) \n  loading = false;\n\n  @property({ type: Boolean }) \n  required = false;\n\n  @property({ type: String }) \n  error: string | boolean = false;\n\n  @property({ type: String }) \n  name = '';\n\n  // ===========================================================================\n  // INTERNAL STATE\n  // ===========================================================================\n  \n  @state() \n  private isOpen = false;\n\n  // ===========================================================================\n  // STATE CHANGE HANDLER (if needed for derived values)\n  // ===========================================================================\n\n  // handleIcaStateChange(key: string, value: any) {\n  //   const valueAttr = this.getAttribute('value');\n  //   if (valueAttr === \\`{{\\${key}}}\\`) {\n  //     // Recalculate derived values here\n  //   }\n  //   this.requestUpdate();\n  // }\n\n  // ===========================================================================\n  // EVENT HANDLERS\n  // ===========================================================================\n  \n  private handleSelect(value: string) {\n    if (this.disabled || this.readonly) return;\n\n    this.value = value;\n    this.isOpen = false;\n    \n    this.dispatchEvent(new CustomEvent('change', {\n      bubbles: true,\n      composed: true,\n      detail: { value }\n    }));\n  }\n\n  private handleBlur() {\n    this.dispatchEvent(new CustomEvent('blur', {\n      bubbles: true,\n      composed: true,\n    }));\n  }\n\n  // ===========================================================================\n  // RENDER\n  // ===========================================================================\n  \n  render() {\n    const lang = this.getMessageKey(messages);\n    this.msg = messages[lang];\n\n    if (this.loading) {\n      return html\\`<div class=\"loading\">\\${this.msg.loading}</div>\\`;\n    }\n\n    const placeholder = this.getSlotAttr('Value', 'placeholder') || this.msg.placeholder;\n\n    return html\\`\n        /// Implementation here\n    \\`;\n  }\n}\n```\n\n---\n\n## 14. Skill Groups\n\nEach molecule belongs to a **Skill Group** that defines its contract:\n\nThe contract defines:\n- **Properties** (value, disabled, etc.)\n- **Events** (change, blur, etc.)\n- **Slot Tags** (Trigger, Content, Item, etc.)\n- **Validation Rules**\n\n---\n\n\n## 15. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 03/23/2026 | Initial skill definition |\n| 2.0.0 | 04/01/2026 | Added Slot Tags system, contracts, interchangeability |\n| 2.1.0 | 04/02/2026 | Replaced classMap with template strings pattern for CSS classes |\n| 2.2.0 | 04/02/2026 | Added unsafeHTML for rendering Slot Tag content |\n| 2.3.0 | 04/02/2026 | Added naming rules: no protected/override, reserved method names |\n| 2.4.0 | 04/13/2026 | Added section 9: correct usage of `nothing` with proper return types |\n| 2.5.0 | 04/16/2026 | Added section 11: handleIcaStateChange for derived values |\n| 2.6.0 | 04/22/2026 | Added section 12: dark mode \u2014 semantic color pairs and required dark: variants |\n";
}
declare module "_102020_/l2/skills/aura/overview.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/overview" {
    export const skill = "\n## Skill \u2014 Frontend Architecture \u2014 Collab Aura\n\nThis document defines the official frontend architecture, design principles, and responsibilities for building applications using Collab Aura.\nAll components, pages, and integrations MUST follow these rules.\n\n## Core Architecture Principles\n### Atomic Design Structure\nThe frontend follows Atomic Design, with the following hierarchy:\n- Page \u2192 Top-level screen and orchestration layer\n- Organism \u2192 Complex UI sections composed of molecules and plugins\n- Molecule \u2192 Reusable UI components, presentation-only\n- Plugin \u2192 Integration components that communicate with external services\nEach level has a strict responsibility and separation of concerns.\n\n### Technology Stack\n- Use Lit 3 to build Web Components\n- Do NOT use Shadow DOM\n- Use Tailwind CSS for styling\n- Use SPA (Single Page Application) architecture\n- Each page corresponds to a URL entry point\n\n### Backend Communication Model\nFollow the BFF (Backend for Frontend) pattern.\nFrontend MUST communicate with backend routines using the BFF abstraction layer.\nAll backend communication MUST go through the frontend backend gateway (beInvoke or equivalent).\nDirect backend calls outside this abstraction are NOT allowed.\n\n### Data Fetching Strategy\nUse Stale-While-Revalidate (SWR) strategy for optimal perceived performance.\nThis means:\n- First attempt to load data from local IndexedDB (fast response)\n- Mark data consistency as \"stale\"\n- Then fetch fresh data from backend\n- Update state and IndexedDB when backend responds\n- Mark data consistency as \"fresh\"\nThis improves performance and user experience.\n\n## State Management\nGlobal state is used by pages and organisms.\nState naming:\nui.[pageName].[stateName]\nExamples:\nui.productDetail.product  \nui.productDetail.productConsistency  \nui.productDetail.onLoadMore  \nState types:\n- Data state \u2192 holds UI data\n- Event state \u2192 triggers actions (example: onUpdateUser)\nRules:\n- Pages MUST NOT pass data to organisms via properties, prefer states.\n- Molecules MUST NOT access global state.\n\n## Page Definitions\nA Page is a Web Component responsible for orchestrating the entire screen.\nResponsibilities:\n- Entry point of the user interface\n- Each page corresponds to a URL\n- Render the overall layout\n- Render organisms and plugins\n- Own business logic\n- Communicate with backend using BFF\n- Manage state lifecycle\n- Define state contracts for child organisms\n- Implement data fetching using SWR pattern\nPages MUST:\n- Follow business rules\n- Render SPA-compatible HTML\n- Render organisms and sections inside a root <div>\n- Orchestrate tabs and conditional content if needed\n- Update state based on backend responses\nPages MUST NOT:\n- Contain reusable UI logic that belongs in organisms\n- Contain reusable UI components that belong in molecules\nTesting:\nEach page MUST have a corresponding test file:\npageName.test.ts\nTests MUST verify:\n- Business logic\n- State transitions\n- Backend communication behavior\n\n## Organism Definitions\nOrganisms are Web Components responsible for rendering complex UI sections.\nResponsibilities:\n- Render layout sections\n- Combine molecules and plugins\n- Receive data via global states\n- Emit events via state updates\nOrganisms MUST:\n- Follow defined property contracts\n- Be reusable within the project\nOrganisms MUST NOT:\n- Communicate directly with backend\n- Own business logic\n- Fetch data\nTesting:\nEach organism MUST have:\norganismName.test.ts\nTests MUST verify:\n- Layout rendering\n- Property handling\n- State-driven rendering behavior\n\n## Molecule Definitions\nMolecules are reusable UI components.\nResponsibilities:\n- Render UI elements\n- Be highly reusable\n- Be presentation-only\nMolecules MUST:\n- Receive data only via properties\n- Be stateless regarding global application state\nMolecules MUST NOT:\n- Access global state\n- Communicate with backend\n- Contain business logic\n\n## Plugin Definitions\nPlugins are Web Components responsible for integrating with external services.\nExamples:\n- Payment platforms\n- External APIs\n- Third-party integrations\n- Analytics services\nPlugins MAY:\n- Communicate with external services\n- Provide integration functionality\nPlugins MUST NOT:\n- Contain core business logic of the application\n- Own application state\n\n## Folder and File Organization\nAll frontend files MUST follow this structure:\n_[projectId]_/l2/[moduleName]/[componentName].[extension]\nDefinitions:\n- projectId \u2192 numeric project identifier (example: 100111)\n- l2 \u2192 frontend layer\n- moduleName \u2192 module name or folder\n- componentName \u2192 component name using camelCase\n- extension \u2192 file type (ts, test.ts, defs.ts, css, etc.)\nImport rules:\n- Always use absolute project-based imports \nExample:\nimport \"/_100111_/l2/user/userProfileOrganism.js\";\n\nAll generated frontend code MUST strictly follow this architecture.\n";
}
declare module "_102020_/l2/skills/design/glassmorphism.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/glassmorphism" {
    export const skill = "\n\n# Skill: Glassmorphism\n\n## Philosophy\n> \"Depth through transparency. Light caught in layers.\"\n\nComponents float above a dark gradient canvas, simulating frosted glass. The background bleeds through every surface. Hierarchy is built with opacity and blur, not color or shadow.\n\n---\n\n## Canvas\n\nThis skill is **dark only**. Components must always render over a dark gradient canvas.\n\nThe canvas color palette is **free** \u2014 chosen by the implementer. What is required is the structure:\n\n```html\n<!-- Required canvas structure -->\n<div class=\"bg-gradient-to-br from-[your-color-950] via-[your-color-950] to-[your-color-950]\">\n\n  <!-- Ambient orbs: optional but recommended for depth -->\n  <div class=\"absolute w-96 h-96 rounded-full blur-3xl pointer-events-none bg-[--your-color]/20\" />\n  <div class=\"absolute w-80 h-80 rounded-full blur-3xl pointer-events-none bg-[your-color]/20\" />\n\n</div>\n```\n\n## Canvas rules\n- Background must be **dark** (`*-900` to `*-950` range)\n- Gradient must have **at least 2 stops** for depth\n- Ambient orbs use the same hue family as the gradient, at low opacity (`/15` to `/25`)\n- Orbs must be `pointer-events-none` and positioned absolutely\n\n> Components rendered without a dark canvas will lose their visual effect entirely.\n\n---\n\n## Tokens\n\n### Glass Surface (Moderate \u2014 default)\n| Token | Value |\n|---|---|\n| Background | `bg-white/10` |\n| Backdrop blur | `backdrop-blur-md` |\n| Border | `border border-white/20` |\n| Border highlight | `border-t-white/30` (top edge only) |\n| Inner glow | `shadow-inner shadow-white/5` |\n\n> **Intensity scale for reference:**\n> - Subtle: `bg-white/5` + `backdrop-blur-sm` + `border-white/10`\n> - **Moderate: `bg-white/10` + `backdrop-blur-md` + `border-white/20`** \u2190 default\n> - Intense: `bg-white/15` + `backdrop-blur-xl` + `border-white/30`\n\n### Color\n| Token | Value |\n|---|---|\n| Text Primary | `white` |\n| Text Secondary | `white/60` |\n| Text Muted | `white/40` |\n| Accent | inherits from canvas palette |\n| Danger | inherits from implementer |\n| Success | inherits from implementer |\n\n> All semantic colors are defined by the implementer. Use `*-300` or `*-400` lightness range to ensure legibility on dark backgrounds.\n\n### Typography\n| Token | Value |\n|---|---|\n| Font family | `font-sans` |\n| Body size | `text-base` |\n| Label size | `text-sm` |\n| Heading size | `text-xl` |\n| Body weight | `font-normal` |\n| Heading weight | `font-semibold` |\n| Heading tracking | `tracking-wide` |\n| Text rendering | `antialiased` |\n\n### Spacing\n| Token | Value |\n|---|---|\n| Component padding | `p-6` |\n| Element gap | `gap-4` |\n| Section gap | `gap-8` |\n\n### Shape\n| Token | Value |\n|---|---|\n| Border radius | `rounded-2xl` |\n| Border width | `border` (1px) |\n| Outer glow | `shadow-lg shadow-black/30` |\n\n### Interaction\n| State | Value |\n|---|---|\n| Hover (surface) | `hover:bg-white/15` |\n| Hover (border) | `hover:border-white/30` |\n| Focus ring | `focus-visible:ring-1 focus-visible:ring-white/50 focus-visible:ring-offset-0` |\n| Transition | `transition-all duration-200` |\n| Active | `active:bg-white/20` |\n\n> `ring-offset-0` is intentional \u2014 offset creates visual glitching on glass surfaces.\n\n---\n\n## Layering System\n\nGlass components gain depth through stacking. Use opacity to signal hierarchy:\n\n| Layer | bg | blur | border |\n|---|---|---|---|\n| Base (canvas) | gradient | \u2014 | \u2014 |\n| Card / Panel | `white/10` | `backdrop-blur-md` | `white/20` |\n| Elevated (modal, popover) | `white/15` | `backdrop-blur-lg` | `white/25` |\n| Tooltip / Badge | `white/20` | `backdrop-blur-sm` | `white/30` |\n\n---\n\n## Rules\n\n### \u2705 Do\n- Always render over a dark gradient canvas\n- Use `border-t-white/30` on the top edge to simulate light hitting glass\n- Use ambient orbs (`blur-3xl`) behind key components to add depth\n- Keep text `white` or `white/60` \u2014 never dark text on glass\n- Use `rounded-2xl` consistently\n- Prefer `transition-all` for smooth glass state changes\n- Use `pointer-events-none` on all decorative elements\n- Derive accent color from the canvas palette\n\n### \u274C Never\n- Render components on a white or light background\n- Use opaque backgrounds (`bg-zinc-900`, `bg-slate-800`, etc.)\n- Use colored borders \u2014 only `white/*` opacity borders\n- Use `ring-offset` on focus states\n- Use `font-bold` \u2014 weight feels heavy against transparent surfaces\n- Stack more than 3 glass layers\n- Use drop shadows with color \u2014 only `shadow-black/*`\n\n---\n\n## Iconography\n- Style: **outline / stroke**\n- Stroke width: `1.5`\n- Size: `size-5`\n- Color: `text-white/70` default, accent color for emphasis\n\n---\n\n## Tone\nEthereal. Expensive. Cinematic.  \nLight passes through every surface. The canvas is always part of the component.\n\n";
}
declare module "_102020_/l2/skills/design/minimalist.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/minimalist" {
    export const skill = "\n# Skill: Minimalist\n\n## Philosophy\n\n> \"The component exists. Nothing more.\"\n\nEverything that doesn't communicate is removed.  \nNo decorative shadows, no gradients, no unnecessary borders.  \nWhite space is not empty \u2014 it is the design itself.\n\n---\n\n## Tokens\n\n### Color\n\n| Token            | Light    | Dark     |\n|------------------|----------|----------|\n| Background       | zinc-50  | zinc-950 |\n| Surface          | white    | zinc-900 |\n| Border           | zinc-200 | zinc-800 |\n| Text Primary     | zinc-900 | zinc-50  |\n| Text Secondary   | zinc-500 | zinc-400 |\n| Accent           | zinc-900 | zinc-50  |\n\n**Note:**  \nAccent is the text itself. No separate accent color.\n\n---\n\n### Typography\n\n| Token             | Value                  |\n|-------------------|------------------------|\n| Font family       | font-sans (system-ui)  |\n| Body size         | text-base              |\n| Label size        | text-sm                |\n| Heading size      | text-lg                |\n| Body weight       | font-normal            |\n| Emphasis weight   | font-medium            |\n| Heading tracking  | tracking-tight         |\n\n**Rule:**  \nNever use `font-bold` or `font-semibold`.\n\n---\n\n### Spacing\n\n| Token             | Value                |\n|-------------------|----------------------|\n| Component padding | p-6 or p-8           |\n| Element gap       | gap-4 or gap-6       |\n| Section gap       | gap-8 or gap-12      |\n\n**Rule:**  \nWhen in doubt, add more space.\n\n---\n\n### Shape\n\n| Token         | Value                                      |\n|---------------|--------------------------------------------|\n| Border radius | rounded-none or rounded-sm                 |\n| Border width  | border (1px)                               |\n| Border color  | border-zinc-200 / dark:border-zinc-800     |\n| Shadow        | none                                       |\n\n---\n\n### Interaction\n\n| State        | Value                                                                 |\n|--------------|-----------------------------------------------------------------------|\n| Hover (bg)   | hover:bg-zinc-100 / dark:hover:bg-zinc-800                           |\n| Hover (text) | hover:text-zinc-600                                                  |\n| Focus ring   | focus-visible:ring-1 focus-visible:ring-zinc-900 focus-visible:ring-offset-2 |\n| Transition   | transition-colors duration-150                                       |\n| Active       | active:bg-zinc-200                                                   |\n\n**Rule:**  \nNo scale, translate, or transform effects.\n\n---\n\n## Rules\n\n### \u2705 Do\n\n- Use generous white space as a design element  \n- Use zinc scale exclusively for neutrals  \n- Separate sections with space, not dividers  \n- Use line-style icons (stroke, not fill)  \n- Keep a single level of visual hierarchy per component  \n- Prefer border over shadows for surface separation  \n\n### \u274C Never\n\n- Decorative shadows (`shadow-*`)  \n- Gradients (`bg-gradient-*`)  \n- Vibrant or saturated colors  \n- Large border radius (`rounded-lg` or above)  \n- `font-bold` or `font-semibold`  \n- Filled or colorful icons  \n- Animations beyond `transition-colors`  \n- More than 2 font sizes in a single component  \n\n---\n\n## Iconography\n\n- **Style:** outline / stroke  \n- **Stroke width:** 1 or 1.5 (never 2+)  \n- **Size:** size-4 or size-5  \n- **Color:** inherits from text (`currentColor`)  \n\n---\n\n## Tone\n\nCold. Precise. Confident through restraint.  \nThe absence of decoration is the statement.\n";
}
declare module "_102020_/l2/skills/molecules/groupViewData.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupViewData" {
    export const skill = "\n# Skill: view + data\n\n## Metadata\n\n- **Name:** viewData\n- **Version:** 1.1.0\n- **Category:** Data Display\n- **Last Updated:** 13/04/2026\n\n---\n\n## Short Description\n\n> **view + data**: Adaptive visualization of data collection. Display multiple records with defined fields and rich content. The component implementation decides the best presentation format.\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize a collection of data**. The group defines the data structure (columns, rows, cells), and each component implementation decides how to render it.\n\n### When to Use\n\n- Display collection of records\n- Multiple fields per record\n- Rich content in cells (badges, actions, composed layouts)\n- When you need a standardized data structure\n\n### When NOT to Use\n\n- Single metrics \u2192 use **view + metric**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Charts/graphs \u2192 use **view + chart**\n\n### Possible Implementations\n\n- Data Table\n- Card Grid\n- List View\n- Responsive View (adapts to viewport)\n- Compact Table\n- Kanban Board\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `selectable` | `boolean` | `false` | | `@property` | Enables row/item selection |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight on hover |\n\n> **Note:** Additional properties may be added by specific implementations (e.g., `striped`, `bordered` for table implementations).\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, data: Element }` | Fired when a row/item is clicked |\n| `selection-change` | `{ selected: number[] }` | Fired when selection changes |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n**Important:** Use ONLY the tags defined below. Do NOT create custom tags.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<Columns>` | \u2713 | Container for column definitions |\n| `<Column>` | \u2713 (min. 1) | Defines a column/field |\n| `<Rows>` | \u2713 | Container for data rows |\n| `<Row>` | \u2713 (min. 1) | A data row/item |\n| `<Cell>` | \u2713 | A data cell |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n---\n\n### `<Columns>`\n\nContainer for column definitions. **Required.**\n\n**Accepts:** `<Column>`\n\n```html\n<Columns>\n  <Column field=\"id\" header=\"ID\" />\n  <Column field=\"name\" header=\"Name\" />\n</Columns>\n```\n\n---\n\n### `<Column>`\n\nDefines a column/field. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `field` | `string` | \u2713 | Field identifier (for reference) |\n| `header` | `string` | \u2713 | Header/label text |\n| `width` | `string` | | Suggested width (e.g., \"100px\", \"20%\") |\n| `align` | `'left' | 'center' | 'right'` | | Content alignment |\n| `hidden` | `boolean` | | Hides the column |\n\n**Accepts:** None (self-closing)\n\n```html\n<Column field=\"id\" header=\"Order ID\" width=\"120px\" />\n<Column field=\"status\" header=\"Status\" align=\"center\" />\n<Column field=\"internal\" header=\"Internal\" hidden />\n```\n\n---\n\n### `<Rows>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<Row>`\n\n```html\n<Rows>\n  <Row>...</Row>\n  <Row>...</Row>\n</Rows>\n```\n\n---\n\n### `<Row>`\n\nA data row/item. **Required** (minimum 1 for non-empty state).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `selected` | `boolean` | | Marks row as selected |\n| `disabled` | `boolean` | | Disables row interaction |\n\n**Accepts:** `<Cell>`\n\n```html\n<Row>\n  <Cell>Value 1</Cell>\n  <Cell>Value 2</Cell>\n</Row>\n\n<Row selected>\n  <Cell>Selected Row</Cell>\n</Row>\n\n<Row disabled>\n  <Cell>Disabled Row</Cell>\n</Row>\n```\n\n---\n\n### `<Cell>`\n\nA data cell. **Required** (should match number of Columns).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n\n**Accepts:** Any content (text, elements, components)\n\n```html\n<!-- Simple text -->\n<Cell>John Doe</Cell>\n\n<!-- Composed content -->\n<Cell>\n  <div class=\"font-medium\">William Little</div>\n  <div class=\"text-sm text-slate-500\">william@email.com</div>\n</Cell>\n\n<!-- Badge -->\n<Cell>\n  <span class=\"badge badge-success\">Active</span>\n</Cell>\n\n<!-- Actions -->\n<Cell>\n  <div class=\"flex gap-2\">\n    <button>Edit</button>\n    <button>Delete</button>\n  </div>\n</Cell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <div class=\"text-center py-8\">\n    <span class=\"text-4xl\">\uD83D\uDCED</span>\n    <p class=\"mt-2 text-slate-500\">No records found</p>\n  </div>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when `loading` property is true.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <div class=\"text-center py-8\">\n    <Spinner />\n    <p class=\"mt-2\">Loading...</p>\n  </div>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Columns>\n\u2502   \u2514\u2500\u2500 <Column>\n\u251C\u2500\u2500 <Rows>\n\u2502   \u2514\u2500\u2500 <Row>\n\u2502       \u2514\u2500\u2500 <Cell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Columns>` | root |\n| `<Column>` | `<Columns>` |\n| `<Rows>` | root |\n| `<Row>` | `<Rows>` |\n| `<Cell>` | `<Row>` |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<Columns>` missing | error | `Missing required slot <Columns>` |\n| `<Rows>` missing | error | `Missing required slot <Rows>` |\n| No `<Column>` in Columns | error | `At least 1 <Column> is required inside <Columns>` |\n| `<Column>` without `field` | error | `<Column> requires attribute \"field\"` |\n| `<Column>` without `header` | error | `<Column> requires attribute \"header\"` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n\n---\n\n## Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal state |\n| **hover** | Mouse over (if hoverable) |\n| **selected** | Row is selected |\n| **disabled** | Row interaction disabled |\n\n---\n\n## Accessibility (Recommended)\n\n| Attribute | Application |\n|-----------|-------------|\n| `aria-busy` | When loading is true |\n| `aria-selected` | On selected rows |\n| `aria-disabled` | On disabled rows |\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 13/04/2026 | Initial contract definition |\n| 1.1.0 | 13/04/2026 | Removed view-specific properties. Focus on data structure only |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupViewTable.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupViewTable" {
    export const skill = "\n\n# Skill: view + table\n\n## Metadata\n\n- **Name:** viewTable\n- **Version:** 1.0.0\n- **Category:** Data Display\n- **Last Updated:** 04/02/2026\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to **visualize structured data** in tabular format.\n\n### When to Use\n\n- Display list of records\n- Compare data across columns\n- Show structured information\n- CRUD interfaces\n\n### When NOT to Use\n\n- Few items with visual identity \u2192 use **view + cards**\n- Hierarchical data \u2192 use **view + hierarchy**\n- Single metrics \u2192 use **view + metric**\n\n### Possible Implementations\n\n- Data Table (full-featured)\n- Table (simple display)\n- Editable Grid\n- Virtualized Table\n- Tree Table\n\n---\n\n## Contract\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| `loading` | `boolean` | `false` | | `@property` | Shows loading state |\n| `striped` | `boolean` | `false` | | `@property` | Zebra-striped rows |\n| `hoverable` | `boolean` | `true` | | `@property` | Highlight row on hover |\n| `bordered` | `boolean` | `false` | | `@property` | Borders on all cells |\n| `compact` | `boolean` | `false` | | `@property` | Reduced padding |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| `@property` | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| `row-click` | `{ index: number, row: Element }` | Fired when a row is clicked |\n\n---\n\n## Slot Tags\n\nSlot tags are **unknown HTML elements** (not registered Custom Elements). The parent component reads and interprets these tags to build its structure.\n\n### Summary\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `<TableHeader>` | \u2713 | Header section container |\n| `<TableBody>` | \u2713 | Body section container |\n| `<TableRow>` | \u2713 | A table row |\n| `<TableHead>` | \u2713 | Header cell |\n| `<TableCell>` | \u2713 | Data cell |\n| `<TableFooter>` | | Footer section container |\n| `<Caption>` | | Table caption/title |\n| `<Empty>` | | Empty state content |\n| `<Loading>` | | Loading state content |\n\n\n### `<Caption>`\n\nTable caption or title. Usually displayed above the table.\n\n**Accepts:** Any content (text, elements)\n\n```html\n<Caption>List of Users</Caption>\n```\n\n---\n\n### `<TableHeader>`\n\nContainer for header rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableHeader>\n  <TableRow>\n    <TableHead>Name</TableHead>\n    <TableHead>Email</TableHead>\n  </TableRow>\n</TableHeader>\n```\n\n---\n\n### `<TableBody>`\n\nContainer for data rows. **Required.**\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableBody>\n  <TableRow>\n    <TableCell>John Doe</TableCell>\n    <TableCell>john@email.com</TableCell>\n  </TableRow>\n</TableBody>\n```\n\n---\n\n### `<TableFooter>`\n\nContainer for footer rows.\n\n**Accepts:** `<TableRow>`\n\n```html\n<TableFooter>\n  <TableRow>\n    <TableCell colspan=\"2\">Total: 100 records</TableCell>\n  </TableRow>\n</TableFooter>\n```\n\n---\n\n### `<TableRow>`\n\nA table row. **Required** (minimum 1 in header and body).\n\n**Accepts:** `<TableHead>` (inside TableHeader) or `<TableCell>` (inside TableBody/TableFooter)\n\n```html\n<TableRow>\n  <TableCell>Data 1</TableCell>\n  <TableCell>Data 2</TableCell>\n</TableRow>\n```\n\n---\n\n### `<TableHead>`\n\nA header cell. **Required** (minimum 1).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, icons, sort indicators)\n\n```html\n<TableHead>Name</TableHead>\n<TableHead colspan=\"2\">Contact Info</TableHead>\n```\n\n---\n\n### `<TableCell>`\n\nA data cell. **Required** (minimum 1 per row).\n\n| Attribute | Type | Required | Description |\n|-----------|------|:--------:|-------------|\n| `colspan` | `number` | | Span multiple columns |\n| `rowspan` | `number` | | Span multiple rows |\n\n**Accepts:** Any content (text, badges, buttons, etc.)\n\n```html\n<TableCell>John Doe</TableCell>\n<TableCell>\n  <Badge>Active</Badge>\n</TableCell>\n<TableCell>\n  <Button size=\"sm\">Edit</Button>\n</TableCell>\n```\n\n---\n\n### `<Empty>`\n\nDisplayed when there are no rows in the table.\n\n**Accepts:** Any content\n\n```html\n<Empty>\n  <Icon name=\"inbox\" />\n  <span>No records found</span>\n</Empty>\n```\n\n---\n\n### `<Loading>`\n\nDisplayed when the table is in loading state.\n\n**Accepts:** Any content\n\n```html\n<Loading>\n  <Spinner />\n  <span>Loading data...</span>\n</Loading>\n```\n\n---\n\n## Slot Hierarchy\n\n```\ncomponent (root)\n\u2502\u2500\u2500 <Caption>\n\u2502\u2500\u2500 <TableHeader>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableHead>\n\u2502\u2500\u2500 <TableBody>\n\u2502   \u2514\u2500\u2500 <TableRow>\n\u2502       \u2514\u2500\u2500 <TableCell>\n\u2502\u2500\u2500 <TableFooter>\n\u2502       \u2514\u2500\u2500 <TableRow>\n\u2502           \u2514\u2500\u2500 <TableCell>\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Loading>\n```\n\n| Tag | Valid Parents |\n|-----|---------------|\n| `<Caption>` | `<Table>` |\n| `<TableHeader>` | `<Table>` |\n| `<TableBody>` | `<Table>` |\n| `<TableFooter>` | `<Table>` |\n| `<TableRow>` | `<TableHeader>`, `<TableBody>`, `<TableFooter>` |\n| `<TableHead>` | `<TableRow>` (inside TableHeader) |\n| `<TableCell>` | `<TableRow>` (inside TableBody or TableFooter) |\n| `<Empty>` | root |\n| `<Loading>` | root |\n\n---\n\n## Validation Rules\n\n### Slot Validation\n\n| Rule | Type | Message |\n|------|------|---------|\n| `<TableHeader>` missing | error | `Missing required slot <TableHeader>` |\n| `<TableBody>` missing | error | `Missing required slot <TableBody>` |\n| No `<TableRow>` in header | error | `At least 1 <TableRow> is required inside <TableHeader>` |\n| No `<TableHead>` in header row | error | `At least 1 <TableHead> is required inside header <TableRow>` |\n| Unknown tag found | warning | `Unknown slot <TagName> ignored` |\n| Tag in invalid position | warning | `<TagName> is not valid inside <ParentTag>, ignored` |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Normal display | Shows table with data |\n| **loading** | Loading data | Shows loading indicator, hides body |\n| **empty** | No data | Shows empty state message |\n| **striped** | Zebra rows | Alternating row background colors |\n| **hoverable** | Row hover | Highlight row on mouse over |\n\n### Row States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal row |\n| **hover** | Mouse over row |\n| **selected** | Row is selected (if selection enabled) |\n\n### Cell States\n\n| State | Description |\n|-------|-------------|\n| **default** | Normal cell |\n| **truncated** | Content overflow with ellipsis |\n\n---\n\n## Accessibility (Recommended)\n\n### Semantic Structure\n\n| Element | Renders As |\n|---------|------------|\n| `<Caption>` | `<caption>` |\n| `<TableHeader>` | `<thead>` |\n| `<TableBody>` | `<tbody>` |\n| `<TableFooter>` | `<tfoot>` |\n| `<TableRow>` | `<tr>` |\n| `<TableHead>` | `<th scope=\"col\">` |\n| `<TableCell>` | `<td>` |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| `role=\"table\"` | Applied automatically via semantic HTML |\n| `aria-busy` | When loading is true |\n| `aria-rowcount` | Total number of rows (if known) |\n| `aria-colcount` | Total number of columns |\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| `Tab` | Move between interactive elements in cells |\n| `Arrow Keys` | Navigate between cells (if cell navigation enabled) |\n\n---\n\nEach implementation decides internally:\n- Visual styling (spacing, borders, colors)\n- Additional features (sorting, filtering, pagination)\n- How it renders each slot tag\n\nThe contract ensures **structural compatibility** across all implementations in the group.\n\n---\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 04/02/2026 | Initial contract definition |\n";
}
declare module "_102020_/l2/skills/molecules/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/index" {
    export const skills: {
        name: string;
        description: string;
        skillReference: string;
        skillUsageReference: string;
    }[];
}
declare module "_102020_/l2/skills/molecules/playgroundGenerator.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/playgroundGenerator" {
    export const skill = "\n# Skill \u2014 Molecule Playground Generator\n> Gera p\u00E1ginas HTML interativas de demonstra\u00E7\u00E3o para Molecules do sistema Collab Aura.\n\n---\n## 1. Metadata\n\n| Field       | Value                              |\n|-------------|------------------------------------|\n| **Name**    | `moleculePlaygroundGenerator`    |\n| **Version** | `2.6.0`                          |\n\n---\n\n## 2. Tag Name \u2014 CRITICAL RULE\n\n**Extract the component tag name MUST be copied verbatim from the `@customElement(...)` decorator in the `.ts` file.**\nUse same tag in playground example\n\n### Rules\n\n- **Never derive** the tag name from the file name, class name, or folder path\n- **Never reconstruct** the tag name using the naming convention formula\n- **Always read** the `@customElement(...)` value from the `.ts` source\n- Opening tag and closing tag MUST be **identical strings**\n\n### Why\n\nThe naming convention formula (`kebab-case(folder)--kebab-case(component)-(projectId)`) is used when **creating** a new molecule. When **generating a playground** for an existing molecule, the tag already exists in the `.ts` \u2014 use it directly.\n\n---\n\n## 3. Property Analysis (was \u00A72)\n\n### 2.1 Classifica\u00E7\u00E3o por Decorator\n\n| Decorator | Vai no State? | Binding |\n|-----------|---------------|---------|\n| `@propertyDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@propertyCompositeDataSource` | \u2713 SIM | `{{playground.demo.prop}}` |\n| `@property` | \u2717 N\u00C3O | Valor direto |\n| `@state` | \u2717 N\u00C3O | N\u00E3o aparece |\n\n## Attribute Names in HTML (non-string properties)\n\nProperties decorated with `@propertyDataSource` that have type `Boolean`, `Number`, or `Object` and a camelCase name **must use the kebab-case `attribute` name in HTML**, not the TypeScript property name.\n\nAlways check the decorator in the `.ts` file to find the correct attribute name:\n\n```typescript\n// Declared in the .ts\n@propertyDataSource({ type: Boolean, attribute: 'is-editing' })\nisEditing: boolean = false;\n\n@propertyDataSource({ type: Number, attribute: 'max-length' })\nmaxLength: number | null = null;\n```\n\n```html\n<!-- \u274C WRONG \u2014 TypeScript property name used as HTML attribute -->\n<molecules--my-component-102020 isEditing=\"true\" maxLength=\"100\">\n\n<!-- \u2705 CORRECT \u2014 kebab-case attribute name from the decorator -->\n<molecules--my-component-102020 is-editing=\"true\" max-length=\"100\">\n```\n\nThis applies to all HTML in the playground: `<demo>` element and `<template>` block.\n\n---\n\n## 4. State\n\n### 3.1 Formato\n\n```html\n<widget-playground-state-102020 state='{\"playground\":{\"basic\":{\"value\":0,\"error\":\"\"}}}'>\n</widget-playground-state-102020>\n```\n\n### 3.2 Posi\u00E7\u00E3o no HTML\n\nO `widget-playground-state-102020` DEVE vir ANTES de qualquer demo no HTML.\n\n### 3.3 Regras\n\n- JSON v\u00E1lido\n- Uma linha\n- Apenas propriedades @propertyDataSource\n- Sempre usar valores default (nunca null ou undefined)\n\n### 3.4 Valores Default por Tipo\n\n| Tipo | Default |\n|------|---------|\n| string | `\"\"` |\n| number | `0` |\n| boolean | `false` |\n\n---\n\n## 5. Property Editors\n\n### 4.1 Widget por Tipo\n\n| Tipo da Propriedade | Widget |\n|---------------------|--------|\n| string | `widget-playground-state-text-102020` |\n| string | null | `widget-playground-state-text-102020` |\n| number | `widget-playground-state-number-102020` |\n| number | null | `widget-playground-state-number-102020` |\n| boolean | `widget-playground-state-boolean-102020` |\n\n### 4.2 Exemplos\n\n**String:**\n```html\n<widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n```\n\n**Number:**\n```html\n<widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n```\n\n**Boolean:**\n```html\n<widget-playground-state-boolean-102020 label=\"showIcon\" value=\"{{playground.basic.showIcon}}\"></widget-playground-state-boolean-102020>\n```\n\n---\n\n## 6. Styling (Tailwind)\n\nAll elements MUST include `dark:` variants so the playground renders correctly in both light and dark themes.\n\n| Elemento | Classes |\n|----------|---------|\n| Page root | `bg-white dark:bg-slate-900 min-h-screen` |\n| Container | `mx-auto p-8 font-sans` |\n| Header | `text-center mb-12` |\n| Title | `text-3xl font-semibold text-slate-800 dark:text-slate-100 mb-2` |\n| Badge | `inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 rounded-full text-sm font-medium` |\n| Grid | `grid grid-cols-1 md:grid-cols-2 gap-6 mb-12` |\n| Card | `bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6` |\n| Card Title | `text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4` |\n| Details | `mt-4` |\n| Summary | `cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400` |\n| Details Content | `mt-2 p-4 border border-slate-200 dark:border-slate-700 rounded-lg dark:bg-slate-900` |\n\n---\n\n## 7. HTML Structure\n\n### 6.1 Ordem dos Elementos\n\n1. Container\n2. Header\n3. `widget-playground-state-102020` (SEMPRE antes das demos)\n4. Section com demos\n\n### 6.2 Demo Card\n\n```html\n<div class=\"bg-white dark:bg-slate-900 min-h-screen\">\n<div class=\"mx-auto p-8 font-sans\">\n\n  <header class=\"text-center mb-12\">\n    <h1 class=\"text-3xl font-semibold text-slate-800 dark:text-slate-100 mb-2\">Component Name</h1>\n    <span class=\"inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 rounded-full text-sm font-medium\">skill group</span>\n  </header>\n\n  <widget-playground-state-102020 state='{\"playground\":{\"basic\":{\"value\":0,\"error\":\"\"}}}'>\n  </widget-playground-state-102020>\n\n  <section class=\"grid grid-cols-1 md:grid-cols-2 gap-6 mb-12\">\n    <article class=\"bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-6\">\n      <h3 class=\"text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4\">Basic</h3>\n      <demo id=\"demo-basic\">\n        <molecules--component-102020 \n          value=\"{{playground.basic.value}}\"\n          error=\"{{playground.basic.error}}\"\n          disabled=\"false\"\n          is-editing=\"true\">\n          <Label>Field</Label>\n        </molecules--component-102020>\n      </demo>\n      <details class=\"mt-4\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400\">Properties</summary>\n        <div class=\"mt-2 p-4 border border-slate-200 dark:border-slate-700 rounded-lg dark:bg-slate-900\">\n          <widget-playground-state-number-102020 label=\"value\" value=\"{{playground.basic.value}}\"></widget-playground-state-number-102020>\n          <widget-playground-state-text-102020 label=\"error\" value=\"{{playground.basic.error}}\"></widget-playground-state-text-102020>\n        </div>\n      </details>\n      <details class=\"mt-2\">\n        <summary class=\"cursor-pointer text-sm font-medium text-slate-500 dark:text-slate-400\">HTML</summary>\n        <div class=\"mt-2\">\n          <widget-playground-state-preview-code-102020 target=\"demo-basic\">\n            <template>\n<molecules--component-102020 \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\"\n  disabled=\"false\"\n  is-editing=\"true\">\n  <Label>Field</Label>\n</molecules--component-102020>\n            </template>\n          </widget-playground-state-preview-code-102020>\n        </div>\n      </details>\n    </article>\n  </section>\n\n</div>\n</div>\n```\n\n### 6.3 Demo Element\n\nO elemento `<demo>` DEVE:\n- Ter um `id` \u00FAnico (ex: demo-basic, demo-disabled)\n- Conter o HTML do componente (funciona independente do editor)\n\n```html\n<demo id=\"demo-basic\">\n  <molecules--component-102020 \n    value=\"{{playground.basic.value}}\"\n    error=\"{{playground.basic.error}}\">\n    <Label>Field</Label>\n  </molecules--component-102020>\n</demo>\n```\n\n### 6.4 HTML Editor Widget\n\nO `widget-playground-state-preview-code-102020` recebe:\n- `target`: id do elemento demo (para atualizar ao editar)\n- `<template>`: c\u00F3digo HTML fonte (para exibir formatado no editor)\n\n**IMPORTANTE:** O HTML deve estar duplicado - no `<demo>` E no `<template>`.\n\n```html\n<widget-playground-state-preview-code-102020 target=\"demo-basic\">\n  <template>\n<molecules--component-102020 \n  value=\"{{playground.basic.value}}\"\n  error=\"{{playground.basic.error}}\">\n  <Label>Field</Label>\n</molecules--component-102020>\n  </template>\n</widget-playground-state-preview-code-102020>\n```\n\nO widget:\n1. L\u00EA o HTML do `<template>` (c\u00F3digo fonte, n\u00E3o compilado)\n2. Exibe formatado no editor com syntax highlighting\n3. Ao editar, atualiza o innerHTML do `<demo>` target em tempo real\n\n---\n\n## 8. Demos\n\n| Demo | Namespace | @property |\n|------|-----------|-----------|\n| Basic | playground.basic | defaults |\n| Disabled | playground.disabled | disabled=\"true\" |\n| Loading | playground.loading | loading=\"true\" |\n| Error | playground.error | defaults |\n| View Mode | playground.viewMode | isEditing=\"false\" |\n\n---\n\n## 9. Checklist\n\n- [ ] Tag name copied verbatim from `@customElement(...)` in the `.ts` file\n- [ ] Opening tag and closing tag are identical strings\n- [ ] State cont\u00E9m APENAS @propertyDataSource\n- [ ] State \u00E9 JSON v\u00E1lido\n- [ ] State usa valores default (string=\"\", number=0, boolean=false)\n- [ ] State NUNCA usa null ou undefined\n- [ ] widget-playground-state-102020 vem ANTES das demos\n- [ ] Cada demo tem namespace pr\u00F3prio\n- [ ] Cada `<demo>` tem id \u00FAnico e cont\u00E9m o HTML do componente\n- [ ] string \u2192 widget-playground-state-text-102020\n- [ ] number \u2192 widget-playground-state-number-102020\n- [ ] boolean \u2192 widget-playground-state-boolean-102020\n- [ ] HTML duplicado: no `<demo>` E no `<template>` do editor\n- [ ] `<demo>` sem class/style\n- [ ] Page root tem `dark:bg-slate-900`\n- [ ] Todos os elementos de cor t\u00EAm variante `dark:`\n\n---\n\n## 10. Changelog\n\n| Version | Date       | Description |\n|---------|------------|-------------|\n| 2.1.0   | 2026-04-15 | Using dedicated widgets with -102020 suffix |\n| 2.2.0   | 2026-04-16 | Added HTML editor widget for live code editing |\n| 2.3.0   | 2026-04-16 | HTML editor uses template element for source code |\n| 2.4.0   | 2026-04-16 | HTML duplicated in demo AND template - demo works independently |\n| 2.5.0   | 2026-04-17 | Added \u00A72 explicit rule: tag name must be copied from @customElement, never derived |\n| 2.6.0   | 2026-04-22 | Added dark mode: dark: variants on all styling elements, page root wrapper, updated Demo Card example and checklist |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/creation" {
    export const skill = "\n\n# enter + date \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + date** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + date` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | ISO 8601 date string (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `minDate` | `string` | `''` | `@propertyDataSource` | Minimum allowed date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | `@propertyDataSource` | Maximum allowed date (`\"YYYY-MM-DD\"`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n| `firstDayOfWeek` | `number` | `0` | `@propertyDataSource` | First day of week: 0=Sunday, 1=Monday |\n| `showWeekNumbers` | `boolean` | `false` | `@propertyDataSource` | Show week numbers in the calendar |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Calendar panel is open |\n| `viewMonth` | `number` | current | `@state` | Month currently displayed in calendar |\n| `viewYear` | `number` | current | `@state` | Year currently displayed in calendar |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored as **ISO 8601 date**: `\"YYYY-MM-DD\"`\n- **No time component** \u2014 never store or emit time information\n- `null` represents no value selected\n\n### Display Format\n\n| Locale | Stored | Displayed |\n|--------|--------|-----------|\n| `en-US` | `\"2026-04-17\"` | `04/17/2026` |\n| `pt-BR` | `\"2026-04-17\"` | `17/04/2026` |\n| `de-DE` | `\"2026-04-17\"` | `17.04.2026` |\n| `en-GB` | `\"2026-04-17\"` | `17/04/2026` |\n\n### View Mode\n\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | User selected or cleared a date |\n| `monthChange` | `{ year: number, month: number }` | \u2713 | Calendar navigated to a different month |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"2026-04-17\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input trigger + calendar panel |\n| **View** | `false` | Renders formatted date as static text |\n\n- In view mode: no input, no calendar, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Open** | Calendar panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no calendar |\n\n---\n\n## 9. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render formatted date string or \"\u2014\"\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'):\n     - Render label\n     - IF required: add indicator (*)\n\n  3. Input trigger:\n     - Show formatted value or placeholder\n     - Calendar icon\n     - onClick: toggle isOpen\n\n  4. IF loading: render loading indicator, do NOT open calendar\n\n  5. IF isOpen:\n     - Month/year navigation header (prev/next arrows)\n     - Weekday headers (respecting firstDayOfWeek)\n     - Day grid:\n       - Highlight today\n       - Highlight selected date\n       - Disable days outside minDate/maxDate\n     - IF showWeekNumbers: render week number column\n     - Clear action\n     - On day click: set value, emit change, close calendar\n     - On outside click: close without change\n     - On month navigate: emit monthChange, update viewMonth/viewYear\n\n  6. Below trigger:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 10. Value Handling\n\n### Parsing\n\n- Calendar day selection \u2192 `\"YYYY-MM-DD\"` string\n- Never derive or append a time component\n\n### minDate / maxDate\n\n- Disable calendar days that fall outside the allowed range\n- Prevent navigation to months entirely before `minDate` or after `maxDate`\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Calendar dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n| Month heading | `aria-live=\"polite\"` |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Date Picker** | Input trigger + calendar popup |\n| **Date Input** | Masked text input (`MM/DD/YYYY`) |\n| **Calendar Inline** | Always-visible calendar, no popup |\n| **Month Picker** | Select month + year only, no day |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDate/usage" {
    export const skill = "\n\n# enter + date \u2014 Usage\n\n> Quick reference for using molecules in the **enter + date** group.\n> Use this when you need the user to provide a **date only (no time)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `minDate` | `string` | `''` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `firstDayOfWeek` | `number` | `0` | First day of week: `0` = Sunday, `1` = Monday |\n| `showWeekNumbers` | `boolean` | `false` | Show week numbers in the calendar |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user selects or clears a date |\n| `monthChange` | `{ year: number, month: number }` | Fired when the calendar navigates to a different month |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted as **ISO 8601 date**: `\"YYYY-MM-DD\"`\n- `null` when no value is selected\n- No time component is ever stored or emitted\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--date-input-102020\n  value=\"{{ui.form.birthDate}}\"\n  error=\"{{ui.form.birthDateError}}\"\n  locale=\"en-US\"\n  required>\n  <Label>Date of Birth</Label>\n</molecules--date-input-102020>\n```\n\n### With min/max and helper\n\n```html\n<molecules--date-input-102020\n  value=\"{{ui.form.dueDate}}\"\n  error=\"{{ui.form.dueDateError}}\"\n  locale=\"pt-BR\"\n  minDate=\"2026-01-01\"\n  maxDate=\"2026-12-31\"\n  required>\n  <Label>Due Date</Label>\n  <Helper>Select a date within the current year</Helper>\n</molecules--date-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/creation" {
    export const skill = "\n# enter + date-interval \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + date-interval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + date-interval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start date input |\n| `LabelEnd` | No | Label for the end date input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startDate` | `string | null` | `null` | `@propertyDataSource` | Start date (`\"YYYY-MM-DD\"`) |\n| `endDate` | `string | null` | `null` | `@propertyDataSource` | End date (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `minDate` | `string` | `''` | `@propertyDataSource` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | `@propertyDataSource` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `minRangeDays` | `number` | `0` | `@propertyDataSource` | Minimum range in days (0 = no minimum) |\n| `maxRangeDays` | `number` | `0` | `@propertyDataSource` | Maximum range in days (0 = no maximum) |\n| `firstDayOfWeek` | `number` | `0` | `@propertyDataSource` | First day of week: 0=Sunday, 1=Monday |\n| `allowSameDay` | `boolean` | `true` | `@propertyDataSource` | Allow start and end on the same day |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both dates are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Calendar panel is open |\n| `selectingEnd` | `boolean` | `false` | `@state` | Currently in end-date selection phase |\n| `hoverDate` | `string | null` | `null` | `@state` | Date being hovered during range selection |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `startDate` and `endDate` are always ISO 8601 date strings: `\"YYYY-MM-DD\"`\n- **No time component** \u2014 never store or emit time information\n- `null` means the date has not been selected yet\n- `endDate` must always be \u2265 `startDate` (enforced by the component)\n\n### Display Format\n\n| Locale | Range | Displayed |\n|--------|-------|-----------|\n| `en-US` | `\"2026-04-01\"` \u2192 `\"2026-04-30\"` | `04/01/2026 \u2013 04/30/2026` |\n| `pt-BR` | `\"2026-04-01\"` \u2192 `\"2026-04-30\"` | `01/04/2026 \u2013 30/04/2026` |\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startDate` is set: display `\"startDate \u2013 \u2014\"`\n- If both are set: display full formatted range\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startDate: string | null, endDate: string | null }` | \u2713 | Both dates confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start date changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End date changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\n// Emit individual change\nthis.dispatchEvent(new CustomEvent('startChange', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.startDate }\n}));\n\n// Emit consolidated change when both are confirmed\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { startDate: this.startDate, endDate: this.endDate }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two date inputs + range calendar |\n| **View** | `false` | Renders formatted date range as static text |\n\n- In view mode: no inputs, no calendar, no events, no error, no helper\n\n---\n\n## 7. Selection Flow\n\n```\n1. User clicks/focuses the trigger\n2. Calendar opens \u2014 selectingEnd = false\n3. User clicks start date:\n   - startDate is set\n   - endDate = null\n   - selectingEnd = true\n   - emit startChange\n4. User hovers dates \u2192 range preview highlighted (startDate to hoverDate)\n5. User clicks end date:\n   - IF clicked date >= startDate: set endDate, emit endChange + change\n   - IF clicked date < startDate: swap \u2014 new startDate = clicked, endDate = old startDate\n   - selectingEnd = false\n   - close calendar\n```\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Selecting** | Start selected, range preview on hover |\n| **Complete** | Both dates set, range highlighted |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 10. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render \"startDate \u2013 endDate\" formatted or \"\u2014\"\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render overall label\n\n  3. Two date trigger inputs side by side:\n     - Left: LabelStart + startDate formatted or placeholder\n     - Right: LabelEnd + endDate formatted or placeholder\n     - Calendar icons on each\n\n  4. IF loading: render loading indicator, do NOT open calendar\n\n  5. IF isOpen:\n     - Single or dual-month calendar view\n     - Highlight range from startDate to endDate (or hoverDate preview)\n     - Disable days outside minDate/maxDate\n     - Visually indicate days that would violate minRangeDays/maxRangeDays\n     - IF allowSameDay=false: disable startDate from end selection\n     - Clear action\n     - On outside click: close without change\n\n  6. Below inputs:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 11. Value Handling\n\n### Range Validation\n\n| Rule | Behavior |\n|------|----------|\n| `endDate < startDate` | Swap the two values |\n| `allowSameDay=false` and same day selected | Prevent selection, keep selectingEnd=true |\n| Range < `minRangeDays` | Visually grey out invalid end dates |\n| Range > `maxRangeDays` | Visually grey out dates beyond maximum |\n\n### minDate / maxDate\n\n- Disable calendar days outside the allowed bounds\n- Prevent navigation to months entirely outside the allowed range\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Calendar dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Date Range Picker** | Two inputs + dual-month calendar popup |\n| **Date Range Inline** | Always-visible dual calendar |\n| **Date Range with Presets** | Quick options (Last 7 days, This month) + custom range |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateInterval/usage" {
    export const skill = "\n# enter + date-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + date-interval** group.\n> Use this when you need the user to provide a **date range (start and end date, no time)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start date input |\n| `LabelEnd` | Label shown above the end date input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startDate` | `string | null` | `null` | Start date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `endDate` | `string | null` | `null` | End date in ISO 8601 format (`\"YYYY-MM-DD\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `minDate` | `string` | `''` | Minimum selectable date (`\"YYYY-MM-DD\"`) |\n| `maxDate` | `string` | `''` | Maximum selectable date (`\"YYYY-MM-DD\"`) |\n| `minRangeDays` | `number` | `0` | Minimum number of days the range must span (0 = no minimum) |\n| `maxRangeDays` | `number` | `0` | Maximum number of days the range can span (0 = no maximum) |\n| `firstDayOfWeek` | `number` | `0` | First day of week: `0` = Sunday, `1` = Monday |\n| `allowSameDay` | `boolean` | `true` | Allow start and end on the same day |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both dates as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startDate: string | null, endDate: string | null }` | Fired when both dates are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start date changes |\n| `endChange` | `{ value: string | null }` | Fired when end date changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both `startDate` and `endDate` are ISO 8601 date strings: `\"YYYY-MM-DD\"`\n- `null` means not yet selected\n- No time component is ever stored or emitted\n- `endDate` is always \u2265 `startDate`\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--date-interval-102020\n  startDate=\"{{ui.form.vacationStart}}\"\n  endDate=\"{{ui.form.vacationEnd}}\"\n  error=\"{{ui.form.vacationError}}\"\n  locale=\"pt-BR\"\n  required>\n  <Label>Vacation Period</Label>\n  <LabelStart>From</LabelStart>\n  <LabelEnd>To</LabelEnd>\n</molecules--date-interval-102020>\n```\n\n### With range constraints and helper\n\n```html\n<molecules--date-interval-102020\n  startDate=\"{{ui.report.startDate}}\"\n  endDate=\"{{ui.report.endDate}}\"\n  error=\"{{ui.report.dateError}}\"\n  locale=\"en-US\"\n  minDate=\"2026-01-01\"\n  maxDate=\"2026-12-31\"\n  maxRangeDays=\"90\">\n  <Label>Report Period</Label>\n  <Helper>Maximum range is 90 days</Helper>\n</molecules--date-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/creation" {
    export const skill = "\n\n# enter + datetime \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + datetime** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + datetime` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | ISO 8601 datetime string (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g., `'en-US'`, `'pt-BR'`) |\n| `timezone` | `string` | `''` | `@propertyDataSource` | IANA timezone. Empty = local |\n| `minDatetime` | `string` | `''` | `@propertyDataSource` | Minimum allowed datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | `@propertyDataSource` | Maximum allowed datetime (ISO 8601) |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in time picker |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Picker panel is open |\n| `isFocused` | `boolean` | `false` | `@state` | Field has focus |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- Time is always stored in **24-hour format**, regardless of display locale\n- `null` represents no value selected\n\n### Display Format\n\nDisplay is locale-aware. The molecule formats `value` for display only \u2014 never modifies the stored value.\n\n| Locale | Stored value | Displayed |\n|--------|-------------|-----------|\n| `en-US` | `\"2026-04-17T14:30:00\"` | `04/17/2026 02:30 PM` |\n| `pt-BR` | `\"2026-04-17T14:30:00\"` | `17/04/2026 14:30` |\n| `de-DE` | `\"2026-04-17T14:30:00\"` | `17.04.2026 14:30` |\n\n### Derived State\n\n`value` is bound via `@propertyDataSource`. If your implementation maintains derived state (e.g., a formatted display string), use `handleIcaStateChange` to recalculate when `value` changes externally. See `molecule-generation2.md` section 11.\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | User confirmed a datetime selection |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"2026-04-17T14:30:00\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input trigger + picker panel |\n| **View** | `false` | Renders formatted datetime as static text |\n\n### View Mode Rules\n\n- Format `value` using `locale` and display as text\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n- No input, no picker, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message below input, apply error visual state |\n\n- Error is never shown in view mode (`isEditing === false`)\n- The molecule displays the error; the **Page/Organism** is responsible for setting it\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Hover** | Subtle visual feedback |\n| **Open** | Picker panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no picker |\n\n---\n\n## 9. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render formatted datetime string or \"\u2014\"\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles (disabled, error, loading)\n\n  2. IF hasSlot('Label'):\n     - Render label\n     - IF required: add indicator (*)\n\n  3. Input trigger:\n     - Show formatted value or placeholder\n     - Calendar + clock icon\n     - onClick: toggle isOpen\n\n  4. IF loading:\n     - Render loading indicator inside trigger\n     - Do NOT open picker while loading\n\n  5. IF isOpen:\n     - Render picker panel:\n       a. Date selection section (calendar grid)\n          - Month/year navigation\n          - Day grid \u2014 disable days outside minDatetime/maxDatetime\n       b. Time selection section\n          - Hours column\n          - Minutes column (filtered by minuteStep)\n       c. Confirm and Clear actions\n     - On confirm: set value, emit change, close panel\n     - On clear: set value = null, emit change, close panel\n     - On outside click: close panel without change\n\n  6. Below trigger:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 10. Value Handling\n\n### Parsing Input to Value\n\nWhen the user selects date and time in the picker:\n\n```\ndate part  \u2192 \"YYYY-MM-DD\"  (from calendar selection)\ntime part  \u2192 \"HH:mm\"       (from time columns, always 24h)\ncombined   \u2192 \"YYYY-MM-DDTHH:mm:00\"\n```\n\n### Applying minDatetime / maxDatetime\n\n- Disable calendar days entirely outside the allowed range\n- For the boundary day: disable time options that fall outside the boundary\n\n### minuteStep\n\n- Only show minutes that are multiples of `minuteStep`\n- Example: `minuteStep=15` \u2192 show 00, 15, 30, 45\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Picker dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Current value | `aria-label` on trigger with formatted datetime |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **DateTime Picker** | Input trigger + calendar + clock panel (popup) |\n| **DateTime Input** | Masked text input with format validation |\n| **DateTime Inline** | Always-visible calendar + clock, no popup |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTime/usage" {
    export const skill = "\n\n# enter + datetime \u2014 Usage\n\n> Quick reference for using molecules in the **enter + datetime** group.\n> Use this when you need the user to provide a **date and time together**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `timezone` | `string` | `''` | IANA timezone, e.g. `'America/Sao_Paulo'`. Empty = local |\n| `minDatetime` | `string` | `''` | Minimum selectable datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | Maximum selectable datetime (ISO 8601) |\n| `minuteStep` | `number` | `1` | Minutes increment in the time picker (e.g. 5, 15, 30) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user confirms a datetime selection |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- `null` when no value is selected\n- Time is always in **24-hour format** internally, regardless of display locale\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.form.scheduledAt}}\"\n  error=\"{{ui.form.scheduledAtError}}\"\n  locale=\"en-US\"\n  required>\n  <Label>Scheduled At</Label>\n</molecules--datetime-input-102020>\n```\n\n### With helper and minute step\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.meeting.startsAt}}\"\n  error=\"{{ui.meeting.startsAtError}}\"\n  locale=\"pt-BR\"\n  minuteStep=\"15\"\n  minDatetime=\"2026-01-01T00:00:00\"\n  required>\n  <Label>Meeting Start</Label>\n  <Helper>Select a date and time at least 15 minutes from now</Helper>\n</molecules--datetime-input-102020>\n```\n\n### View mode (read-only display)\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.order.confirmedAt}}\"\n  isEditing=\"false\"\n  locale=\"en-US\">\n  <Label>Confirmed At</Label>\n</molecules--datetime-input-102020>\n```\n\n### Disabled\n\n```html\n<molecules--datetime-input-102020\n  value=\"{{ui.form.lockedAt}}\"\n  disabled=\"true\"\n  locale=\"en-US\">\n  <Label>Locked At</Label>\n</molecules--datetime-input-102020>\n```\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/creation" {
    export const skill = "\n# enter + datetime-interval \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + datetime-interval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + datetime-interval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start datetime input |\n| `LabelEnd` | No | Label for the end datetime input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startDatetime` | `string | null` | `null` | `@propertyDataSource` | Start datetime (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `endDatetime` | `string | null` | `null` | `@propertyDataSource` | End datetime (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `timezone` | `string` | `''` | `@propertyDataSource` | IANA timezone. Empty = local |\n| `minDatetime` | `string` | `''` | `@propertyDataSource` | Minimum allowed datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | `@propertyDataSource` | Maximum allowed datetime (ISO 8601) |\n| `minDurationMinutes` | `number` | `0` | `@propertyDataSource` | Minimum duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | `@propertyDataSource` | Maximum duration in minutes (0 = no maximum) |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in time picker |\n| `allowSameInstant` | `boolean` | `false` | `@propertyDataSource` | Allow start and end at the same datetime |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both datetimes are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `activeField` | `string | null` | `null` | `@state` | Which picker is open: `'start'`, `'end'`, or `null` |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Both values stored as **ISO 8601**: `\"YYYY-MM-DDTHH:mm:ss\"`\n- Time always stored in **24-hour format**\n- `null` means not yet selected\n- `endDatetime` must be > `startDatetime` (unless `allowSameInstant=true`)\n\n### Display Format\n\n| Locale | Same day range | Displayed |\n|--------|---------------|-----------|\n| `en-US` | same day | `04/17/2026 09:00 AM \u2013 10:30 AM` |\n| `en-US` | different days | `04/17/2026 09:00 AM \u2013 04/18/2026 08:00 AM` |\n| `pt-BR` | same day | `17/04/2026 09:00 \u2013 10:30` |\n\nWhen start and end are on the same day, the date can be shown once with only the times for brevity.\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startDatetime` is set: display `\"startDatetime \u2013 \u2014\"`\n- If both set: display full formatted range\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startDatetime: string | null, endDatetime: string | null }` | \u2713 | Both datetimes confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start datetime changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End datetime changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: {\n    startDatetime: this.startDatetime, // \"2026-04-17T09:00:00\"\n    endDatetime: this.endDatetime      // \"2026-04-17T10:30:00\"\n  }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two datetime inputs + pickers |\n| **View** | `false` | Renders formatted datetime range as static text |\n\n- In view mode: no inputs, no pickers, no events, no error, no helper\n\n---\n\n## 7. Selection Flow\n\n```\n1. User clicks start input \u2192 activeField = 'start'\n2. Start picker opens (calendar + time)\n3. User confirms start:\n   - startDatetime is set\n   - emit startChange\n   - IF endDatetime is null: activeField = 'end' (auto-advance)\n   - ELSE: activeField = null, close\n4. User clicks end input \u2192 activeField = 'end'\n5. End picker opens:\n   - Calendar: disable dates before startDatetime date\n   - Time: if same day, disable times \u2264 startDatetime time\n6. User confirms end:\n   - endDatetime is set\n   - emit endChange + change\n   - activeField = null, close picker\n```\n\n---\n\n## 8. Duration Validation\n\n| Rule | Behavior |\n|------|----------|\n| `endDatetime \u2264 startDatetime` | Prevent selection (unless `allowSameInstant=true`) |\n| Duration < `minDurationMinutes` | Grey out end times/dates that would be too short |\n| Duration > `maxDurationMinutes` | Grey out end times/dates that would be too long |\n\nThe molecule enforces these rules visually during selection. The Page/Organism sets the `error` message after the fact if needed.\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Active (start)** | Start picker open |\n| **Active (end)** | End picker open |\n| **Complete** | Both datetimes selected |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render formatted range or \"\u2014\"\n     - If same day: abbreviate end to time only\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render overall label\n\n  3. Two datetime trigger inputs:\n     - Left: LabelStart + startDatetime formatted or placeholder\n     - Right: LabelEnd + endDatetime formatted or placeholder\n     - Calendar+clock icons on each\n\n  4. IF loading: render loading indicator, do NOT open pickers\n\n  5. IF activeField === 'start':\n     - Render start picker panel (calendar + time selector)\n     - Confirm / Clear actions\n     - On confirm: set startDatetime, emit startChange\n       - If endDatetime is null: switch activeField to 'end'\n       - Else: close (activeField = null)\n\n  6. IF activeField === 'end':\n     - Render end picker panel (calendar + time selector)\n     - Disable dates/times that violate constraints\n     - Confirm / Clear actions\n     - On confirm: set endDatetime, emit endChange + change, close\n\n  7. Below inputs:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Picker dialogs | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Day cells | `role=\"gridcell\"`, `aria-selected`, `aria-disabled` |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **DateTime Range Picker** | Two inputs + separate calendar+time panels |\n| **Event Scheduler** | Side-by-side pickers optimized for meeting booking |\n| **Booking Widget** | Compact check-in/check-out with duration display |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterDateTimeInterval/usage" {
    export const skill = "\n\n# enter + datetime-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + datetime-interval** group.\n> Use this when you need the user to provide a **date+time range (start and end datetime)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start datetime input |\n| `LabelEnd` | Label shown above the end datetime input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startDatetime` | `string | null` | `null` | Start datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `endDatetime` | `string | null` | `null` | End datetime in ISO 8601 format (`\"YYYY-MM-DDTHH:mm:ss\"`) |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `timezone` | `string` | `''` | IANA timezone, e.g. `'America/Sao_Paulo'`. Empty = local |\n| `minDatetime` | `string` | `''` | Minimum selectable datetime (ISO 8601) |\n| `maxDatetime` | `string` | `''` | Maximum selectable datetime (ISO 8601) |\n| `minDurationMinutes` | `number` | `0` | Minimum duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | Maximum duration in minutes (0 = no maximum) |\n| `minuteStep` | `number` | `1` | Minutes increment in the time picker (e.g. 15, 30) |\n| `allowSameInstant` | `boolean` | `false` | Allow start and end at the exact same datetime |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both datetimes as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startDatetime: string | null, endDatetime: string | null }` | Fired when both datetimes are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start datetime changes |\n| `endChange` | `{ value: string | null }` | Fired when end datetime changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both values are ISO 8601 datetime strings: `\"YYYY-MM-DDTHH:mm:ss\"`\n- `null` when not yet selected\n- Time is always stored in **24-hour format** internally\n- `endDatetime` is always > `startDatetime` (unless `allowSameInstant=true`)\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--datetime-interval-102020\n  startDatetime=\"{{ui.form.meetingStart}}\"\n  endDatetime=\"{{ui.form.meetingEnd}}\"\n  error=\"{{ui.form.meetingError}}\"\n  locale=\"en-US\"\n  minuteStep=\"15\"\n  required>\n  <Label>Meeting Period</Label>\n  <LabelStart>Start</LabelStart>\n  <LabelEnd>End</LabelEnd>\n</molecules--datetime-interval-102020>\n```\n\n### With duration constraints\n\n```html\n<molecules--datetime-interval-102020\n  startDatetime=\"{{ui.booking.checkIn}}\"\n  endDatetime=\"{{ui.booking.checkOut}}\"\n  error=\"{{ui.booking.periodError}}\"\n  locale=\"pt-BR\"\n  minDurationMinutes=\"60\"\n  maxDurationMinutes=\"480\">\n  <Label>Reservation</Label>\n  <LabelStart>Check-in</LabelStart>\n  <LabelEnd>Check-out</LabelEnd>\n  <Helper>Reservations between 1 and 8 hours</Helper>\n</molecules--datetime-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/creation" {
    export const skill = "\n# enter + money \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + money** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + money` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Monetary value as a plain number (e.g. `1500.50`) |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `currency` | `string` | `'USD'` | `@propertyDataSource` | ISO 4217 currency code (e.g. `'USD'`, `'BRL'`, `'EUR'`) |\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g. `'en-US'`, `'pt-BR'`) |\n| `decimals` | `number` | `2` | `@propertyDataSource` | Decimal places (use `0` for currencies without cents, e.g. JPY) |\n| `min` | `number | null` | `null` | `@propertyDataSource` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | `@propertyDataSource` | Maximum allowed value (null = no maximum) |\n| `showSymbol` | `boolean` | `true` | `@propertyDataSource` | Display currency symbol alongside the field |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder when value is null |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `rawValue` | `string` | `''` | `@state` | Locale-formatted string currently shown in the input (derived from `value`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **JavaScript number** representing the monetary amount\n- `null` means not yet provided\n- **Never** store currency symbols or thousand separators \u2014 those are display only\n- `decimals` defines precision (default 2 for cents-based currencies; 0 for e.g. JPY)\n\n### Parsing Rules\n\nInput typed by the user must be parsed according to the active locale:\n\n| Locale | Thousand sep | Decimal sep | Input `\"1.500,50\"` \u2192 value |\n|--------|-------------|-------------|---------------------------|\n| `pt-BR` | `.` | `,` | `1500.50` |\n| `en-US` | `,` | `.` | `1500.50` |\n| `''` | (none) | `.` | `1500.50` |\n\nParsing algorithm:\n1. Remove all characters that are not digits, the locale decimal separator, or a minus sign\n2. Replace the locale decimal separator with `.`\n3. Parse as `parseFloat`\n\n### Display Format\n\n| `locale` | `currency` | `showSymbol` | Value | Displayed |\n|----------|-----------|-------------|-------|-----------|\n| `'en-US'` | `'USD'` | `true` | `1500.50` | `$1,500.50` |\n| `'pt-BR'` | `'BRL'` | `true` | `1500.50` | `R$ 1.500,50` |\n| `'en-US'` | `'EUR'` | `false` | `1500.50` | `1,500.50` |\n\n### View Mode\n\n- If value is `null`: display `\"\u2014\"`\n- Otherwise: display value formatted with `Intl.NumberFormat` using `currency` and `locale`\n- Currency symbol position follows the locale convention\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Value confirmed on blur |\n| `input` | `{ value: number | null }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders locale-formatted text input |\n| **View** | `false` | Renders fully formatted currency string as static text |\n\n- In view mode: no input, no events, no error, no helper\n\n---\n\n## 7. Input Interaction\n\n```\nON FOCUS:\n  - Select all input content for easy replacement\n  - Emit `focus` event\n\nON INPUT (each keystroke):\n  - Store raw string in rawValue\n  - Attempt to parse: value = parseLocaleNumber(rawValue)\n  - Emit `input` event with current parsed value (may be null if unparseable)\n\nON BLUR:\n  - If rawValue is empty: set value = null\n  - Else: parse rawValue \u2192 value\n  - Clamp to min/max if applicable\n  - Reformat: rawValue = formatToRaw(value)  \u2190 normalize display\n  - Emit `change` event\n  - Emit `blur` event\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| Value < `min` | Clamp to `min` on blur |\n| Value > `max` | Clamp to `max` on blur |\n| Non-numeric input | Clear on blur, value = null |\n| `required` and `null` | Error state until a value is entered |\n| Negative value when `min >= 0` | Clamp to `min` on blur |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted, content selected |\n| **Filled** | Value present, formatted |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Fully formatted currency string, no input |\n\n---\n\n## 11. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render Intl.NumberFormat-formatted value or \"\u2014\"\n     - Include currency symbol per locale/showSymbol\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Input row:\n     - IF showSymbol: render currency symbol (position follows locale)\n     - Text input bound to rawValue\n       - type=\"text\"\n       - inputmode=\"decimal\" (triggers numeric keyboard on mobile)\n       - @focus: select all, emit `focus` event\n       - @input: update rawValue, parse, emit `input` event\n       - @blur: normalize, clamp, reformat rawValue, emit `change` + `blur`\n\n  4. IF loading: render loading indicator, disable input\n\n  5. Below input:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Currency context | `aria-label` includes currency code when symbol alone is ambiguous |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Currency Input** | Locale-aware text input with currency symbol |\n| **Price Field** | Compact input for product pricing, always positive |\n| **Money Input** | General purpose, supports negative values (credits/debits) |\n| **Currency Converter** | Two linked money inputs with exchange rate display |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterMoney/usage" {
    export const skill = "\n# enter + money \u2014 Usage\n\n> Quick reference for using molecules in the **enter + money** group.\n> Use this when you need the user to provide a **monetary value** with locale-aware formatting.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Monetary value as a plain number (e.g. `1500.50`). `null` = not yet provided |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `currency` | `string` | `'USD'` | ISO 4217 currency code, e.g. `'USD'`, `'BRL'`, `'EUR'` |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `decimals` | `number` | `2` | Decimal places (use `0` for currencies without cents, e.g. JPY) |\n| `min` | `number | null` | `null` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | Maximum allowed value (null = no maximum) |\n| `showSymbol` | `boolean` | `true` | Display currency symbol alongside the input |\n| `placeholder` | `string` | `''` | Placeholder when value is null |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = formatted read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when value is confirmed on blur |\n| `input` | `{ value: number | null }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value stored and emitted as a plain JavaScript **number** (e.g. `1500.50`)\n- `null` when not yet provided\n- **Never** includes currency symbols or thousand separators \u2014 those are display only\n- Display formatting respects `locale`, `currency`, and `decimals`\n\n---\n\n## Examples\n\n### Product price (USD)\n\n```html\n<molecules--currency-input-102020\n  value=\"{{ui.product.price}}\"\n  error=\"{{ui.product.priceError}}\"\n  currency=\"USD\"\n  locale=\"en-US\"\n  min=\"0\"\n  required>\n  <Label>Price</Label>\n</molecules--currency-input-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/creation" {
    export const skill = "\n# enter + number \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + number** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + number` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Prefix` | No | Content rendered before the input (e.g. unit symbol) |\n| `Suffix` | No | Content rendered after the input (e.g. unit label) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Current numeric value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `min` | `number | null` | `null` | `@propertyDataSource` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | `@propertyDataSource` | Maximum allowed value (null = no maximum) |\n| `step` | `number` | `1` | `@propertyDataSource` | Increment/decrement step for stepper and slider |\n| `decimals` | `number` | `0` | `@propertyDataSource` | Number of decimal places allowed |\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting (e.g. `'en-US'`, `'pt-BR'`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text when value is null |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `rawValue` | `string` | `''` | `@state` | Formatted string currently shown in the input (derived from `value`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **JavaScript number**\n- `null` means not yet provided\n- Decimal precision controlled by `decimals` property\n- Display format respects `locale` and `decimals`; stored value is always a plain number\n- When `decimals = 0`, only integers are accepted\n\n### Display Format\n\n| `locale` | `decimals` | Value | Displayed |\n|----------|------------|-------|-----------|\n| `'en-US'` | `0` | `1500` | `1,500` |\n| `'pt-BR'` | `2` | `1500.5` | `1.500,50` |\n| `''` | `2` | `1500.5` | `1500.50` (browser default) |\n\n### View Mode\n\n- If value is `null`: display `\"\u2014\"`\n- Otherwise: display value formatted with `locale` and `decimals`\n- Prefix/Suffix slots are rendered in view mode\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Value confirmed (on blur or stepper click) |\n| `input` | `{ value: number | null }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders numeric input (with optional stepper or slider) |\n| **View** | `false` | Renders formatted number as static text |\n\n- In view mode: no input, no stepper, no events, no error, no helper\n\n---\n\n## 7. Stepper Logic\n\nWhen the implementation uses a stepper (+/\u2212 buttons):\n\n```typescript\nprivate increment() {\n  const current = this.value ?? 0;\n  const next = current + this.step;\n  if (this.max !== null && next > this.max) return;\n  this.value = this.roundToDecimals(next);\n  this.rawValue = this.formatToDisplay(this.value);\n  this.emitChange();\n}\n\nprivate decrement() {\n  const current = this.value ?? 0;\n  const next = current - this.step;\n  if (this.min !== null && next < this.min) return;\n  this.value = this.roundToDecimals(next);\n  this.rawValue = this.formatToDisplay(this.value);\n  this.emitChange();\n}\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| Value < `min` | Clamp to `min` on blur |\n| Value > `max` | Clamp to `max` on blur |\n| Non-numeric input | Ignored on keydown; cleared on blur |\n| Decimals > `decimals` | Truncate or round on blur |\n| `required` and `null` | Error state until a value is entered |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted |\n| **Filled** | Value present |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render formatted value or \"\u2014\"\n     - Include Prefix/Suffix if slots exist\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Input row:\n     - IF hasSlot('Prefix'): render prefix content\n     - Numeric input bound to rawValue\n       - type=\"text\" (to control formatting)\n       - inputmode=\"decimal\" (mobile keyboard)\n       - @input: update rawValue, parse and emit `input` event\n       - @blur: normalize rawValue, clamp, emit `change` event\n       - @focus: emit `focus` event\n     - IF hasSlot('Suffix'): render suffix content\n     - IF implementation is stepper: render \u2212 and + buttons\n\n  4. IF loading: render loading indicator, disable input and buttons\n\n  5. IF implementation is slider:\n     - Render range slider bound to value\n     - @input: update value and rawValue, emit `input` event\n     - @change: emit `change` event\n\n  6. Below input:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Stepper buttons | `aria-label=\"Increment\"` / `aria-label=\"Decrement\"` |\n| Min/Max | `aria-valuemin` / `aria-valuemax` on slider implementations |\n| Current value | `aria-valuenow` on slider implementations |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Number Input** | Plain text input accepting numeric values |\n| **Stepper** | Input flanked by \u2212 and + buttons |\n| **Slider** | Horizontal range slider for bounded values |\n| **Percentage Input** | Number input locked to 0\u2013100 with `%` suffix |\n| **Quantity Selector** | Stepper with compact visual for cart-style quantities |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterNumber/usage" {
    export const skill = "\n# enter + number \u2014 Usage\n\n> Quick reference for using molecules in the **enter + number** group.\n> Use this when you need the user to provide a **numeric value**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Prefix` | Content rendered before the input (e.g. `#`, `km`) |\n| `Suffix` | Content rendered after the input (e.g. `kg`, `%`) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Current numeric value. `null` = not yet provided |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `min` | `number | null` | `null` | Minimum allowed value (null = no minimum) |\n| `max` | `number | null` | `null` | Maximum allowed value (null = no maximum) |\n| `step` | `number` | `1` | Increment/decrement step for stepper and slider |\n| `decimals` | `number` | `0` | Number of decimal places |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `placeholder` | `string` | `''` | Placeholder text when value is null |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when value is confirmed (blur or stepper click) |\n| `input` | `{ value: number | null }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value stored and emitted as a plain JavaScript **number**\n- `null` when not yet provided\n- Display respects `locale` and `decimals`; stored value is always a raw number\n\n---\n\n## Examples\n\n### Basic quantity\n\n```html\n<molecules--number-stepper-102020\n  value=\"{{ui.order.quantity}}\"\n  error=\"{{ui.order.quantityError}}\"\n  min=\"1\"\n  max=\"99\"\n  step=\"1\"\n  required>\n  <Label>Quantity</Label>\n</molecules--number-stepper-102020>\n```\n\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterText/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterText/creation" {
    export const skill = "\n# enter + text \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + text** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + text` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Prefix` | No | Content rendered before the input (e.g. icon, static text) |\n| `Suffix` | No | Content rendered after the input (e.g. icon, action button) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string` | `''` | `@propertyDataSource` | Current text value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text when value is empty |\n| `maxLength` | `number | null` | `null` | `@propertyDataSource` | Maximum number of characters (null = no limit) |\n| `minLength` | `number | null` | `null` | `@propertyDataSource` | Minimum number of characters (null = no minimum) |\n| `rows` | `number` | `1` | `@propertyDataSource` | Number of visible rows (>1 renders a textarea) |\n| `autocomplete` | `string` | `''` | `@propertyDataSource` | HTML autocomplete attribute value (e.g. `'email'`, `'name'`, `'off'`) |\n| `inputType` | `string` | `'text'` | `@propertyDataSource` | HTML input type: `'text'`, `'email'`, `'password'`, `'search'`, `'url'`, `'tel'` |\n| `mask` | `string` | `''` | `@propertyDataSource` | Input mask pattern (e.g. `'(##) #####-####'` for phone). `#` = digit, `A` = letter, `*` = any |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Value is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a plain **string**\n- Empty string `''` means no value entered\n- When `mask` is set, `value` always stores the **raw unmasked string** \u2014 the mask is display only\n- When `inputType='password'`, value is never displayed back to the user\n\n### View Mode\n\n- If value is `''`: display `\"\u2014\"`\n- If `inputType='password'`: display `\"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\"` regardless of value length\n- Otherwise: display value as plain text\n- Prefix/Suffix slots are rendered in view mode\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string }` | \u2713 | Value confirmed on blur |\n| `input` | `{ value: string }` | \u2713 | Value changed on each keystroke |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders input or textarea |\n| **View** | `false` | Renders value as static text |\n\n- In view mode: no input, no events, no error, no helper\n\n---\n\n## 7. Input vs Textarea\n\n| Condition | Element rendered |\n|-----------|-----------------|\n| `rows = 1` | `<input>` |\n| `rows > 1` | `<textarea>` |\n\n- `<textarea>` does not support `inputType` or `mask`\n- When `rows > 1` and `maxLength` is set: display a character counter below the field (e.g. `42 / 200`)\n\n---\n\n## 8. Mask Logic\n\nWhen `mask` is set:\n\n- Apply mask on every `@input` event before updating `value`\n- `value` stores only the raw digits/letters extracted from the masked string\n- Display shows the formatted mask string in `rawDisplay`\n- Mask characters: `#` = digit only, `A` = letter only, `*` = any character\n- Literal characters in the mask (e.g. `(`, `)`, `-`, space) are inserted automatically\n\n```\nExample: mask=\"(##) #####-####\"\nUser types: \"11987654321\"\nrawDisplay:  \"(11) 98765-4321\"\nvalue:       \"11987654321\"\n```\n\n---\n\n## 9. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `value.length < minLength` | Error state; Page sets the error message |\n| `value.length > maxLength` | Block input beyond the limit |\n| `required` and `value === ''` | Error state until text is entered |\n| `inputType='email'` | Page is responsible for format validation |\n\n---\n\n## 10. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 11. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Input border highlighted |\n| **Filled** | Value present |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, input blocked |\n| **View Mode** | Plain text only |\n\n---\n\n## 12. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. IF inputType='password': render \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\"\n     ELSE IF value === '': render \"\u2014\"\n     ELSE: render value as text\n     - Include Prefix/Suffix if slots exist\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Input row:\n     - IF hasSlot('Prefix'): render prefix content\n     - IF rows > 1: render <textarea rows={rows}>\n       ELSE: render <input type={inputType}>\n       - bound to value (or rawDisplay when mask is set)\n       - placeholder, maxLength, autocomplete, required, disabled, readonly\n       - @input: update value (and rawDisplay if masked), emit `input` event\n       - @blur: emit `change` + `blur` events\n       - @focus: emit `focus` event\n     - IF hasSlot('Suffix'): render suffix content\n\n  4. IF loading: render loading indicator, disable input\n\n  5. IF rows > 1 AND maxLength is set: render character counter\n\n  6. Below input:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 13. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Password | Never `aria-label` the actual value |\n| Character counter | `aria-live=\"polite\"` so screen readers announce remaining characters |\n\n---\n\n## 14. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Text Input** | Single-line plain text field |\n| **Textarea** | Multi-line text field with optional character counter |\n| **Password Input** | Single-line input with show/hide toggle |\n| **Masked Input** | Input with automatic formatting (phone, CPF, ZIP) |\n| **Search Input** | Input with search icon and clear button |\n| **Tag Input** | Input that converts entries into removable tags |\n\n---\n\n## 15. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterText/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterText/usage" {
    export const skill = "\n\n# enter + text \u2014 Usage\n\n> Quick reference for using molecules in the **enter + text** group.\n> Use this when you need the user to provide **free-form text**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Prefix` | Content rendered before the input (e.g. icon, static text) |\n| `Suffix` | Content rendered after the input (e.g. icon, action button) |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string` | `''` | Current text value |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Placeholder text when value is empty |\n| `maxLength` | `number | null` | `null` | Maximum number of characters (null = no limit) |\n| `minLength` | `number | null` | `null` | Minimum number of characters (null = no minimum) |\n| `rows` | `number` | `1` | Number of visible rows. `1` = input, `>1` = textarea |\n| `autocomplete` | `string` | `''` | HTML autocomplete value (e.g. `'email'`, `'name'`, `'off'`) |\n| `inputType` | `string` | `'text'` | Input type: `'text'`, `'email'`, `'password'`, `'search'`, `'url'`, `'tel'` |\n| `mask` | `string` | `''` | Mask pattern. `#` = digit, `A` = letter, `*` = any. Literals inserted automatically |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the value as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string }` | Fired when value is confirmed on blur |\n| `input` | `{ value: string }` | Fired on each keystroke |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is always a plain **string**\n- Empty string `''` when not yet provided\n- When `mask` is set, `value` contains the **raw unmasked string** \u2014 the formatted display is handled internally\n- When `inputType='password'`, view mode renders `\"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\"` regardless of value\n\n---\n\n## Examples\n\n### Simple text field\n\n```html\n<molecules--text-input-102020\n  value=\"{{ui.form.firstName}}\"\n  error=\"{{ui.form.firstNameError}}\"\n  placeholder=\"John\"\n  maxLength=\"200\"\n  required>\n  <Label>First Name</Label>\n</molecules--text-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/creation" {
    export const skill = "\n# enter + time \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + time** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + time` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Field label |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Time string in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `hour12` | `boolean` | `false` | `@propertyDataSource` | Display in 12-hour format (AM/PM) |\n| `showSeconds` | `boolean` | `false` | `@propertyDataSource` | Include seconds in input and stored value |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in picker |\n| `minTime` | `string` | `''` | `@propertyDataSource` | Minimum allowed time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | `@propertyDataSource` | Maximum allowed time (`\"HH:mm\"`) |\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Field is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Time picker panel is open |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is always stored in **24-hour format**: `\"HH:mm\"`\n- When `showSeconds=true`: `\"HH:mm:ss\"`\n- **No date component** \u2014 never store or emit date information\n- `null` represents no value selected\n\n### Display Format\n\nDisplay respects `hour12` and `locale`. The stored value is never modified.\n\n| `hour12` | Stored | Displayed |\n|----------|--------|-----------|\n| `false` | `\"14:30\"` | `14:30` |\n| `true` | `\"14:30\"` | `02:30 PM` |\n| `false` | `\"08:05:30\"` | `08:05:30` |\n| `true` | `\"08:05:30\"` | `08:05:30 AM` |\n\n### View Mode\n\n- If `value` is `null`, display `\"\u2014\"` (em dash)\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Time confirmed or cleared |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value } // \"14:30\" or null\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders time input + picker panel |\n| **View** | `false` | Renders formatted time as static text |\n\n- In view mode: no input, no picker, no events, no error, no helper\n\n---\n\n## 7. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 8. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focus** | Highlighted border or outline |\n| **Open** | Time picker panel visible |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only, no picker |\n\n---\n\n## 9. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render formatted time string or \"\u2014\"\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'):\n     - Render label\n     - IF required: add indicator (*)\n\n  3. Input field:\n     - Masked text input (HH:mm or hh:mm AM/PM)\n     - Clock icon \u2014 onClick: toggle isOpen\n\n  4. IF loading: render loading indicator, do NOT open picker\n\n  5. IF isOpen:\n     - Hours column (00\u201323 or 01\u201312)\n     - Minutes column (filtered by minuteStep)\n     - IF showSeconds: seconds column (00\u201359)\n     - IF hour12: AM/PM selector\n     - Disable options outside minTime/maxTime\n     - Confirm and Clear actions\n     - On confirm: set value, emit change, close panel\n     - On outside click: close without change\n\n  6. Below input:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 10. Value Handling\n\n### minuteStep\n\n- Only render minutes that are multiples of `minuteStep`\n- Example: `minuteStep=15` \u2192 show 00, 15, 30, 45\n\n### minTime / maxTime\n\n- Disable hours/minutes outside the allowed range\n- For boundary hours: disable only the out-of-range minutes\n\n### showSeconds\n\n- When `false`: store `\"HH:mm\"`, hide seconds column\n- When `true`: store `\"HH:mm:ss\"`, show seconds column (always step 1)\n\n### hour12\n\n- Display only \u2014 never affects stored format\n- Internally always convert to/from 24h\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Associated label | `aria-labelledby` |\n| Error announced | `aria-describedby` pointing to error element |\n| Invalid state | `aria-invalid=\"true\"` when error exists |\n| Required field | `aria-required=\"true\"` |\n| Picker dialog | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Current value | `aria-label` on trigger with formatted time |\n\n---\n\n## 12. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Time Picker** | Input + scrollable columns panel |\n| **Time Input** | Masked text input `HH:mm` |\n| **Time Spinner** | Up/down arrows per segment |\n| **Clock Face** | Analog clock for hour + minute selection |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterTime/usage" {
    export const skill = "\n\n# enter + time \u2014 Usage\n\n> Quick reference for using molecules in the **enter + time** group.\n> Use this when you need the user to provide a **time only (no date)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Field label shown above the input |\n| `Helper` | Descriptive text shown below the input when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Selected time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `hour12` | `boolean` | `false` | Display in 12-hour format with AM/PM |\n| `showSeconds` | `boolean` | `false` | Include seconds in the input |\n| `minuteStep` | `number` | `1` | Minutes increment in picker (e.g. 5, 15, 30) |\n| `minTime` | `string` | `''` | Minimum selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | Maximum selectable time (`\"HH:mm\"`) |\n| `placeholder` | `string` | `''` | Placeholder text when no value is selected |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks the field as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when the user confirms a time selection |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Stored and emitted in **24-hour format**: `\"HH:mm\"` or `\"HH:mm:ss\"` when `showSeconds=true`\n- `null` when no value is selected\n- Display format respects `hour12` and `locale`, but stored value is always 24h\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--time-input-102020\n  value=\"{{ui.form.openingTime}}\"\n  error=\"{{ui.form.openingTimeError}}\"\n  required>\n  <Label>Opening Time</Label>\n</molecules--time-input-102020>\n```\n\n### With 15-minute step and AM/PM display\n\n```html\n<molecules--time-input-102020\n  value=\"{{ui.schedule.alarmTime}}\"\n  error=\"{{ui.schedule.alarmTimeError}}\"\n  locale=\"en-US\"\n  hour12=\"true\"\n  minuteStep=\"15\"\n  minTime=\"06:00\"\n  maxTime=\"22:00\">\n  <Label>Alarm Time</Label>\n  <Helper>Choose a time between 6:00 AM and 10:00 PM</Helper>\n</molecules--time-input-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/creation" {
    export const skill = "\n# enter + time-interval \u2014 Creation\n\n> Implementation reference for creating molecules in the **enter + time-interval** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `enter + time-interval` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Overall label for the range field |\n| `LabelStart` | No | Label for the start time input |\n| `LabelEnd` | No | Label for the end time input |\n| `Helper` | No | Help text displayed below the field |\n\n```typescript\nslotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `startTime` | `string | null` | `null` | `@propertyDataSource` | Start time in 24h: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `endTime` | `string | null` | `null` | `@propertyDataSource` | End time in 24h: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `locale` | `string` | `''` | `@propertyDataSource` | Locale for display formatting |\n| `hour12` | `boolean` | `false` | `@propertyDataSource` | Display in 12-hour format (AM/PM) |\n| `showSeconds` | `boolean` | `false` | `@propertyDataSource` | Include seconds in input and stored value |\n| `minuteStep` | `number` | `1` | `@propertyDataSource` | Minutes increment in picker |\n| `minTime` | `string` | `''` | `@propertyDataSource` | Earliest selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | `@propertyDataSource` | Latest selectable time (`\"HH:mm\"`) |\n| `minDurationMinutes` | `number` | `0` | `@propertyDataSource` | Minimum interval duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | `@propertyDataSource` | Maximum interval duration in minutes (0 = no maximum) |\n| `allowOvernight` | `boolean` | `false` | `@propertyDataSource` | Allow end time before start time (crosses midnight) |\n| `allowSameTime` | `boolean` | `false` | `@propertyDataSource` | Allow start and end at same time |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | Both times are required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `activeField` | `string | null` | `null` | `@state` | Which picker is open: `'start'`, `'end'`, or `null` |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Both values stored in **24-hour format**: `\"HH:mm\"`\n- When `showSeconds=true`: `\"HH:mm:ss\"`\n- **No date component** \u2014 never store or emit date information\n- `null` means not yet selected\n\n### Overnight Interval\n\n- When `allowOvernight=true` and `endTime < startTime`, the interval is valid and crosses midnight\n- Duration calculation: `(24 * 60) - toMinutes(startTime) + toMinutes(endTime)`\n- Display: append `(+1)` or `(next day)` indicator to end time\n\n### Display Format\n\n| `hour12` | Range | Displayed |\n|----------|-------|-----------|\n| `false` | `\"08:00\"` \u2192 `\"17:30\"` | `08:00 \u2013 17:30` |\n| `true` | `\"08:00\"` \u2192 `\"17:30\"` | `08:00 AM \u2013 05:30 PM` |\n| `false` (overnight) | `\"22:00\"` \u2192 `\"06:00\"` | `22:00 \u2013 06:00 (+1)` |\n\n### View Mode\n\n- If both are `null`: display `\"\u2014\"`\n- If only `startTime` is set: display `\"startTime \u2013 \u2014\"`\n- If both set: display full formatted range with overnight indicator if applicable\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ startTime: string | null, endTime: string | null }` | \u2713 | Both times confirmed |\n| `startChange` | `{ value: string | null }` | \u2713 | Start time changed |\n| `endChange` | `{ value: string | null }` | \u2713 | End time changed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: {\n    startTime: this.startTime, // \"08:00\"\n    endTime: this.endTime      // \"17:30\"\n  }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders two time inputs + pickers |\n| **View** | `false` | Renders formatted time range as static text |\n\n- In view mode: no inputs, no pickers, no events, no error, no helper\n\n---\n\n## 7. Duration Calculation\n\n```typescript\n// Standard (no overnight)\nfunction calcDurationMinutes(startTime: string, endTime: string): number {\n  return toMinutes(endTime) - toMinutes(startTime);\n}\n\n// Overnight\nfunction calcDurationMinutesOvernight(startTime: string, endTime: string): number {\n  return (24 * 60) - toMinutes(startTime) + toMinutes(endTime);\n}\n\nfunction toMinutes(time: string): number {\n  const [h, m] = time.split(':').map(Number);\n  return h * 60 + m;\n}\n```\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `endTime \u2264 startTime` (no overnight) | Prevent selection or show error |\n| `allowOvernight=true` and `endTime < startTime` | Valid \u2014 treat as overnight interval |\n| Duration < `minDurationMinutes` | Grey out invalid end times |\n| Duration > `maxDurationMinutes` | Grey out end times beyond maximum |\n| Outside `minTime` / `maxTime` | Disable times in picker |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Active (start)** | Start time picker open |\n| **Active (end)** | End time picker open |\n| **Complete** | Both times selected |\n| **Overnight** | End time indicator shows `(+1)` |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible |\n| **View Mode** | Formatted text only |\n\n---\n\n## 11. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render \"startTime \u2013 endTime\" formatted or \"\u2014\"\n     - IF allowOvernight and endTime < startTime: add \"(+1)\" to endTime\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render overall label\n\n  3. Two time inputs side by side:\n     - Left: LabelStart + startTime formatted or placeholder\n     - Right: LabelEnd + endTime formatted or placeholder\n     - Clock icons on each\n     - IF overnight: show \"(+1)\" badge next to end input\n\n  4. IF loading: render loading indicator, do NOT open pickers\n\n  5. IF activeField === 'start':\n     - Hours column + minutes column (filtered by minuteStep)\n     - IF showSeconds: seconds column\n     - IF hour12: AM/PM selector\n     - Disable options outside minTime/maxTime\n     - Confirm / Clear\n     - On confirm: set startTime, emit startChange\n       - IF endTime is null: switch activeField to 'end'\n       - ELSE: close (activeField = null)\n\n  6. IF activeField === 'end':\n     - Same structure as start picker\n     - IF allowOvernight=false: disable times \u2264 startTime\n     - IF allowOvernight=true: all times valid, show overnight indicator\n     - Grey out times that violate minDurationMinutes/maxDurationMinutes\n     - On confirm: set endTime, emit endChange + change, close\n\n  7. Below inputs:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Labels | `aria-labelledby` for each input |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Picker dialogs | `role=\"dialog\"`, `aria-modal=\"true\"` |\n| Overnight indicator | `aria-label` describing the next-day context |\n\n---\n\n## 13. Possible Implementations\n\n| Component | Description |\n|-----------|-------------|\n| **Time Range Picker** | Two inputs + scrollable column panels |\n| **Time Range Slider** | Dual-handle slider on a 24h timeline |\n| **Business Hours** | Compact start+end per weekday row |\n\n---\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-17 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupEnterTimeInterval/usage" {
    export const skill = "\n\n# enter + time-interval \u2014 Usage\n\n> Quick reference for using molecules in the **enter + time-interval** group.\n> Use this when you need the user to provide a **time range (start and end time, no date)**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Overall label for the range field |\n| `LabelStart` | Label shown above the start time input |\n| `LabelEnd` | Label shown above the end time input |\n| `Helper` | Descriptive text shown below the field when there is no error |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `startTime` | `string | null` | `null` | Start time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `endTime` | `string | null` | `null` | End time in 24h format: `\"HH:mm\"` or `\"HH:mm:ss\"` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `locale` | `string` | `''` | Display locale, e.g. `'en-US'`, `'pt-BR'` |\n| `hour12` | `boolean` | `false` | Display in 12-hour format with AM/PM |\n| `showSeconds` | `boolean` | `false` | Include seconds in the input |\n| `minuteStep` | `number` | `1` | Minutes increment in the picker (e.g. 5, 15, 30) |\n| `minTime` | `string` | `''` | Earliest selectable time (`\"HH:mm\"`) |\n| `maxTime` | `string` | `''` | Latest selectable time (`\"HH:mm\"`) |\n| `minDurationMinutes` | `number` | `0` | Minimum interval duration in minutes (0 = no minimum) |\n| `maxDurationMinutes` | `number` | `0` | Maximum interval duration in minutes (0 = no maximum) |\n| `allowOvernight` | `boolean` | `false` | Allow end time before start time (crosses midnight) |\n| `allowSameTime` | `boolean` | `false` | Allow start and end at the same time |\n| `isEditing` | `boolean` | `true` | `true` = input mode, `false` = read-only formatted text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks both times as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator inside the field |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ startTime: string | null, endTime: string | null }` | Fired when both times are confirmed |\n| `startChange` | `{ value: string | null }` | Fired when start time changes |\n| `endChange` | `{ value: string | null }` | Fired when end time changes |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Both values stored and emitted in **24-hour format**: `\"HH:mm\"` or `\"HH:mm:ss\"` when `showSeconds=true`\n- `null` when not yet selected\n- Display format respects `hour12` and `locale`, stored value is always 24h\n- When `allowOvernight=true` and `endTime < startTime`, the interval crosses midnight\n\n---\n\n## Examples\n\n### Basic\n\n```html\n<molecules--time-interval-102020\n  startTime=\"{{ui.form.shiftStart}}\"\n  endTime=\"{{ui.form.shiftEnd}}\"\n  error=\"{{ui.form.shiftError}}\"\n  minuteStep=\"30\"\n  required>\n  <Label>Work Shift</Label>\n  <LabelStart>From</LabelStart>\n  <LabelEnd>To</LabelEnd>\n</molecules--time-interval-102020>\n```\n\n### With overnight support and AM/PM display\n\n```html\n<molecules--time-interval-102020\n  startTime=\"{{ui.config.openTime}}\"\n  endTime=\"{{ui.config.closeTime}}\"\n  error=\"{{ui.config.hoursError}}\"\n  locale=\"en-US\"\n  hour12=\"true\"\n  minuteStep=\"15\"\n  allowOvernight=\"true\"\n  minDurationMinutes=\"60\">\n  <Label>Business Hours</Label>\n  <LabelStart>Opens</LabelStart>\n  <LabelEnd>Closes</LabelEnd>\n  <Helper>Minimum 1 hour. Overnight hours allowed</Helper>\n</molecules--time-interval-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/creation" {
    export const skill = "\n\n# locate + position \u2014 Creation\n\n> Implementation reference for creating molecules in the **locate + position** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `locate + position` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the geolocation button |\n| `Suggestions` | No | Container for address suggestion items, populated by the page |\n| `Item` | No | One suggestion inside `<Suggestions>`. Attribute: `value` = `\"lat,lng\"`. Content = address label |\n| `Empty` | No | Content shown when no location is selected or no suggestions available |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Suggestions', 'Item', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Suggestions>\n\u2502   \u2514\u2500\u2500 <Item value=\"lat,lng\">\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Selected coordinates as `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`) or `null` |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Placeholder text for the search input |\n| `showMap` | `boolean` | `false` | `@propertyDataSource` | Show an embedded map preview of the selected location |\n| `allowGeolocation` | `boolean` | `false` | `@propertyDataSource` | Show a button to use the browser's geolocation API |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A location is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (e.g. fetching suggestions or resolving geolocation) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `searchQuery` | `string` | `''` | `@state` | Current text in the search input |\n| `isOpen` | `boolean` | `false` | `@state` | Whether the suggestions panel is open |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- `value` is a plain **string** in the format `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`)\n- `null` means no location selected\n- Parsing:\n\n```typescript\nprivate parseValue(): { lat: number; lng: number } | null {\n  if (!this.value) return null;\n  const [lat, lng] = this.value.split(',').map(Number);\n  return isNaN(lat) || isNaN(lng) ? null : { lat, lng };\n}\n```\n\n### Suggestions via Slot Tags\n\nSuggestions are provided by the page as `<Item>` elements inside `<Suggestions>`:\n\n```html\n<Suggestions>\n  <Item value=\"-23.55,-46.63\">S\u00E3o Paulo, SP - Brazil</Item>\n  <Item value=\"-22.90,-43.17\">Rio de Janeiro, RJ - Brazil</Item>\n</Suggestions>\n```\n\nRead suggestions inline using `getSlots`:\n\n```typescript\nconst suggestionsContainer = this.getSlot('Suggestions');\nconst items = suggestionsContainer\n  ? Array.from(suggestionsContainer.querySelectorAll('Item')).map(el => ({\n      value: el.getAttribute('value') || '',\n      label: el.innerHTML,\n    }))\n  : [];\n```\n\nThe page updates `<Suggestions>` content in response to the `search` event.\n\n### View Mode\n\n- If `value` is `null`: render Empty slot content or `\"\u2014\"`\n- Otherwise: find the matching `<Item>` label for the current value, or display the raw coordinates\n- If `showMap=true`: render map preview with pin at the parsed lat/lng\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Location confirmed \u2014 value is `\"lat,lng\"` or null |\n| `search` | `{ query: string }` | \u2713 | User typed in search input \u2014 page should update `<Suggestions>` items |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Search Flow\n\n```\nUser types in search input\n  \u2192 emit `search` with { query }\n  \u2192 Page calls BFF, updates <Suggestions> slot with <Item> elements\n  \u2192 Component re-renders suggestion list\n  \u2192 User selects a suggestion\n  \u2192 Component sets value = item.value (\"lat,lng\"), emits `change`\n  \u2192 isOpen = false, searchQuery = selected item label\n```\n\n### Geolocation Flow\n\n```\nUser clicks geolocation button\n  \u2192 browser navigator.geolocation.getCurrentPosition()\n  \u2192 on success: set value = \"lat,lng\", emit `change`\n  \u2192 emit `search` with { query: \"lat,lng\" } so page can resolve address\n  \u2192 page updates <Suggestions> with resolved address\n```\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n\nthis.dispatchEvent(new CustomEvent('search', {\n  bubbles: true,\n  composed: true,\n  detail: { query: this.searchQuery }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders search input, suggestions panel, optional map |\n| **View** | `false` | Renders address as static text, optional map |\n\n- In view mode: no input, no suggestions, no search events, no error, no helper\n\n---\n\n## 7. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until a location is selected |\n| No `<Item>` inside `<Suggestions>` | Render Empty slot or default \"No results\" message |\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Focused** | Search input border highlighted |\n| **Open** | Suggestions panel visible |\n| **Selected** | Address displayed in input, map pin updated |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No editing, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator; suggestions panel disabled |\n| **View Mode** | Address as plain text, optional map |\n\n---\n\n## 10. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Parse value \u2192 { lat, lng } or null\n     IF value: find matching <Item> label or display raw \"lat, lng\"\n     ELSE: render Empty slot or \"\u2014\"\n  3. IF showMap AND value: render map preview with pin at lat/lng\n  4. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Search input row:\n     - Text input bound to searchQuery\n       - @input: update searchQuery, emit `search`, set isOpen=true\n       - @focus: emit `focus` event\n       - @blur: emit `blur` event\n       - placeholder from prop or i18n default\n     - IF allowGeolocation: render geolocation button\n       - IF hasSlot('Trigger'): use Trigger content as button label\n       - @click: call navigator.geolocation.getCurrentPosition()\n     - IF loading: render loading indicator, disable input and button\n\n  4. IF isOpen AND hasSlot('Suggestions'):\n     - Read items from <Suggestions> slot:\n       const items = Array.from(suggestionsEl.querySelectorAll('Item')).map(...)\n     - IF items.length > 0:\n         FOR each item: render address row (unsafeHTML for label)\n           Highlight if item.value === value\n           @click: set value = item.value, searchQuery = item.label\n                   isOpen = false, emit `change`\n     - ELSE: render Empty slot or default \"No results\" message\n\n  5. IF showMap AND value:\n     - Parse value \u2192 { lat, lng }\n     - Render map preview with pin at lat/lng\n\n  6. Below input:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Search input | `role=\"combobox\"`, `aria-expanded`, `aria-autocomplete=\"list\"` |\n| Suggestions panel | `role=\"listbox\"` |\n| Suggestion items | `role=\"option\"`, `aria-selected` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Geolocation button | `aria-label=\"Use current location\"` |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n| 1.1.0 | 2026-04-21 | Suggestions via Slot Tags; value simplified to \"lat,lng\" string |\n";
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupLocatePosition/usage" {
    export const skill = "\n\n# locate + position \u2014 Usage\n\n> Quick reference for using molecules in the **locate + position** group.\n> Use this when you need the user to **inform or visualize a geographic location**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom label for the geolocation button |\n| `Suggestions` | Container for suggestion items, populated by the page |\n| `Item` | One suggestion inside `<Suggestions>`. Attribute: `value` = `\"lat,lng\"`. Content = address label |\n| `Empty` | Content shown when no location is selected or no suggestions found |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Coordinates as `\"lat,lng\"` (e.g. `\"-23.55,-46.63\"`) or `null` |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Placeholder text for the search input |\n| `show-map` | `boolean` | `false` | Show an embedded map preview of the selected location |\n| `allow-geolocation` | `boolean` | `false` | Show a button to capture the user's current position |\n| `is-editing` | `boolean` | `true` | `true` = interactive input, `false` = read-only text |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents editing but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a location as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator (e.g. while fetching suggestions) |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when a location is selected. Value is `\"lat,lng\"` or null |\n| `search` | `{ query: string }` | Fired when the user types. Page must update `<Suggestions>` items in response |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- `value` is a plain **string** in `\"lat,lng\"` format (e.g. `\"-23.55,-46.63\"`)\n- `null` when nothing is selected\n- Suggestions are provided via `<Item>` elements inside the `<Suggestions>` slot tag\n\n---\n\n## Search Flow\n\nThe molecule does **not** call any API directly. The page is responsible for fetching suggestions:\n\n```\n1. User types \u2192 molecule emits `search` with { query }\n2. Page calls BFF, receives address list\n3. Page updates <Suggestions> slot with <Item> elements\n4. Molecule renders the suggestion list\n5. User selects \u2192 molecule sets value = item.value, emits `change`\n```\n\n---\n\n## Examples\n\n### Address autocomplete\n\n```html\n<molecules--address-autocomplete-102020\n  value=\"{{ui.order.deliveryCoords}}\"\n  error=\"{{ui.order.addressError}}\"\n  placeholder=\"Search address...\"\n  required>\n  <Label>Delivery Address</Label>\n  <Suggestions>\n    <Item value=\"-23.55,-46.63\">S\u00E3o Paulo, SP</Item>\n    <Item value=\"-22.90,-43.17\">Rio de Janeiro, RJ</Item>\n  </Suggestions>\n</molecules--address-autocomplete-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupRateItem/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupRateItem/creation" {
    export const skill = "\n# rate + item \u2014 Creation\n\n> Implementation reference for creating molecules in the **rate + item** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `rate + item` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Item` | No | Defines one selectable rating option. Attribute: `value` (required). Content = visual label (emoji, icon, text) |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Item'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Item value=\"...\">\n\u2514\u2500\u2500 <Helper>\n```\n\n### Item vs Auto-generate\n\n- **If `<Item>` slots exist:** render only the declared items. `min`, `max`, `step` are ignored\n- **If no `<Item>` slots:** auto-generate options from `min` to `max` with `step` increments, using the implementation's default visual (stars, dots, numbers, etc.)\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Currently selected rating value |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `min` | `number` | `0` | `@propertyDataSource` | Minimum rating value (used when no `<Item>` slots) |\n| `max` | `number` | `5` | `@propertyDataSource` | Maximum rating value (used when no `<Item>` slots) |\n| `step` | `number` | `1` | `@propertyDataSource` | Increment between values (used when no `<Item>` slots) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A rating is required |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `hoverValue` | `number | null` | `null` | `@state` | Value being hovered (for visual preview before selection) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a native **number**\n- `null` means no rating selected\n- When using `<Item>` slots, value matches the `value` attribute of the selected item (parsed as number)\n- When auto-generated, value is a number in the `min`\u2013`max` range\n\n### View Mode\n\n- If `value` is `null`: display `\"\u2014\"`\n- Otherwise: display the selected rating visually (filled stars, highlighted emoji, etc.)\n- No hover effect, no interaction\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: number | null }` | \u2713 | Rating selected |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders interactive rating options |\n| **View** | `false` | Renders selected value as static visual |\n\n- In view mode: no interaction, no hover, no events, no error, no helper\n\n---\n\n## 7. Hover Behavior\n\nWhen editing and not disabled/readonly:\n\n- On mouse enter over an option: set `hoverValue` to that option's value\n- All options up to `hoverValue` are visually highlighted (for cumulative implementations like stars)\n- For discrete implementations (emoji, thumbs): only the hovered option is highlighted\n- On mouse leave: reset `hoverValue` to `null`, visual returns to reflect `value`\n- On click: set `value` = clicked option's value, emit `change`\n\n---\n\n## 8. Reading Items\n\nWhen `<Item>` slots are present, read them inline using `getSlots`:\n\n```typescript\nconst items = this.getSlots('Item').map(el => ({\n  value: Number(el.getAttribute('value')),\n  label: el.innerHTML,\n}));\n```\n\nWhen no `<Item>` slots, generate options:\n\n```typescript\nconst items = [];\nfor (let v = this.min; v <= this.max; v += this.step) {\n  items.push({ value: v, label: '' });\n}\n```\n\n---\n\n## 9. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until a rating is selected |\n\n---\n\n## 10. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 11. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance, no selection |\n| **Hovered** | Preview highlight on the hovered option |\n| **Selected** | Selected value visually active |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No interaction, selected value visible |\n| **Error** | Error border/style, error message visible |\n| **View Mode** | Static visual of selected value |\n\n---\n\n## 12. Rendering Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. IF value is null: render \"\u2014\"\n     ELSE: render selected rating visual (filled stars, highlighted emoji, etc.)\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Determine items:\n     IF hasSlot('Item'): read items from slot tags\n     ELSE: auto-generate from min/max/step\n\n  4. Render option row:\n     FOR each item:\n       - Render visual (star icon, emoji content via unsafeHTML, number, etc.)\n       - Apply highlight:\n         IF hoverValue !== null: highlight based on hoverValue\n         ELSE: highlight based on value\n       - @mouseenter: set hoverValue = item.value (unless disabled/readonly)\n       - @mouseleave: set hoverValue = null\n       - @click: set value = item.value, emit `change` (unless disabled/readonly)\n       - @focus/@blur: emit focus/blur events\n\n  5. Below options:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 13. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Container | `role=\"radiogroup\"` |\n| Each option | `role=\"radio\"`, `aria-checked`, `aria-label` with the value |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Keyboard | `ArrowLeft`/`ArrowRight` navigate options; `Enter`/`Space` selects |\n\n---\n\n\n## 14. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupRateItem/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupRateItem/usage" {
    export const skill = "\n# rate + item \u2014 Usage\n\n> Quick reference for using molecules in the **rate + item** group.\n> Use this when you need the user to **rate or score an item**.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Item` | One rating option. Attribute: `value` (required). Content = visual label (emoji, icon, text). When no `<Item>` is declared, options are auto-generated from `min`/`max`/`step` |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Selected rating value. `null` = no rating |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `min` | `number` | `0` | Minimum value (ignored when `<Item>` slots are present) |\n| `max` | `number` | `5` | Maximum value (ignored when `<Item>` slots are present) |\n| `step` | `number` | `1` | Increment between values (ignored when `<Item>` slots are present) |\n| `is-editing` | `boolean` | `true` | `true` = interactive, `false` = read-only visual |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents selection but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a rating as required |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: number | null }` | Fired when a rating is selected |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is a plain **number** representing the selected rating\n- `null` when no rating is selected\n- When using `<Item>` slots, `value` matches the item's `value` attribute (parsed as number)\n- When auto-generated, `value` is in the `min`\u2013`max` range\n\n\n---\n\n## Examples\n\n### Star rating (auto-generated, 1\u20135)\n\n```html\n<molecules--star-rating-102020\n  value=\"{{ui.review.rating}}\"\n  error=\"{{ui.review.ratingError}}\"\n  min=\"1\"\n  max=\"5\"\n  required>\n  <Label>Rate this product</Label>\n</molecules--star-rating-102020>\n```\n\n### Thumbs up/down\n\n```html\n<molecules--thumbs-102020\n  value=\"{{ui.comment.vote}}\">\n  <Item value=\"0\">\uD83D\uDC4E</Item>\n  <Item value=\"1\">\uD83D\uDC4D</Item>\n</molecules--thumbs-102020>\n```\n\n\n```\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/creation" {
    export const skill = "\n# select + fileForUpload \u2014 Creation\n\n> Implementation reference for creating molecules in the **select + fileForUpload** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `select + fileForUpload` |\n| **Category** | Data Entry |\n| **Version** | `1.0.1` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the file selection button or drop zone |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `File[]` | `[]` | `@propertyDataSource` | Currently selected files |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `multiple` | `boolean` | `false` | `@propertyDataSource` | Allow selecting more than one file |\n| `accept` | `string` | `''` | `@propertyDataSource` | Accepted file types (e.g. `'image/*'`, `'.pdf,.docx'`) |\n| `maxSizeKb` | `number` | `0` | `@propertyDataSource` | Maximum file size in KB per file (0 = no limit) |\n| `maxFiles` | `number` | `0` | `@propertyDataSource` | Maximum number of files when `multiple=true` (0 = no limit) |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (e.g. upload in progress, controlled by page) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isDragging` | `boolean` | `false` | `@state` | Whether a file is being dragged over the drop zone |\n\n---\n\n## 4. Value Contract\n\n- `value` holds the current `File[]` bound to the global state via `@propertyDataSource`\n- Default is `[]` (empty array)\n- When the user selects or drops files, they are validated and merged into `value`\n- When the user removes a file, it is removed from `value`\n- The page reads `value` from the state and is responsible for uploading via BFF\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `reject` | `{ files: File[], reason: 'size' | 'type' | 'count' }` | \u2713 | Fired when files are rejected due to validation |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('reject', {\n  bubbles: true,\n  composed: true,\n  detail: { files: rejectedFiles, reason: 'size' }\n}));\n```\n\n---\n\n## 6. File Validation\n\nValidation happens before adding files to `value`. Invalid files are emitted via `reject`.\n\n| Rule | Condition | Reject reason |\n|------|-----------|---------------|\n| File type | `accept` is set and file type does not match | `'type'` |\n| File size | `maxSizeKb > 0` and file size exceeds limit | `'size'` |\n| File count | `maxFiles > 0` and total count would exceed limit | `'count'` |\n\n- Valid files are merged into `value`\n- Invalid files are emitted via `reject` event\n- If all files are invalid, `value` remains unchanged\n\n---\n\n## 7. Drag and Drop\n\nWhen the implementation supports drag and drop:\n\n```\n@dragover: preventDefault(), set isDragging = true\n@dragleave: set isDragging = false\n@drop: preventDefault(), set isDragging = false\n        extract files from event.dataTransfer.files\n        run validation, add valid files to value, emit reject for invalid\n```\n\n- `isDragging` drives the visual highlight of the drop zone\n- Drop zone must call `event.preventDefault()` on `dragover` to allow dropping\n\n---\n\n## 8. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Page/Organism is responsible for setting the error message\n- Validation rejections are surfaced via the `reject` event \u2014 page decides how to display them\n\n---\n\n## 9. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Dragging** | Drop zone highlighted, visual feedback |\n| **Disabled** | Reduced opacity, no interaction, drag ignored |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator visible, interaction blocked |\n\n---\n\n## 10. Rendering Logic\n\n```\nRENDER:\n\n1. Container \u2014 apply state styles (error, disabled, dragging)\n\n2. IF hasSlot('Label'): render label\n\n3. Drop zone / trigger area:\n   - IF hasSlot('Trigger'): render Trigger content\n     ELSE: render default icon + instruction text (i18n)\n   - Hidden <input type=\"file\"> bound to accept and multiple\n   - @click on zone: trigger input.click() (unless disabled/loading)\n   - @dragover: preventDefault(), isDragging = true\n   - @dragleave: isDragging = false\n   - @drop: extract files, validate, add valid to value, emit reject for invalid\n   - @change on input: extract files, validate, add valid to value, emit reject for invalid\n\n4. IF value.length > 0: render file list\n   FOR each file in value:\n     - File name\n     - File size (formatted, e.g. \"1.2 MB\")\n     - Remove button \u2192 remove from value\n\n5. IF loading: render loading indicator, block interaction\n\n6. Below zone:\n   IF error !== '': render error message\n   ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 11. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Input | `<input type=\"file\">` always present (visually hidden) |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Drop zone | `role=\"button\"`, `tabindex=\"0\"`, `aria-label` describing action |\n| Keyboard | `Enter`/`Space` on drop zone triggers file picker |\n\n---\n\n## 12. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectFileForUpload/usage" {
    export const skill = "\n# select + fileForUpload \u2014 Usage\n\n> Quick reference for using molecules in the **select + fileForUpload** group.\n> Use this when you need the user to **select files to be uploaded**.\n\n---\n\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom content for the file selection button or drop zone |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `File[]` | `[]` | Currently selected files, bound to state |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `multiple` | `boolean` | `false` | Allow selecting more than one file |\n| `accept` | `string` | `''` | Accepted file types (e.g. `'image/*'`, `'.pdf,.docx'`) |\n| `max-size-kb` | `number` | `0` | Maximum file size in KB per file (0 = no limit) |\n| `max-files` | `number` | `0` | Maximum number of files when `multiple=true` (0 = no limit) |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `loading` | `boolean` | `false` | Shows a loading indicator (e.g. upload in progress) |\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `reject` | `{ files: File[], reason: 'size' | 'type' | 'count' }` | Fired when files are rejected due to validation |\n\n---\n\n## Value Contract\n\n- `value` holds the current `File[]` bound to the global state\n- Files are added on selection/drop and removed via the file list UI\n- The page reads `value` from state and is responsible for uploading via BFF\n- Use the `loading` property to block interaction while an upload is in progress\n\n\n---\n\n## Examples\n\n### Simple file button\n\n```html\n<molecules--file-button-102020\n  value=\"{{ui.form.attachments}}\"\n  accept=\".pdf,.docx\"\n  error=\"{{ui.form.attachmentError}}\">\n  <Label>Attachment</Label>\n  <Helper>PDF or Word, up to 5MB</Helper>\n</molecules--file-button-102020>\n```\n\n### Multi-file drag-drop zone\n\n```html\n<molecules--dropzone-102020\n  value=\"{{ui.upload.files}}\"\n  multiple=\"true\"\n  accept=\"image/*\"\n  max-size-kb=\"2048\"\n  max-files=\"5\"\n  loading=\"{{ui.upload.loading}}\"\n  error=\"{{ui.upload.error}}\">\n  <Label>Product Images</Label>\n  <Trigger>Drop images here or click to browse</Trigger>\n  <Helper>Up to 5 images, max 2MB each</Helper>\n</molecules--dropzone-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/creation" {
    export const skill = "# select + one \u2014 Creation\n\n> Implementation reference for creating molecules in the **select + one** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `select + one` |\n| **Category** | Data Entry |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\n| Tag | Required | Description |\n|-----|:--------:|-------------|\n| `Label` | No | Label displayed above or beside the field |\n| `Helper` | No | Help text displayed below the field |\n| `Trigger` | No | Custom content for the trigger button. When no item is selected, this content acts as the placeholder |\n| `Item` | Yes | Defines one selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | No | Groups items under a named heading. Attribute: `label` |\n| `Empty` | No | Content shown when no items are available |\n\n```typescript\nslotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];\n```\n\n### Slot Hierarchy\n\n```\ncomponent (root)\n\u251C\u2500\u2500 <Label>\n\u251C\u2500\u2500 <Trigger>\n\u251C\u2500\u2500 <Group label=\"...\">\n\u2502   \u2514\u2500\u2500 <Item value=\"...\">\n\u251C\u2500\u2500 <Item value=\"...\">\n\u251C\u2500\u2500 <Empty>\n\u2514\u2500\u2500 <Helper>\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `string | null` | `null` | `@propertyDataSource` | Value of the currently selected item |\n| `error` | `string` | `''` | `@propertyDataSource` | Error message (empty = no error) |\n| `name` | `string` | `''` | `@propertyDataSource` | Field name (for forms) |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `placeholder` | `string` | `''` | `@propertyDataSource` | Text shown when no item is selected (fallback when no `Trigger` slot) |\n| `searchable` | `boolean` | `false` | `@propertyDataSource` | Show a search input inside the selector to filter items |\n\n### 3.3 States\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isEditing` | `boolean` | `true` | `@propertyDataSource` | Edit mode (true) or view mode (false) |\n| `disabled` | `boolean` | `false` | `@propertyDataSource` | Field is disabled |\n| `readonly` | `boolean` | `false` | `@propertyDataSource` | Field is read-only |\n| `required` | `boolean` | `false` | `@propertyDataSource` | A selection is required |\n| `loading` | `boolean` | `false` | `@propertyDataSource` | Loading state (items not yet available) |\n\n### 3.4 Internal State\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `isOpen` | `boolean` | `false` | `@state` | Whether the selector panel is currently open |\n| `searchQuery` | `string` | `''` | `@state` | Current search filter text (used when `searchable=true`) |\n\n---\n\n## 4. Value Contract\n\n### Storage Format\n\n- Value stored and emitted as a plain **string** matching the `value` attribute of the selected `<Item>`\n- `null` means no item selected\n- The label displayed in the trigger is read from the selected `<Item>` inner content \u2014 never stored\n\n### View Mode\n\n- If value is `null`: display placeholder or `\"\u2014\"`\n- Otherwise: display the label of the selected item as plain text\n- Label is obtained via `this.findItem(this.value)?.label`\n\n---\n\n## 5. Events\n\n| Event | Detail | Bubbles | Description |\n|-------|--------|:-------:|-------------|\n| `change` | `{ value: string | null }` | \u2713 | Selection confirmed |\n| `blur` | `{}` | \u2713 | Field lost focus |\n| `focus` | `{}` | \u2713 | Field received focus |\n\n### Dispatch Example\n\n```typescript\nthis.dispatchEvent(new CustomEvent('change', {\n  bubbles: true,\n  composed: true,\n  detail: { value: this.value }\n}));\n```\n\n---\n\n## 6. isEditing Mode\n\n| Mode | `isEditing` | Behavior |\n|------|-------------|----------|\n| **Edit** | `true` | Renders trigger button + selector panel |\n| **View** | `false` | Renders selected item label as static text |\n\n- In view mode: no trigger, no panel, no events, no error, no helper\n\n---\n\n## 7. Open/Close Behavior\n\n- Clicking the trigger toggles `isOpen`\n- Selecting an item sets `value`, closes the panel (`isOpen = false`), emits `change`\n- Pressing `Escape` closes the panel without changing value\n- Clicking outside the component closes the panel (use a `@click` listener on `document` in `connectedCallback`, remove in `disconnectedCallback`)\n- When `disabled` or `readonly`: trigger click is ignored, panel never opens\n\n---\n\n## 8. Validation Rules\n\n| Rule | Behavior |\n|------|----------|\n| `required` and `value === null` | Error state until an item is selected |\n| Item with `disabled` attribute | Rendered but not selectable; clicking it is ignored |\n\n---\n\n## 9. Error Handling\n\n| `error` value | Behavior |\n|---------------|----------|\n| `''` | No error \u2014 show Helper if slot exists |\n| `'any message'` | Show error message, apply error visual state |\n\n- Error never shown in view mode\n- Page/Organism is responsible for setting the error message\n\n---\n\n## 10. Visual States\n\n| State | Behavior |\n|-------|----------|\n| **Normal** | Default appearance |\n| **Open** | Selector panel visible |\n| **Selected** | Trigger shows selected item label |\n| **Disabled** | Reduced opacity, no interaction |\n| **Readonly** | No interaction, text selectable |\n| **Error** | Error border/style, error message visible |\n| **Loading** | Loading indicator in trigger; panel does not open |\n| **View Mode** | Selected label as plain text |\n\n---\n\n## 11. Rendering Logic\n\n### Reading items and groups inline\n\nUse `getSlots` directly inside `render()` \u2014 no helper methods needed:\n\n```typescript\n// Read all items\nconst items = this.getSlots('Item').map(el => ({\n  value: el.getAttribute('value') || '',\n  label: el.innerHTML,\n  disabled: el.hasAttribute('disabled'),\n}));\n\n// Read groups with their nested items\nconst groups = this.getSlots('Group').map(group => ({\n  label: group.getAttribute('label') || '',\n  items: Array.from(group.querySelectorAll('Item')).map(el => ({\n    value: el.getAttribute('value') || '',\n    label: el.innerHTML,\n    disabled: el.hasAttribute('disabled'),\n  })),\n}));\n\n// Find selected item label\nconst selectedLabel = items.find(i => i.value === this.value)?.label || null;\n\n// Filter when searchable\nconst q = this.searchQuery.toLowerCase();\nconst filtered = items.filter(i => i.label.toLowerCase().includes(q));\n```\n\n### Logic\n\n```\nRENDER:\n\nIF isEditing === false (View Mode):\n  1. IF hasSlot('Label'): render label\n  2. Render selected item label or placeholder or \"\u2014\"\n  3. RETURN\n\nIF isEditing === true (Edit Mode):\n  1. Container \u2014 apply state styles\n\n  2. IF hasSlot('Label'): render label\n\n  3. Trigger button:\n     - IF loading: render loading indicator, disable trigger\n     - IF value is set: render selected item label\n       ELSE: render Trigger slot content or placeholder or \"\u2014\"\n     - Chevron icon indicating open/closed state\n     - @click: toggle isOpen (unless disabled/readonly/loading)\n     - @blur: emit `blur` event\n     - @focus: emit `focus` event\n\n  4. IF isOpen:\n     Selector panel:\n     - IF searchable: render search input bound to searchQuery\n     - IF groups exist:\n         FOR each group: render group label + group items\n         Render standalone items after groups\n       ELSE:\n         Render all items (filtered by searchQuery if searchable)\n     - FOR each item:\n         Highlight if item.value === value (currently selected)\n         Dim if item.disabled\n         @click: IF NOT disabled \u2192 set value, isOpen=false, emit `change`\n     - IF no items (or all filtered out): render Empty slot or default message\n\n  5. Below trigger:\n     IF error !== '': render error message\n     ELSE IF hasSlot('Helper'): render helper text\n```\n\n---\n\n## 12. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Trigger | `role=\"combobox\"`, `aria-expanded`, `aria-haspopup=\"listbox\"` |\n| Panel | `role=\"listbox\"` |\n| Items | `role=\"option\"`, `aria-selected`, `aria-disabled` |\n| Label | `aria-labelledby` pointing to rendered label |\n| Error | `aria-describedby` pointing to error element |\n| Invalid | `aria-invalid=\"true\"` when error exists |\n| Required | `aria-required=\"true\"` |\n| Keyboard | `ArrowDown`/`ArrowUp` navigate items; `Enter` selects; `Escape` closes |\n\n---\n\n## 13. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-20 | Initial creation reference |\n| 1.1.0 | 2026-04-20 | Removed item parsing helpers; inline pattern in Rendering Logic |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectOne/usage" {
    export const skill = "\n# select + one \u2014 Usage\n\n> Quick reference for using molecules in the **select + one** group.\n> Use this when you need the user to **choose exactly one option** from a list.\n\n---\n\n## Slot Tags\n\n| Tag | Description |\n|-----|-------------|\n| `Label` | Label displayed above or beside the field |\n| `Helper` | Descriptive text shown below the field when there is no error |\n| `Trigger` | Custom content for the trigger button. When no item is selected, this content acts as the placeholder |\n| `Item` | One selectable option. Attributes: `value` (required), `disabled` |\n| `Group` | Groups items under a named heading. Attribute: `label` |\n| `Empty` | Content shown when no items are available |\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `string | null` | `null` | Value of the selected item. `null` = nothing selected |\n| `error` | `string` | `''` | Error message. Empty string means no error |\n| `name` | `string` | `''` | Field name for form identification |\n| `placeholder` | `string` | `''` | Text shown when no item is selected |\n| `searchable` | `boolean` | `false` | Show a search input to filter items |\n| `isEditing` | `boolean` | `true` | `true` = interactive selector, `false` = read-only label |\n| `disabled` | `boolean` | `false` | Disables the field entirely |\n| `readonly` | `boolean` | `false` | Prevents selection but keeps the field focusable |\n| `required` | `boolean` | `false` | Marks a selection as required |\n| `loading` | `boolean` | `false` | Shows a loading indicator; panel does not open |\n\n\n---\n\n## Events\n\n| Event | Detail | Description |\n|-------|--------|-------------|\n| `change` | `{ value: string | null }` | Fired when an item is selected |\n| `blur` | `{}` | Fired when the field loses focus |\n| `focus` | `{}` | Fired when the field receives focus |\n\n---\n\n## Value Format\n\n- Value is a plain **string** matching the `value` attribute of the selected `<Item>`\n- `null` when nothing is selected\n- The displayed label comes from the `<Item>` inner content \u2014 not stored in `value`\n\n---\n\n## Examples\n\n### Simple dropdown\n\n```html\n<molecules--dropdown-102020\n  value=\"{{ui.form.country}}\"\n  error=\"{{ui.form.countryError}}\"\n  required>\n  <Label>Country</Label>\n  <Trigger>Select a country...</Trigger>\n  <Item value=\"br\">Brazil</Item>\n  <Item value=\"us\">United States</Item>\n  <Item value=\"de\">Germany</Item>\n</molecules--dropdown-102020>\n```\n\n### Grouped options\n\n```html\n<molecules--dropdown-102020\n  value=\"{{ui.form.category}}\"\n  error=\"{{ui.form.categoryError}}\">\n  <Label>Category</Label>\n  <Trigger>Select a category...</Trigger>\n  <Group label=\"Electronics\">\n    <Item value=\"phones\">Phones</Item>\n    <Item value=\"laptops\">Laptops</Item>\n  </Group>\n  <Group label=\"Clothing\">\n    <Item value=\"shirts\">Shirts</Item>\n    <Item value=\"shoes\">Shoes</Item>\n  </Group>\n  <Empty>No categories available</Empty>\n</molecules--dropdown-102020>\n```\n\n";
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/creation.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/creation" {
    export const skill = "\n# show + progress \u2014 Creation\n\n> Implementation reference for creating molecules in the **show + progress** group.\n> Follow the general Lit/Aura rules defined in `molecule-generation2.md`.\n\n---\n\n## 1. Metadata\n\n| Field | Value |\n|-------|-------|\n| **Group** | `show + progress` |\n| **Category** | Feedback |\n| **Version** | `1.0.0` |\n\n---\n\n## 2. Slot Tags\n\nThis component has **no slot tags**. It is a visual primitive designed to be composed inside other components (e.g. button with spinner, upload zone with progress bar).\n\n```typescript\nslotTags = [];\n```\n\n---\n\n## 3. Properties\n\n### 3.1 Data\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `value` | `number | null` | `null` | `@propertyDataSource` | Progress percentage 0\u2013100. `null` = indeterminate mode |\n\n### 3.2 Configuration\n\n| Property | Type | Default | Decorator | Description |\n|----------|------|---------|-----------|-------------|\n| `size` | `string` | `'md'` | `@propertyDataSource` | Visual size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `label` | `string` | `''` | `@propertyDataSource` | Accessible label describing what is loading |\n| `showValue` | `boolean` | `false` | `@propertyDataSource` | Display the numeric percentage alongside the indicator |\n\n---\n\n## 4. Value Contract\n\n### Determinate Mode (`value` is a number)\n\n- `value` is clamped to `0\u2013100` before rendering\n- Represents the completion percentage of the operation\n- When `showValue=true`, display formatted as `\"42%\"`\n\n### Indeterminate Mode (`value` is `null`)\n\n- Renders an animated indicator with no specific progress\n- `showValue` is ignored \u2014 no percentage to display\n- Used when the total duration or size is unknown\n\n---\n\n## 5. Events\n\nThis component emits **no events**. It is purely visual.\n\n---\n\n## 6. Visual States\n\n| State | Condition | Behavior |\n|-------|-----------|----------|\n| **Indeterminate** | `value === null` | Animated loop (spinning, pulsing, or sliding) |\n| **Progress** | `value >= 0 && value < 100` | Partial fill reflecting the percentage |\n| **Complete** | `value === 100` | Full fill, animation stops |\n\n---\n\n## 7. Size Mapping\n\n| Size | Typical dimension |\n|------|-------------------|\n| `xs` | 12\u201316px (inline with text) |\n| `sm` | 20\u201324px (inside buttons) |\n| `md` | 32\u201340px (standalone) |\n| `lg` | 48\u201364px (prominent, page-level) |\n\nExact dimensions are implementation-specific (bar height, ring diameter, spinner size).\n\n---\n\n## 8. Rendering Logic\n\n```\nRENDER:\n\n1. Clamp value: IF value !== null \u2192 clamp to 0\u2013100\n\n2. Container \u2014 apply size classes\n\n3. IF value === null (Indeterminate):\n   - Render animated indicator (CSS animation)\n   - aria-label from label prop or i18n default\n\n4. IF value !== null (Determinate):\n   - Render indicator with fill at value%\n   - IF showValue: render \"value%\" text\n   - aria-valuenow = value\n   - aria-valuemin = 0\n   - aria-valuemax = 100\n```\n\n---\n\n## 9. Accessibility (a11y)\n\n| Requirement | Implementation |\n|-------------|----------------|\n| Role | `role=\"progressbar\"` |\n| Label | `aria-label` from `label` prop |\n| Determinate | `aria-valuenow`, `aria-valuemin=\"0\"`, `aria-valuemax=\"100\"` |\n| Indeterminate | Omit `aria-valuenow` (screen readers announce as indeterminate) |\n\n---\n\n## 10. Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 2026-04-21 | Initial creation reference |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/usage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupShowProgress/usage" {
    export const skill = "\n# show + progress \u2014 Usage\n\n> Quick reference for using molecules in the **show + progress** group.\n> Use this when the system needs to **indicate the progress of an operation**.\n> This is a visual primitive \u2014 designed to be composed inside other components.\n\n---\n\n\n## Slot Tags\n\nNone. This component has no slot tags.\n\n---\n\n## Properties\n\n| Property | Type | Default | Description |\n|----------|------|---------|-------------|\n| `value` | `number | null` | `null` | Progress 0\u2013100. `null` = indeterminate (unknown duration) |\n| `size` | `string` | `'md'` | Visual size: `'xs'`, `'sm'`, `'md'`, `'lg'` |\n| `label` | `string` | `''` | Accessible label describing what is loading |\n| `show-value` | `boolean` | `false` | Display the percentage number alongside the indicator |\n\n---\n\n## Events\n\nNone. This component is purely visual.\n\n---\n\n## Value Format\n\n- `number` (0\u2013100): determinate progress, renders a fill at that percentage\n- `null`: indeterminate, renders an animated loop (spinner, pulse, sliding bar)\n\n---\n\n## Examples\n\n### Spinner inside a button (indeterminate)\n\n```html\n<molecules--spinner-102020\n  size=\"sm\"\n  label=\"Saving...\">\n</molecules--spinner-102020>\n```\n\n\n### Determinate ring with percentage\n\n```html\n<molecules--progress-ring-102020\n  value=\"{{ui.report.progress}}\"\n  size=\"md\"\n  show-value=\"true\"\n  label=\"Generating report\">\n</molecules--progress-ring-102020>\n```\n";
}
