declare module "_102020_/l2/aura.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/aura" {
    export class Aura {
        private channel?;
        private mode;
        running: boolean;
        open(name?: string): this;
        listen(mode?: 'develpoment' | 'production'): this;
        send(url: string, options: any): Promise<Response>;
        close(): this;
    }
    export interface RequestMsgBase {
        type: "fetch-request";
        server: string;
        url: string;
        id: string;
        options: string;
        headers: any;
    }
    export interface ResponseMsgBase {
        type: "fetch-response";
        id: string;
        body: string;
        status: number;
        headers: any;
    }
}
declare module "_102020_/l2/auraOrganismBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/auraOrganismBase" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    export class AuraOrganismBase extends CollabLitElement {
    }
}
declare module "_102020_/l2/build.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/build" {
    export const DISTFOLDER = "wwwroot";
    export function buildModule(project: number, moduleName: string): Promise<boolean>;
}
declare module "_102020_/l2/collabAuraLiveView.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/collabAuraLiveView" {
    import { CollabLitElement } from '_102027_/l2/collabLitElement';
    import '/_100554_/l2/collabNav4Menu.js';
    interface ITab {
        moduleName: string;
        modulePath: string;
        project: number;
        pageInitial: string;
        actualPage: string;
        icon: string | undefined;
        target: string;
        iframe: HTMLIFrameElement | undefined;
    }
    export class CollabAuraLiveView102020 extends CollabLitElement {
        private msg;
        mode: 'develpoment' | 'production';
        actualTab: number;
        tabsMenu: any;
        lastInit: number;
        container?: HTMLElement;
        tabs: ITab[];
        private liveViewReady;
        get iframe(): HTMLIFrameElement | null;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        init(project: number, shortName: string, folder: string): Promise<void>;
        private setEvents;
        private onTabSelected;
        private onTabClosed;
        private checkToLoadPage;
        private setInitialTabInfos;
        private setActualTabInfos;
        private openTab;
        private closeTab;
        private addTab;
        private load;
        private toogleLoading;
        private loadPage;
        private loadInProduction;
        private loadInDevelopment;
        private APP_ID;
        private clearOldPageScripts;
        private injectHTML;
        private injectJS;
        private injectScriptRunTime;
        private injectGlobalStyle;
        private functionReplaceAnchor;
        private addStyleApp;
        private addScript;
    }
}
declare module "_102020_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102020_/l2/enhancementAura.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/enhancementAura" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_102020_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102020_/l2/start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/start" {
    export function start(): void;
}
declare module "_102020_/l2/agents/agentNewMolecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMolecule" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string;
    };
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculeDefs" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string;
    };
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/agentNewMoleculePlanner" {
    import { IAgentAsync } from '_100554_/l2/aiAgentBase';
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "clarification";
        json: TClarification;
    };
    export interface TClarification {
        fileReference: string;
        description: string;
        finalPrompt: string;
        group: string;
        functionalRequirements: string[];
        visualRequirements: string[];
    }
}
declare module "_102020_/l2/agents/templates/molecule.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/agents/templates/molecule" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class TemplateMolecule extends StateLitElement {
        private msg;
        /**
      * =========================================================================
      * INPUT DATA (FROM ORGANISMS)
      * =========================================================================
      * Molecules SHOULD receive business data via @propertyDataSource or propertyCompositeDataSource when possible.
      */
        value: number | undefined;
        hint: string;
        label: string;
        loading: boolean;
        render(): any;
    }
}
declare module "_102020_/l2/molecules/card.defs" {
    export const group = "groupCard";
    export const skill = "\n\n# Objective\nPermitir exibir um Card com face frontal e verso, contendo se\u00E7\u00F5es header/body/footer e suporte opcional a imagem no header. O Card deve alternar entre frente e verso ao ser acionado por clique ou teclado, com anima\u00E7\u00E3o de flip e comportamento acess\u00EDvel e responsivo.\n\n# Responsibilities\n- Exibir uma face frontal composta por tr\u00EAs \u00E1reas distintas: header, body e footer.\n- Permitir fornecer conte\u00FAdo para header, body e footer por meio de \u00E1reas dedicadas de inser\u00E7\u00E3o de conte\u00FAdo.\n- Permitir configurar uma imagem no header por propriedades de fonte e texto alternativo, com op\u00E7\u00E3o de exibir ou ocultar a imagem.\n- Quando a imagem n\u00E3o estiver configurada ou estiver desabilitada, n\u00E3o exibir a imagem e aplicar o comportamento de layout esperado para essa aus\u00EAncia.\n- Exibir uma face traseira (verso) com conte\u00FAdo adicional fornecido em uma \u00E1rea dedicada.\n- Alternar entre estado \u201Cfrente\u201D e \u201Cverso\u201D quando o Card for acionado:\n  - Primeiro acionamento exibe o verso.\n  - Segundo acionamento retorna \u00E0 frente.\n- Executar uma anima\u00E7\u00E3o de flip (giro 3D) durante a altern\u00E2ncia, mantendo frente e verso alinhados e ocupando o mesmo espa\u00E7o visual.\n- Permitir altern\u00E2ncia via teclado quando o Card estiver focado (Enter e Espa\u00E7o).\n- Expor o estado atual de flip como propriedade/atributo observ\u00E1vel (\u201Cflipped\u201D) para permitir integra\u00E7\u00E3o e estiliza\u00E7\u00E3o externa.\n- Emitir um evento customizado a cada altern\u00E2ncia, contendo no detalhe o estado atual (flipped: true/false).\n- Prover comportamento acess\u00EDvel quando acion\u00E1vel:\n  - Ser foc\u00E1vel por teclado.\n  - Possuir sem\u00E2ntica/role apropriado para intera\u00E7\u00E3o.\n  - Refletir o estado atual em atributo ARIA equivalente.\n- Respeitar a prefer\u00EAncia do usu\u00E1rio por redu\u00E7\u00E3o de movimento, reduzindo ou desabilitando a anima\u00E7\u00E3o de flip.\n- Garantir que elementos interativos contidos no Card (por exemplo, links e bot\u00F5es) possam, de forma configur\u00E1vel, n\u00E3o disparar o flip ao serem acionados.\n\n# Constraints\n- N\u00E3o deve depender de bibliotecas externas.\n- O verso deve ocupar exatamente a mesma \u00E1rea do Card, sem alterar o tamanho geral durante a altern\u00E2ncia.\n- A altern\u00E2ncia deve ser determin\u00EDstica e sempre refletir corretamente no estado exposto (\u201Cflipped\u201D) e no evento emitido.\n- Quando a intera\u00E7\u00E3o do Card estiver habilitada:\n  - Deve permitir acionamento por clique e teclado.\n  - Deve manter consist\u00EAncia entre estado visual e estado ARIA.\n- Quando a prefer\u00EAncia de redu\u00E7\u00E3o de movimento estiver ativa:\n  - N\u00E3o deve for\u00E7ar anima\u00E7\u00F5es completas que possam causar desconforto.\n- Se configurado para ignorar intera\u00E7\u00F5es internas:\n  - Acionamentos originados em elementos interativos internos n\u00E3o devem alternar o Card.\n\n# Notes\n- O Card deve ser responsivo, com largura fluida e possibilidade de limitar largura m\u00E1xima por customiza\u00E7\u00E3o.\n- Deve permitir customiza\u00E7\u00E3o visual b\u00E1sica (cores, borda, raio, sombra, dura\u00E7\u00E3o de anima\u00E7\u00E3o e altura da imagem do header) por propriedades de estilo expostas ao consumidor.\n\n";
}
declare module "_102020_/l2/molecules/card.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/molecules/card" {
    import { HTMLTemplateResult } from 'lit';
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    type MaxWidth = 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
    export class CardMolecule extends StateLitElement {
        private msg;
        title: string;
        subtitle: string;
        description: string;
        image: string;
        imageAlt: string;
        icon: string;
        metadata: Record<string, unknown>;
        headerContent?: HTMLTemplateResult | string;
        bodyContent?: HTMLTemplateResult | string;
        footerContent?: HTMLTemplateResult | string;
        backContent?: HTMLTemplateResult | string;
        clickable: boolean;
        hoverable: boolean;
        selectable: boolean;
        selected: boolean;
        expandable: boolean;
        expanded: boolean;
        dismissible: boolean;
        draggable: boolean;
        disabled: boolean;
        loading: boolean;
        error: boolean | string;
        flipped: boolean;
        ignoreInternalInteractions: boolean;
        showImage: boolean;
        maxWidth: MaxWidth;
        bgColor: string;
        textColor: string;
        borderColor: string;
        borderWidth: string;
        radius: string;
        shadow: string;
        flipDurationMs: number;
        headerImageHeight: string;
        private prefersReducedMotion;
        private reduceMotionMql?;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private shouldIgnoreFlipFromTarget;
        private emitFlipEvent;
        private toggleFlip;
        private handleClick;
        private handleKeyDown;
        private getInteractiveRole;
        private getTabIndex;
        private getAriaPressed;
        private getMaxWidthClass;
        private cardVarsStyle;
        private renderMaybeImage;
        private renderHeader;
        private renderBody;
        private renderFooter;
        private renderFrontFace;
        private renderBackFace;
        render(): HTMLTemplateResult;
    }
    global {
        interface HTMLElementTagNameMap {
            'molecules--card-102020': CardMolecule;
        }
    }
}
declare module "_102020_/l2/skills/aura/design.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/design" {
    export const skill = "\n\n---\nname: interface-design\ndescription: Interface design for organism and molecules implemented using Lit Web Components and Tailwind CSS.\n---\n\n# Tailwind Ui\n\n## Identity\n\nYou are a Tailwind CSS expert. You understand utility-first CSS, responsive\ndesign patterns, dark mode implementation, and how to build consistent,\nmaintainable component styles.\n\nYour core principles:\n1. Utility-first - compose styles from utilities, extract components when patterns repeat\n2. Responsive mobile-first - start with mobile, add breakpoint modifiers\n3. Design system consistency - use the theme, extend don't override\n4. Performance - purge unused styles, avoid arbitrary values when possible\n5. Accessibility - proper contrast, focus states, reduced motion\n\n# Implementation Stack\n\nAll interfaces must be implemented using:\n\n- **Lit 3.0 Web Components**\n- **Tailwind CSS**\n- **Semantic tokens mapped in Tailwind config**\n\n# Designing Frontend\n\n## Workflow\n\n1. **Conceptualize**\n   - Identify purpose and user context\n   - Choose a bold aesthetic direction (brutally minimal, maximalist, retro-futuristic, organic, luxury, brutalist, etc.)\n   - Define the one unforgettable element\n   - Note technical constraints (framework, performance, accessibility)\n\n2. **Implement**\n   - Write production-grade code (HTML/CSS/JS.)\n   - Apply aesthetic guidelines below\n\n3. **Verify**\n   - Check visual hierarchy and cohesion\n   - Test interactions and animations\n   - Validate accessibility requirements\n   - Confirm no generic patterns emerged\n\n4. **Iterate**\n   - Refine details based on verification\n   - Enhance distinctiveness where needed\n\n## Aesthetic Guidelines\n\n**Typography**\n- Use distinctive, characterful fonts (avoid Inter, Roboto, Arial, system fonts)\n- Pair expressive display fonts with refined body fonts\n\n**Color & Theme**\n- Build cohesive palettes with CSS variables\n- Use dominant colors with sharp accents, not evenly-distributed schemes\n- Avoid clich\u00E9d combinations (purple gradients on white)\n\n**Motion**\n- Create high-impact moments with orchestrated page loads and staggered reveals\n- Use CSS animations for HTML; Motion library for React\n- Add surprising hover states and scroll-triggered effects\n\n**Spatial Composition**\n- Break from grid conventions: asymmetry, overlap, diagonal flow\n- Use generous negative space OR intentional density\n\n**Backgrounds & Visual Effects**\n- Layer gradient meshes, noise textures, geometric patterns\n- Apply contextual effects: layered transparencies, dramatic shadows, decorative borders\n- Add atmosphere through depth and texture\n\n## Implementation Principles\n\n- **Match complexity to vision**: Maximalist designs require elaborate code; minimalist designs demand precision in spacing and typography\n- **Vary every design**: Different fonts, themes, aesthetics for each project\n- **Never converge**: Avoid repeated choices (Space Grotesk, common layouts)\n- **Context-specific**: Design should feel genuinely crafted for its purpose\n\n## Every Choice Must Be A Choice\n\nFor every decision, you must be able to explain WHY.\n\n- Why this layout and not another?\n- Why this color temperature?\n- Why this typeface?\n- Why this spacing scale?\n- Why this information hierarchy?\n\nIf your answer is \"it's common\" or \"it's clean\" or \"it works\" \u2014 you haven't chosen. You've defaulted. Defaults are invisible. Invisible choices compound into generic output.\n\n**The test:** If you swapped your choices for the most common alternatives and the design didn't feel meaningfully different, you never made real choices.\n";
}
declare module "_102020_/l2/skills/aura/moleculeGeneration.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/moleculeGeneration" {
    export const skill = "\n\n\n# Molecule Generation Skill\n\n> Skill for generating UI Molecule components in the MLS system.\n\n---\n\n## 1. Metadata\n\n| Field       | Value                                                                 |\n|-------------|-----------------------------------------------------------------------|\n| **Name**    | `moleculeGeneration`                                                  |\n| **Version** | `1.0.0`                                                               |\n| **Category**| `ui-generation`                                                       |\n| **Triggers**| `create molecule`, `generate ui component`, `new component`, `build molecule` |\n\n---\n\n## 2. Core Principles\n\nMolecules are **UI-first** components that follow these rules:\n\n| Principle              | Description                                                      |\n|------------------------|------------------------------------------------------------------|\n| **No Business Logic**  | Molecules do NOT contain business logic                          |\n| **No Shadow DOM**      | Molecules do NOT use Shadow Root                                 |\n| **Independence**       | Molecules must function independently                            |\n| **Data Flow**          | Data flows DOWN from Organisms via properties; events flow UP    |\n| **No Slots**           | Do NOT use the `<slot>` system                                   |\n\n---\n\n## 3. Naming Conventions\n\n### Tag Name (Custom Element)\n```\nkebab-case(folder)--kebab-case(component)-(projectId)\n```\n**Example:** `molecules--button-102020`\n\n### Class Name\n```\nPascalCase + Molecule\n```\n**Example:** `ButtonMolecule`\n\n### File Name\n```\ncamelCase.ts\n```\n**Example:** `buttonMolecule.ts`\n\n---\n\n## 4. Import Structure\n\n```typescript\n// Lit and directives \u2014 ALWAYS from 'lit'\nimport {\n    html,\n    HTMLTemplateResult,\n    classMap,\n    ifDefined,\n    repeat,\n    until,\n    choose,\n    guard,\n    keyed,\n    live,\n    ref\n} from 'lit';\n\n// Lit decorators\nimport { customElement, property, state } from 'lit/decorators';\n\n// Data Binding decorators\nimport { propertyDataSource, propertyCompositeDataSource } from '_100554_/l2/collabDecorators';\n\n// Base Class\nimport { StateLitElement } from '/_100554_/l2/stateLitElement';\n```\n\n---\n\n## 5. Property Decorators\n\n### `@propertyDataSource`\nBinds the property to a **single dynamic state**.\n\n```typescript\n@propertyDataSource({ type: String }) \nvalue: string | undefined;\n```\n**Binding:** `{{page1.name}}`\n\n---\n\n### `@propertyCompositeDataSource`\nBinds the property to **multiple composed states**.\n\n```typescript\n@propertyCompositeDataSource({ type: String }) \nlabel: string = '';\n```\n**Binding:** `Hello {{page1.userId}} - {{page1.userName}}`\n\n---\n\n### `@property`\nStandard Lit property for **static configuration or local UI state**.\n\n```typescript\n@property({ type: Boolean }) \nloading = false;\n\n@property({ type: String }) \nvariant: 'primary' | 'secondary' = 'primary';\n```\n\n---\n\n### `@state`\n**Internal** reactive state (not exposed as an attribute).\n\n```typescript\n@state() \nprivate isOpen = false;\n```\n\n---\n\n## 6. Internationalization (i18n) Structure\n\n```typescript\n/// **collab_i18n_start**\nconst message_en = {\n    loading: 'Loading...',\n    // add more messages as needed\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record = {\n    en: message_en,\n    pt: {\n        loading: 'Carregando...',\n    },\n    // add more languages as requested\n};\n/// **collab_i18n_end**\n```\n\n### Usage in Component\n```typescript\nrender() {\n    const lang = this.getMessageKey(messages);\n    this.msg = messages[lang];\n    \n    return html`${this.msg.loading}`;\n}\n```\n\n---\n\n## 7. Complete Structural Template\n\n```typescript\n/// <mls fileReference=\"[file-reference]\" enhancement=\"_102020_/l2/enhancementAura\"/>\n\n// =============================================================================\n// [COMPONENT NAME] MOLECULE \u2014 UI-FIRST COMPONENT\n// =============================================================================\n// [Brief description of the component]\n// This molecule does NOT contain business logic.\n\nimport {\n    html,\n    HTMLTemplateResult,\n    classMap,\n    ifDefined,\n} from 'lit';\n\nimport { customElement, property, state } from 'lit/decorators';\nimport { propertyDataSource, propertyCompositeDataSource } from '_100554_/l2/collabDecorators';\nimport { StateLitElement } from '/_100554_/l2/stateLitElement';\n\n/// **collab_i18n_start**\nconst message_en = {\n    loading: 'Loading...',\n};\ntype MessageType = typeof message_en;\n\nconst messages: Record = {\n    en: message_en,\n};\n/// **collab_i18n_end**\n\n@customElement('molecules--[component-name]-102020')\nexport class [ComponentName]Molecule extends StateLitElement {\n\n    private msg: MessageType = messages.en;\n\n    // =========================================================================\n    // PROPERTIES \u2014 Data from Organisms\n    // =========================================================================\n    \n    @propertyDataSource({ type: String }) \n    value: string | undefined;\n\n    @propertyCompositeDataSource({ type: String }) \n    label: string = '';\n\n    @property({ type: Boolean }) \n    loading = false;\n\n    // =========================================================================\n    // INTERNAL STATE\n    // =========================================================================\n    \n    @state() \n    private isActive = false;\n\n    // =========================================================================\n    // EVENT HANDLERS\n    // =========================================================================\n    \n    private handleClick(e: Event) {\n        this.dispatchEvent(new CustomEvent('component-click', {\n            bubbles: true,\n            composed: true,\n            detail: { /* event data */ }\n        }));\n    }\n\n    // =========================================================================\n    // RENDER\n    // =========================================================================\n    \n    render() {\n        const lang = this.getMessageKey(messages);\n        this.msg = messages[lang];\n\n        if (this.loading) {\n            return html`${this.msg.loading}`;\n        }\n\n        return html`\n            \n                \n            \n        `;\n    }\n}\n```\n\n\n";
}
declare module "_102020_/l2/skills/aura/overview.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/aura/overview" {
    export const skill = "\n## Skill \u2014 Frontend Architecture \u2014 Collab Aura\n\nThis document defines the official frontend architecture, design principles, and responsibilities for building applications using Collab Aura.\nAll components, pages, and integrations MUST follow these rules.\n\n## Core Architecture Principles\n### Atomic Design Structure\nThe frontend follows Atomic Design, with the following hierarchy:\n- Page \u2192 Top-level screen and orchestration layer\n- Organism \u2192 Complex UI sections composed of molecules and plugins\n- Molecule \u2192 Reusable UI components, presentation-only\n- Plugin \u2192 Integration components that communicate with external services\nEach level has a strict responsibility and separation of concerns.\n\n### Technology Stack\n- Use Lit 3 to build Web Components\n- Do NOT use Shadow DOM\n- Use Tailwind CSS for styling\n- Use SPA (Single Page Application) architecture\n- Each page corresponds to a URL entry point\n\n### Backend Communication Model\nFollow the BFF (Backend for Frontend) pattern.\nFrontend MUST communicate with backend routines using the BFF abstraction layer.\nAll backend communication MUST go through the frontend backend gateway (beInvoke or equivalent).\nDirect backend calls outside this abstraction are NOT allowed.\n\n### Data Fetching Strategy\nUse Stale-While-Revalidate (SWR) strategy for optimal perceived performance.\nThis means:\n- First attempt to load data from local IndexedDB (fast response)\n- Mark data consistency as \"stale\"\n- Then fetch fresh data from backend\n- Update state and IndexedDB when backend responds\n- Mark data consistency as \"fresh\"\nThis improves performance and user experience.\n\n## State Management\nGlobal state is used by pages and organisms.\nState naming:\nui.[pageName].[stateName]\nExamples:\nui.productDetail.product  \nui.productDetail.productConsistency  \nui.productDetail.onLoadMore  \nState types:\n- Data state \u2192 holds UI data\n- Event state \u2192 triggers actions (example: onUpdateUser)\nRules:\n- Pages MUST NOT pass data to organisms via properties, prefer states.\n- Molecules MUST NOT access global state.\n\n## Page Definitions\nA Page is a Web Component responsible for orchestrating the entire screen.\nResponsibilities:\n- Entry point of the user interface\n- Each page corresponds to a URL\n- Render the overall layout\n- Render organisms and plugins\n- Own business logic\n- Communicate with backend using BFF\n- Manage state lifecycle\n- Define state contracts for child organisms\n- Implement data fetching using SWR pattern\nPages MUST:\n- Follow business rules\n- Render SPA-compatible HTML\n- Render organisms and sections inside a root <div>\n- Orchestrate tabs and conditional content if needed\n- Update state based on backend responses\nPages MUST NOT:\n- Contain reusable UI logic that belongs in organisms\n- Contain reusable UI components that belong in molecules\nTesting:\nEach page MUST have a corresponding test file:\npageName.test.ts\nTests MUST verify:\n- Business logic\n- State transitions\n- Backend communication behavior\n\n## Organism Definitions\nOrganisms are Web Components responsible for rendering complex UI sections.\nResponsibilities:\n- Render layout sections\n- Combine molecules and plugins\n- Receive data via global states\n- Emit events via state updates\nOrganisms MUST:\n- Follow defined property contracts\n- Be reusable within the project\nOrganisms MUST NOT:\n- Communicate directly with backend\n- Own business logic\n- Fetch data\nTesting:\nEach organism MUST have:\norganismName.test.ts\nTests MUST verify:\n- Layout rendering\n- Property handling\n- State-driven rendering behavior\n\n## Molecule Definitions\nMolecules are reusable UI components.\nResponsibilities:\n- Render UI elements\n- Be highly reusable\n- Be presentation-only\nMolecules MUST:\n- Receive data only via properties\n- Be stateless regarding global application state\nMolecules MUST NOT:\n- Access global state\n- Communicate with backend\n- Contain business logic\n\n## Plugin Definitions\nPlugins are Web Components responsible for integrating with external services.\nExamples:\n- Payment platforms\n- External APIs\n- Third-party integrations\n- Analytics services\nPlugins MAY:\n- Communicate with external services\n- Provide integration functionality\nPlugins MUST NOT:\n- Contain core business logic of the application\n- Own application state\n\n## Folder and File Organization\nAll frontend files MUST follow this structure:\n_[projectId]_/l2/[moduleName]/[componentName].[extension]\nDefinitions:\n- projectId \u2192 numeric project identifier (example: 100111)\n- l2 \u2192 frontend layer\n- moduleName \u2192 module name or folder\n- componentName \u2192 component name using camelCase\n- extension \u2192 file type (ts, test.ts, defs.ts, css, etc.)\nImport rules:\n- Always use absolute project-based imports \nExample:\nimport \"/_100111_/l2/user/userProfileOrganism.js\";\n\nAll generated frontend code MUST strictly follow this architecture.\n";
}
declare module "_102020_/l2/skills/design/glassmorphism.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/glassmorphism" {
    export const skill = "\n\n# Skill: Glassmorphism\n\n## Philosophy\n> \"Depth through transparency. Light caught in layers.\"\n\nComponents float above a dark gradient canvas, simulating frosted glass. The background bleeds through every surface. Hierarchy is built with opacity and blur, not color or shadow.\n\n---\n\n## Canvas\n\nThis skill is **dark only**. Components must always render over a dark gradient canvas.\n\nThe canvas color palette is **free** \u2014 chosen by the implementer. What is required is the structure:\n\n```html\n<!-- Required canvas structure -->\n<div class=\"bg-gradient-to-br from-[your-color-950] via-[your-color-950] to-[your-color-950]\">\n\n  <!-- Ambient orbs: optional but recommended for depth -->\n  <div class=\"absolute w-96 h-96 rounded-full blur-3xl pointer-events-none bg-[--your-color]/20\" />\n  <div class=\"absolute w-80 h-80 rounded-full blur-3xl pointer-events-none bg-[your-color]/20\" />\n\n</div>\n```\n\n## Canvas rules\n- Background must be **dark** (`*-900` to `*-950` range)\n- Gradient must have **at least 2 stops** for depth\n- Ambient orbs use the same hue family as the gradient, at low opacity (`/15` to `/25`)\n- Orbs must be `pointer-events-none` and positioned absolutely\n\n> Components rendered without a dark canvas will lose their visual effect entirely.\n\n---\n\n## Tokens\n\n### Glass Surface (Moderate \u2014 default)\n| Token | Value |\n|---|---|\n| Background | `bg-white/10` |\n| Backdrop blur | `backdrop-blur-md` |\n| Border | `border border-white/20` |\n| Border highlight | `border-t-white/30` (top edge only) |\n| Inner glow | `shadow-inner shadow-white/5` |\n\n> **Intensity scale for reference:**\n> - Subtle: `bg-white/5` + `backdrop-blur-sm` + `border-white/10`\n> - **Moderate: `bg-white/10` + `backdrop-blur-md` + `border-white/20`** \u2190 default\n> - Intense: `bg-white/15` + `backdrop-blur-xl` + `border-white/30`\n\n### Color\n| Token | Value |\n|---|---|\n| Text Primary | `white` |\n| Text Secondary | `white/60` |\n| Text Muted | `white/40` |\n| Accent | inherits from canvas palette |\n| Danger | inherits from implementer |\n| Success | inherits from implementer |\n\n> All semantic colors are defined by the implementer. Use `*-300` or `*-400` lightness range to ensure legibility on dark backgrounds.\n\n### Typography\n| Token | Value |\n|---|---|\n| Font family | `font-sans` |\n| Body size | `text-base` |\n| Label size | `text-sm` |\n| Heading size | `text-xl` |\n| Body weight | `font-normal` |\n| Heading weight | `font-semibold` |\n| Heading tracking | `tracking-wide` |\n| Text rendering | `antialiased` |\n\n### Spacing\n| Token | Value |\n|---|---|\n| Component padding | `p-6` |\n| Element gap | `gap-4` |\n| Section gap | `gap-8` |\n\n### Shape\n| Token | Value |\n|---|---|\n| Border radius | `rounded-2xl` |\n| Border width | `border` (1px) |\n| Outer glow | `shadow-lg shadow-black/30` |\n\n### Interaction\n| State | Value |\n|---|---|\n| Hover (surface) | `hover:bg-white/15` |\n| Hover (border) | `hover:border-white/30` |\n| Focus ring | `focus-visible:ring-1 focus-visible:ring-white/50 focus-visible:ring-offset-0` |\n| Transition | `transition-all duration-200` |\n| Active | `active:bg-white/20` |\n\n> `ring-offset-0` is intentional \u2014 offset creates visual glitching on glass surfaces.\n\n---\n\n## Layering System\n\nGlass components gain depth through stacking. Use opacity to signal hierarchy:\n\n| Layer | bg | blur | border |\n|---|---|---|---|\n| Base (canvas) | gradient | \u2014 | \u2014 |\n| Card / Panel | `white/10` | `backdrop-blur-md` | `white/20` |\n| Elevated (modal, popover) | `white/15` | `backdrop-blur-lg` | `white/25` |\n| Tooltip / Badge | `white/20` | `backdrop-blur-sm` | `white/30` |\n\n---\n\n## Rules\n\n### \u2705 Do\n- Always render over a dark gradient canvas\n- Use `border-t-white/30` on the top edge to simulate light hitting glass\n- Use ambient orbs (`blur-3xl`) behind key components to add depth\n- Keep text `white` or `white/60` \u2014 never dark text on glass\n- Use `rounded-2xl` consistently\n- Prefer `transition-all` for smooth glass state changes\n- Use `pointer-events-none` on all decorative elements\n- Derive accent color from the canvas palette\n\n### \u274C Never\n- Render components on a white or light background\n- Use opaque backgrounds (`bg-zinc-900`, `bg-slate-800`, etc.)\n- Use colored borders \u2014 only `white/*` opacity borders\n- Use `ring-offset` on focus states\n- Use `font-bold` \u2014 weight feels heavy against transparent surfaces\n- Stack more than 3 glass layers\n- Use drop shadows with color \u2014 only `shadow-black/*`\n\n---\n\n## Iconography\n- Style: **outline / stroke**\n- Stroke width: `1.5`\n- Size: `size-5`\n- Color: `text-white/70` default, accent color for emphasis\n\n---\n\n## Tone\nEthereal. Expensive. Cinematic.  \nLight passes through every surface. The canvas is always part of the component.\n\n";
}
declare module "_102020_/l2/skills/design/minimalist.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/design/minimalist" {
    export const skill = "\n# Skill: Minimalist\n\n## Philosophy\n\n> \"The component exists. Nothing more.\"\n\nEverything that doesn't communicate is removed.  \nNo decorative shadows, no gradients, no unnecessary borders.  \nWhite space is not empty \u2014 it is the design itself.\n\n---\n\n## Tokens\n\n### Color\n\n| Token            | Light    | Dark     |\n|------------------|----------|----------|\n| Background       | zinc-50  | zinc-950 |\n| Surface          | white    | zinc-900 |\n| Border           | zinc-200 | zinc-800 |\n| Text Primary     | zinc-900 | zinc-50  |\n| Text Secondary   | zinc-500 | zinc-400 |\n| Accent           | zinc-900 | zinc-50  |\n\n**Note:**  \nAccent is the text itself. No separate accent color.\n\n---\n\n### Typography\n\n| Token             | Value                  |\n|-------------------|------------------------|\n| Font family       | font-sans (system-ui)  |\n| Body size         | text-base              |\n| Label size        | text-sm                |\n| Heading size      | text-lg                |\n| Body weight       | font-normal            |\n| Emphasis weight   | font-medium            |\n| Heading tracking  | tracking-tight         |\n\n**Rule:**  \nNever use `font-bold` or `font-semibold`.\n\n---\n\n### Spacing\n\n| Token             | Value                |\n|-------------------|----------------------|\n| Component padding | p-6 or p-8           |\n| Element gap       | gap-4 or gap-6       |\n| Section gap       | gap-8 or gap-12      |\n\n**Rule:**  \nWhen in doubt, add more space.\n\n---\n\n### Shape\n\n| Token         | Value                                      |\n|---------------|--------------------------------------------|\n| Border radius | rounded-none or rounded-sm                 |\n| Border width  | border (1px)                               |\n| Border color  | border-zinc-200 / dark:border-zinc-800     |\n| Shadow        | none                                       |\n\n---\n\n### Interaction\n\n| State        | Value                                                                 |\n|--------------|-----------------------------------------------------------------------|\n| Hover (bg)   | hover:bg-zinc-100 / dark:hover:bg-zinc-800                           |\n| Hover (text) | hover:text-zinc-600                                                  |\n| Focus ring   | focus-visible:ring-1 focus-visible:ring-zinc-900 focus-visible:ring-offset-2 |\n| Transition   | transition-colors duration-150                                       |\n| Active       | active:bg-zinc-200                                                   |\n\n**Rule:**  \nNo scale, translate, or transform effects.\n\n---\n\n## Rules\n\n### \u2705 Do\n\n- Use generous white space as a design element  \n- Use zinc scale exclusively for neutrals  \n- Separate sections with space, not dividers  \n- Use line-style icons (stroke, not fill)  \n- Keep a single level of visual hierarchy per component  \n- Prefer border over shadows for surface separation  \n\n### \u274C Never\n\n- Decorative shadows (`shadow-*`)  \n- Gradients (`bg-gradient-*`)  \n- Vibrant or saturated colors  \n- Large border radius (`rounded-lg` or above)  \n- `font-bold` or `font-semibold`  \n- Filled or colorful icons  \n- Animations beyond `transition-colors`  \n- More than 2 font sizes in a single component  \n\n---\n\n## Iconography\n\n- **Style:** outline / stroke  \n- **Stroke width:** 1 or 1.5 (never 2+)  \n- **Size:** size-4 or size-5  \n- **Color:** inherits from text (`currentColor`)  \n\n---\n\n## Tone\n\nCold. Precise. Confident through restraint.  \nThe absence of decoration is the statement.\n";
}
declare module "_102020_/l2/skills/molecules/groupCard.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupCard" {
    export const skill = "\n\n# Skill: GroupCard\n\n## Metadata\n\n- **Name:** GroupCard\n- **Category:** Display Molecules\n- **Version:** 1.0.0\n- **Last Updated:** 20/03/2026\n\n---\n\n## Definition\n\n### Essence\n\nDisplay structured information within a visually delimited container.\n\n### When to Use\n\n- Present grouped, related information\n- Display items in a list or grid\n- Showcase content with visual hierarchy\n- Create interactive content blocks\n\n### When NOT to Use\n\n- Simple text display without grouping \u2192 use **Text/Typography**\n- Single action button \u2192 use **Button**\n- Navigation items \u2192 use **Menu/Nav**\n- Tabular data \u2192 use **Table**\n\n---\n\n## Contract\n\n### Anatomy\n\n| Area | Description | Required |\n|------|-------------|:--------:|\n| 'header' | Top area (title, actions) | |\n| 'media' | Image, video, or visual content | |\n| 'body' | Main content area | |\n| 'footer' | Bottom area (actions, metadata) | |\n\nAll areas are flexible slots. A valid Card must have at least one area populated.\n\n### Component Properties\n\n#### Content Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| 'title' | 'string' | '''' | | '@propertyCompositeDataSource' | Card title |\n| 'subtitle' | 'string' | '''' | | '@propertyCompositeDataSource' | Subtitle or short description |\n| 'description' | 'string' | '''' | | '@propertyCompositeDataSource' | Longer descriptive text |\n| 'image' | 'string' | '''' | | '@propertyDataSource' | URL of the image/media |\n| 'icon' | 'string' | '''' | | '@propertyDataSource' | Card icon identifier |\n| 'metadata' | 'object' | '{}' | | '@propertyDataSource' | Additional info (date, author, tags) |\n\n#### Behavior Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| 'clickable' | 'boolean' | 'false' | | '@property' | Entire card is clickable |\n| 'hoverable' | 'boolean' | 'false' | | '@property' | Visual effect on hover |\n| 'selectable' | 'boolean' | 'false' | | '@property' | Can be selected (checkbox/radio) |\n| 'selected' | 'boolean' | 'false' | | '@propertyDataSource' | Card is currently selected |\n| 'expandable' | 'boolean' | 'false' | | '@property' | Can expand to show more content |\n| 'expanded' | 'boolean' | 'false' | | '@propertyDataSource' | Card is currently expanded |\n| 'dismissible' | 'boolean' | 'false' | | '@property' | Can be closed/removed |\n| 'draggable' | 'boolean' | 'false' | | '@property' | Can be dragged |\n\n#### State Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| 'disabled' | 'boolean' | 'false' | | '@property' | Card is disabled |\n| 'loading' | 'boolean' | 'false' | | '@property' | Loading content (skeleton) |\n| 'error' | 'boolean | string' | 'false' | | '@property' | Error state or message |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| '@propertyDataSource' | Binds to a single dynamic state | '{{page1.cardImage}}' |\n| '@propertyCompositeDataSource' | Binds to multiple composed states | '{{page1.userName}} - {{page1.role}}' |\n| '@property' | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| 'click' | '{ }' | Fired when card is clicked (if 'clickable') |\n| 'select' | '{ selected: boolean }' | Fired when card is selected/deselected (if 'selectable') |\n| 'expand' | '{ expanded: boolean }' | Fired when card is expanded/collapsed (if 'expandable') |\n| 'dismiss' | '{ }' | Fired when card is closed (if 'dismissible') |\n| 'action' | '{ action: string }' | Fired when a card action is triggered |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Initial/neutral state | Standard appearance |\n| **hover** | Cursor over the card | Visual feedback (if 'hoverable') |\n| **focus** | Card has focus | Visual focus indicator |\n| **disabled** | Card is disabled | Non-interactive, visually dimmed |\n| **loading** | Loading content | Displays skeleton/placeholder |\n| **selected** | Card is selected | Visual selection indicator |\n| **expanded** | Card is expanded | Shows additional content |\n| **error** | Error state | Visual error feedback |\n| **dragging** | Card is being dragged | Visual drag feedback (if 'draggable') |\n\n---\n\n## Accessibility (Recommended)\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| 'Tab' | Moves focus to/from the card |\n| 'Enter' / 'Space' | Activates card (click, select, or expand) |\n| 'Escape' | Closes expanded card or cancels drag |\n| 'Arrow Keys' | Navigate between cards in a grid/list |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| 'role=\"article\"' | Card container (informational) |\n| 'role=\"button\"' | Card container (if 'clickable') |\n| 'role=\"checkbox\"' | Card container (if 'selectable') |\n| 'aria-selected' | Indicates selected state |\n| 'aria-expanded' | Indicates expanded state |\n| 'aria-disabled' | Indicates disabled state |\n| 'aria-busy' | Indicates loading state |\n| 'aria-grabbed' | Indicates dragging state |\n\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 20/03/2026 | Initial contract definition |\n\n";
}
declare module "_102020_/l2/skills/molecules/groupSelectOne.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/groupSelectOne" {
    export const skill = "\n\n# Skill: groupSelectOne\n\n## Metadata\n\n- **Name:** groupSelectOne\n- **Version:** 1.0.0\n- **Last Updated:** 20/03/2026\n\n---\n\n## Definition\n\n### Essence\n\nAllow the user to choose **exactly one option** from several available.\n\n### When to Use\n\n- User must make an exclusive choice\n- Only one answer is valid at a time\n- Options are mutually exclusive\n\n### When NOT to Use\n\n- User can select multiple options \u2192 use **SelectMultiple**\n- There is only one option (on/off) \u2192 use **Toggle/Switch**\n- Input is free/textual \u2192 use **Input**\n\n---\n\n## Contract\n\n### Option Structure\n\n| Property | Type | Required | Description |\n|----------|------|:--------:|-------------|\n| 'value' | 'string | number' | \u2713 | Unique identifier for the option |\n| 'label' | 'string' | \u2713 | Text displayed to the user |\n| 'disabled' | 'boolean' | | If 'true', option cannot be selected |\n\n### Component Properties\n\n| Property | Type | Default | Required | Decorator | Description |\n|----------|------|---------|:--------:|-----------|-------------|\n| 'value' | 'string | number | null' | 'null' | | '@propertyDataSource' | Value of the selected option |\n| 'options' | 'Option[]' | '[]' | \u2713 | '@propertyDataSource' | List of available options |\n| 'placeholder' | 'string' | '''' | | '@propertyCompositeDataSource' | Text displayed when no option is selected |\n| 'disabled' | 'boolean' | 'false' | | '@property' | Disables the entire component |\n| 'readonly' | 'boolean' | 'false' | | '@property' | Displays value but prevents changes |\n| 'loading' | 'boolean' | 'false' | | '@property' | Indicates asynchronous loading |\n| 'error' | 'boolean | string' | 'false' | | '@property' | Error state or message |\n| 'required' | 'boolean' | 'false' | | '@property' | Indicates mandatory selection |\n\n#### Decorator Reference\n\n| Decorator | Purpose | Binding Example |\n|-----------|---------|-----------------|\n| '@propertyDataSource' | Binds to a single dynamic state | '{{page1.selectedId}}' |\n| '@propertyCompositeDataSource' | Binds to multiple composed states | 'Select a {{page1.itemType}}' |\n| '@property' | Static configuration or local UI state | Direct value assignment |\n\n### Events\n\n| Event | Payload | Description |\n|-------|---------|-------------|\n| 'change' | '{ value: string | number, option: Option }' | Fired when selection changes |\n\n---\n\n## Visual States\n\n### Component States\n\n| State | Description | Expected Behavior |\n|-------|-------------|-------------------|\n| **default** | Initial/neutral state | Interactive, awaiting action |\n| **hover** | Cursor over the component | Visual feedback of interactivity |\n| **focus** | Component has focus | Visual focus indicator (outline) |\n| **disabled** | Component is disabled | Non-interactive, visually dimmed |\n| **readonly** | Read-only mode | Displays value, prevents changes |\n| **loading** | Loading options | Displays loading indicator |\n| **error** | Error state | Visual error feedback (color, icon) |\n\n### Option States\n\n| State | Description |\n|-------|-------------|\n| **default** | Option available for selection |\n| **selected** | Currently selected option |\n| **disabled** | Option cannot be selected |\n| **hover** | Cursor over the option |\n| **focus** | Option has focus (keyboard navigation) |\n\n---\n\n## Accessibility (Recommended)\n\n### Keyboard Navigation\n\n| Key | Action |\n|-----|--------|\n| 'Tab' | Moves focus to/from the component |\n| 'Arrow Up/Down' | Navigates between options |\n| 'Arrow Left/Right' | Navigates between options (horizontal variants) |\n| 'Enter' / 'Space' | Selects focused option |\n| 'Escape' | Closes dropdown (if applicable) |\n| 'Home' | Moves to first option |\n| 'End' | Moves to last option |\n\n### ARIA\n\n| Attribute | Application |\n|-----------|-------------|\n| 'role=\"listbox\"' | Options container |\n| 'role=\"option\"' | Each individual option |\n| 'aria-selected' | Indicates selected option |\n| 'aria-disabled' | Indicates disabled option/component |\n| 'aria-required' | Indicates required field |\n| 'aria-invalid' | Indicates error state |\n| 'aria-expanded' | Indicates if dropdown is open |\n\n---\n\n## Validation Rules\n\n| Rule | Condition | Suggested Message |\n|------|-----------|-------------------|\n| required | 'required === true && value === null' | \"Please select an option\" |\n| invalidOption | 'value' does not exist in 'options' | \"Invalid option\" |\n\n---\n\n\n## Changelog\n\n| Version | Date | Description |\n|---------|------|-------------|\n| 1.0.0 | 20/03/2026 | Initial contract definition |\n\n";
}
declare module "_102020_/l2/skills/molecules/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102020_/l2/skills/molecules/index" {
    export const skills: {
        name: string;
        description: string;
        skillReference: string;
    }[];
}
