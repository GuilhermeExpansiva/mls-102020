/// <mls fileReference="_102020_/l2/widgetPlaygroundStateText.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let WcInputText100554 = class WcInputText100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-playground-state-text-102020{display:block;margin-bottom:.5rem}`);
        this.autocapitalize = "off";
        this.maxlength = undefined;
        this.minlength = undefined;
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.autocorrect = undefined;
        this.autoCapitalize = undefined;
        this.error = '';
    }
    render() {
        return html `
    <div class="flex flex-col gap-1">
      
      ${this.label ? html `
        <label class="text-sm font-medium text-gray-700">
          ${this.label}
        </label>
      ` : null}

      <input
        class="
          w-full px-3 py-2 rounded-lg border
          text-sm text-gray-900
          bg-white
          border-gray-300
          transition
          outline-none
          
          focus:ring-2 focus:ring-blue-500 focus:border-blue-500
          
          disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed
          
          ${this.error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''}
        "
        type="text"
        name=${ifDefined(this.name)}
        ?disabled=${this.disabled}
        ?readonly=${this.readonly}
        ?required=${this.required}
        maxlength=${ifDefined(this.maxlength)}    
        minlength=${ifDefined(this.minlength)}
        autocomplete=${ifDefined(this.autocomplete)}
        placeholder=${ifDefined(this.placeholder)}
        .value=${this.value || ''}
        ?autofocus=${this.autofocus}
        pattern=${ifDefined(this.pattern)}
        @input=${this.handleChange}
      />

      ${this.hint ? html `
        <small class="text-xs text-gray-500">
          ${this.hint}
        </small>
      ` : null}

      ${this.error ? html `
        <div class="text-xs text-red-500 font-medium">
          ${this.error}
        </div>
      ` : null}

    </div>
  `;
    }
    handleChange(event) {
        const input = event.target;
        this.value = input.value;
    }
};
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "value", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "maxlength", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "minlength", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "autofocus", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autocorrect", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autoCapitalize", void 0);
__decorate([
    query('.input_control')
], WcInputText100554.prototype, "input", void 0);
WcInputText100554 = __decorate([
    customElement('widget-playground-state-text-102020')
], WcInputText100554);
export { WcInputText100554 };
