/// <mls fileReference="_102020_/l2/pizzaria/web/desktop/shared/login.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { state } from 'lit/decorators.js';
/// **collab_i18n_start**
const message_en = {
    email: 'Email',
    password: 'Password',
    showPassword: 'Show Password',
    rememberMe: 'Remember me',
    login: 'Login',
    forgotPassword: 'Forgot Password?',
    register: 'Register',
    loading: 'Loading...',
    error: 'An error occurred.',
    retry: 'Retry'
};
const message_pt = {
    email: 'E-mail',
    password: 'Senha',
    showPassword: 'Mostrar senha',
    rememberMe: 'Lembrar-me',
    login: 'Entrar',
    forgotPassword: 'Esqueceu a senha?',
    register: 'Cadastrar',
    loading: 'Carregando...',
    error: 'Ocorreu um erro.',
    retry: 'Tentar novamente'
};
export const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
export class LoginShared extends CollabLitElement {
    constructor() {
        super(...arguments);
        // Control states
        this.action = null;
        this.loading = false;
        this.error = null;
        // Data states
        this.user_email = '';
        this.user_password = '';
        // Temp states
        this.showPassword = false;
        this.rememberMe = false;
        this.errorMessage = '';
        // Computed states
        this.isSubmitEnabled = false;
        this.msg = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        // No navigation with dispatchOnMount, so no interactionRuntime needed
    }
    updated(changed) {
        if (changed.has('action')) {
        }
    }
    // ────────────── EmitsAction handlers ─────────────────────
    async _submitLogin() {
        this.action = null;
        this.loading = true;
        this.error = null;
    }
    // ────────────── TempStateAction handlers ─────────────────
    _toggleShowPassword() {
        this.action = null;
        this.showPassword = !this.showPassword;
    }
    _toggleRememberMe() {
        this.action = null;
        this.rememberMe = !this.rememberMe;
    }
    _clearErrorMessage() {
        this.action = null;
        this.errorMessage = '';
    }
    // ────────────── NavigationFieldsAction handlers ──────────
    navigateToForgotPassword() {
        this.action = null;
        // Implement navigation logic here (e.g., update router state)
    }
    navigateToRegister() {
        this.action = null;
        // Implement navigation logic here (e.g., update router state)
    }
    // ────────────── EmitsAction public surface ───────────────
    emitSubmitLogin() {
    }
    // ────────────── Computed field methods ───────────────────
    _computeIsSubmitEnabled() {
        // Email must be valid format, password at least 8 chars
        this.isSubmitEnabled =
            this.user_email.includes('@') &&
                this.user_email.includes('.') &&
                this.user_password.length >= 8;
    }
}
__decorate([
    state()
], LoginShared.prototype, "action", void 0);
__decorate([
    state()
], LoginShared.prototype, "loading", void 0);
__decorate([
    state()
], LoginShared.prototype, "error", void 0);
__decorate([
    state()
], LoginShared.prototype, "user_email", void 0);
__decorate([
    state()
], LoginShared.prototype, "user_password", void 0);
__decorate([
    state()
], LoginShared.prototype, "showPassword", void 0);
__decorate([
    state()
], LoginShared.prototype, "rememberMe", void 0);
__decorate([
    state()
], LoginShared.prototype, "errorMessage", void 0);
__decorate([
    state()
], LoginShared.prototype, "isSubmitEnabled", void 0);
