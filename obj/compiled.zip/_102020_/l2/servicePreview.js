/// <mls fileReference="_102020_/l2/servicePreview.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { globalState, setState, initState, getState } from '/_102027_/l2/collabState.js';
import { getPath } from '/_102027_/l2/utils.js';
import { getConfigProject } from '/_100554_/l2/libProjectConfig.js';
import { getLastOpenedFiles, } from '/_102027_/l2/libCommom.js';
import { getDependenciesByHtml } from '/_102020_/l2/buildFile.js';
import '/_102025_/l2/collabMessagesPrompt.js';
import '/_100554_/l2/collabSpliterVerticalVarFixed.js';
import '/_100554_/l2/collabSpliterHorizontalVarFixed.js';
import { PreviewModeAura } from '/_102020_/l2/previewModeAura.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando preview...',
    promptPlaceholder: 'Digite aqui @@ para agentes',
    dark: ' escuro',
    light: 'claro',
    pause: 'Preview pausado',
    run: 'Preview executando',
};
const message_en = {
    loading: 'Loading preview...',
    promptPlaceholder: 'Type here @@ for agents',
    pause: 'Preview paused',
    run: 'Preview running',
    dark: 'dark',
    light: 'light',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreview = class ServicePreview extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-preview-102020 #preview-container{position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;background:var(--bg-secondary-color)}service-preview-102020 #preview-container::before{content:'';position:absolute;inset:0;background-size:20px 20px;opacity:.4;pointer-events:none;z-index:0}service-preview-102020 .preview-wrapper{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;transition:all .4s cubic-bezier(.4, 0, .2, 1)}service-preview-102020 .preview-desktop{width:100%;height:100%}service-preview-102020 .preview-desktop .preview-iframe{width:100%;height:100%;border:none;background:var(--bg-primary-color);border-radius:0;display:block}service-preview-102020 .preview-mobile{width:390px;max-width:calc(100% - 48px);height:844px;max-height:calc(100% - 48px);border-radius:40px;border:6px solid var(--text-primary-color);background:var(--text-primary-color);box-shadow:0 8px 32px rgba(0,0,0,0.15),inset 0 0 0 2px var(--bg-secondary-color-darker);overflow:hidden;position:relative}service-preview-102020 .preview-mobile::before{content:'';position:absolute;top:8px;left:50%;transform:translateX(-50%);width:120px;height:28px;background:var(--text-primary-color);border-radius:20px;z-index:10}service-preview-102020 .preview-mobile::after{content:'';position:absolute;bottom:8px;left:50%;transform:translateX(-50%);width:130px;height:5px;background:var(--bg-secondary-color-darker);border-radius:10px;z-index:10}service-preview-102020 .preview-mobile .preview-iframe{width:100%;height:100%;border:none;background:#fff;border-radius:34px;display:block}service-preview-102020 #preview-details{background:var(--bg-primary-color);border-left:1px solid var(--grey-color);overflow-y:auto}`);
        this.msg = messages['en'];
        this.languages = {};
        this.modePreview = 'Desktop';
        this.watch = true;
        this.light = true;
        this.msize = '';
        this.lang = 'en';
        this.actualModels = { defs: undefined, html: undefined, style: undefined, test: undefined, ts: undefined };
        this.actualTheme = 'Default';
        this.project = 0;
        this.shortName = '';
        this.folder = '';
        this.details = {
            icon: '&#xf15b',
            state: 'foreground',
            position: 'right',
            tooltip: 'Preview Aura',
            visible: true,
            widget: '_102020_servicePreview',
            level: [5]
        };
        this.menu = {
            title: 'Example',
            main: {},
            tools: {
                darkLight: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: this.msg.light, icon: 'f185' },
                        { text: this.msg.dark, icon: 'f186' },
                    ]
                },
                languages: {
                    type: 'dropdown',
                    selected: 0,
                    options: []
                },
                watchPreview: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: this.msg.run, icon: 'f04c' },
                        { text: this.msg.pause, icon: 'f04b' },
                    ]
                },
            },
            tabs: {
                group: 'Mode',
                type: 'full',
                selected: 0,
                options: [
                    { text: 'Desktop', icon: 'f390' },
                    { text: 'Mobile', icon: 'f3cf' },
                ]
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTools: this.onClickTools.bind(this),
        };
        window.preview = {
            editor: undefined,
            iframe: undefined,
        };
        initState('preview', { pausePreview: false, service: this });
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        if (index === PreviewType.Desktop) {
            this.modePreview = 'Desktop';
        }
        if (index === PreviewType.Mobile) {
            this.modePreview = 'Mobile';
        }
        this.modePreview = PreviewType[index];
        this.updatePreviewMode();
    }
    onClickTools(op) {
        if (op === 'watchPreview')
            this.toogleWatch();
        else if (op === 'languages')
            this.changeLanguage();
        else if (op === 'darkLight')
            this.toggleDarkLight();
    }
    async onServiceClick(visible, reinit, el) {
        if (visible) {
            await this.setActualFileInfos();
            this.createPreview();
        }
    }
    setEvents() {
        mls.events.addEventListener([2, 3, 4, 7], ['FileAction'], this.onFileAction.bind(this));
        mls.events.addEventListener([2, 3], ['styleChanged'], this.onStyleChanged.bind(this));
    }
    // Implementations
    toogleWatch() {
        this.watch = this.menu.tools.watchPreview.selected === 0;
        if (this.watch) {
            this.createPreview();
        }
    }
    toggleDarkLight() {
        this.light = !this.light;
        if (!mls.actual[2].left || !this.watch)
            return this.light;
        const htmlEl = this.getIframePreviewHTML();
        if (htmlEl) {
            if (this.light) {
                // Light mode: remove both Tailwind class and custom data-theme
                htmlEl.removeAttribute('data-theme');
                htmlEl.classList.remove('dark');
            }
            else {
                // Dark mode: add Tailwind class 'dark' + data-theme for custom tokens/less
                htmlEl.setAttribute('data-theme', 'dark');
                htmlEl.classList.add('dark');
            }
        }
        this.onStyleChanged();
        return this.light;
    }
    changeLanguage() {
        if (this.menu.tools.languages.selected === undefined)
            return;
        const opMenu = this.menu.tools.languages.options[this.menu.tools.languages.selected].text;
        const htmlEl = this.getIframePreviewHTML();
        if (htmlEl)
            htmlEl.lang = this.languages[opMenu].acronym;
        this.lang = this.languages[opMenu].acronym;
        const variation = Object.keys(this.languages).indexOf(opMenu);
        globalState.globalVariation = !isNaN(variation) ? variation : 0;
        if (window.top)
            window.top.window.globalVariation = !isNaN(variation) ? variation : 0;
        this.createPreview();
        return true;
    }
    getIframePreviewHTML() {
        if (!window.preview.iframe)
            throw new Error('Preview not created yet');
        const htmlEl = window.preview.iframe
            ?.contentDocument
            ?.querySelector('html');
        return htmlEl;
    }
    onStyleChanged() {
        // TODO: change style
    }
    onFileAction(ev) {
        if (![2].includes(ev.level) || (ev.type !== 'FileAction') || !ev.desc)
            return;
        const fileAction = JSON.parse(ev.desc);
        const eventsValid = ['open', 'openBackground', 'statusOrErrorChanged', 'changed', 'new', 'modeCreated', 'editorChanged', 'openLink'];
        try {
            if (fileAction.position === this.position || !eventsValid.includes(fileAction.action))
                return;
            if (fileAction.action === 'open' || fileAction.action === 'openBackground') {
                setState('preview.pausePreview', false);
                if (!this.watch && this.menu.selectTool)
                    this.menu.selectTool('watchPreview');
            }
            if (fileAction.action === 'open') {
                this.createPreview();
                return;
            }
            if (this.menu && this.menu.closeMenu)
                this.menu.closeMenu();
            const rp = getState('preview.pausePreview');
            if (this.watch && !rp) {
                this.createPreview();
            }
        }
        catch (e) {
            console.info(e);
        }
    }
    async setActualFileInfos() {
        this.setLastOpenedFile();
        if (!mls.actual[2].left)
            return;
        const { project, shortName, folder } = mls.actual[2].left;
        this.project = project;
        this.shortName = shortName;
        this.folder = folder;
        await this.setActualFiles(project, shortName, folder);
        await this.setActualModels();
    }
    setLastOpenedFile() {
        if (!mls.actual[2].left) {
            const lastFileOpened = getLastOpenedFiles(mls.actualProject || 0);
            if (!lastFileOpened || !lastFileOpened['2']) {
                this.clearPreview();
                return;
            }
            const lastFileLeft = lastFileOpened['2'].left;
            if (!lastFileLeft) {
                this.clearPreview();
                return;
            }
            mls.actual[2].setFullName(lastFileLeft);
            const infoLast = getPath(lastFileLeft);
            if (!infoLast)
                throw new Error('[servicePreview] Not found path:' + lastFileLeft);
            const key = mls.stor.getKeyToFiles(infoLast.project, 2, infoLast.shortName, infoLast.folder, '.ts');
            const file = mls.stor.files[key];
            if (!file) {
                this.clearPreview();
                return;
            }
        }
    }
    async setActualFiles(project, shortName, folder) {
        const files = await mls.stor.getFiles({
            folder,
            project,
            shortName,
            loadContent: true,
            level: 2
        });
        this.actualFiles = { ...files };
    }
    async setActualModels() {
        if (!this.actualFiles)
            return;
        if (!this.actualModels?.ts && this.actualFiles.ts) {
            this.actualModels.ts = await this.actualFiles.ts.getOrCreateModel();
        }
        if (!this.actualModels?.html && this.actualFiles.html) {
            this.actualModels.html = await this.actualFiles.html.getOrCreateModel();
        }
        if (!this.actualModels?.style && this.actualFiles.less) {
            this.actualModels.style = await this.actualFiles.less.getOrCreateModel();
        }
    }
    createPreview() {
        const container = this.querySelector('#preview-container');
        if (!container)
            return;
        container.innerHTML = '';
        const wrapper = document.createElement('div');
        wrapper.classList.add('preview-wrapper');
        wrapper.classList.add(this.modePreview === 'Mobile' ? 'preview-mobile' : 'preview-desktop');
        const iframe = document.createElement('iframe');
        iframe.classList.add('preview-iframe');
        iframe.src = '/_102020_servicePreview';
        // iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
        wrapper.appendChild(iframe);
        container.appendChild(wrapper);
        window.preview.iframe = iframe;
        iframe.addEventListener('load', () => {
            this.writePreviewContent(iframe);
            // Apply current dark/light state and language to the new iframe
            const htmlEl = iframe.contentDocument?.querySelector('html');
            if (htmlEl) {
                htmlEl.lang = this.lang;
                if (!this.light) {
                    htmlEl.setAttribute('data-theme', 'dark');
                    htmlEl.classList.add('dark');
                }
            }
        });
        // Trigger load for about:blank
        this.writePreviewContentBlank(iframe);
        this.configureTools(true);
    }
    writePreviewContentBlank(iframe) {
        try {
            const doc = iframe.contentDocument || iframe.contentWindow?.document;
            if (!doc)
                return;
            doc.open();
            doc.write(`<div>${this.msg.loading}</div>`);
            doc.close();
        }
        catch (e) {
            console.error('Error writing preview content:', e);
        }
    }
    async writePreviewContent(iframe) {
        await this.setActualFileInfos();
        if (!this.actualFiles || !this.actualFiles.html)
            throw new Error('No find html file');
        if (!this.actualFiles || !this.actualFiles.htmlContent)
            throw new Error('No find html file content');
        try {
            const doc = iframe.contentDocument || iframe.contentWindow?.document;
            if (!doc)
                return;
            const domVirtual = document.createElement('div');
            domVirtual.innerHTML = this.actualFiles.htmlContent;
            doc.body.innerHTML = domVirtual.innerHTML;
            let ret = await getDependenciesByHtml(this.actualFiles.html, this.actualFiles.htmlContent, this.actualTheme, true);
            console.info(ret);
            await this.modeSinglePage(ret, iframe);
        }
        catch (e) {
            console.error('Error writing preview content:', e);
        }
    }
    async modeSinglePage(json, iframe) {
        if (!this.actualFiles || !this.actualFiles.html)
            return;
        const c = new PreviewModeAura(json, iframe, '2', false, this.actualFiles.html, this.actualModels);
        await c.init();
    }
    updatePreviewMode() {
        if (!this.elPreview)
            return;
        const wrapper = this.querySelector('.preview-wrapper');
        if (!wrapper) {
            this.createPreview();
            return;
        }
        wrapper.classList.remove('preview-desktop', 'preview-mobile');
        wrapper.classList.add(this.modePreview === 'Mobile' ? 'preview-mobile' : 'preview-desktop');
    }
    clearPreview() {
        const container = this.querySelector('#preview-container');
        if (!container)
            return;
        container.innerHTML = '';
        window.preview.iframe = undefined;
        this.configureTools(false);
    }
    // Languages
    async setLanguages() {
        const project = mls.actualProject;
        if (!project) {
            this.languages = {
                'English': { acronym: 'en', name: 'English' }
            };
        }
        else {
            const config = await getConfigProject(project);
            if (!config || !config.languages || config.languages.length === 0) {
                this.languages = {
                    'English': { acronym: 'en', name: 'English' }
                };
            }
            else {
                config.languages.forEach((entry, index) => {
                    this.languages[`${entry.name}`] = {
                        acronym: entry.language,
                        name: entry.name,
                    };
                });
            }
        }
        const languagesOptions = Object.keys(this.languages).map((lg) => {
            const obj = this.languages[lg];
            const newOpt = {
                text: obj.name,
                class: `collab-flags ${obj.acronym}`
            };
            return newOpt;
        });
        if (this.menu.tools.languages)
            this.menu.tools.languages.options = languagesOptions;
        if (this.menu.refresh)
            this.menu.refresh();
    }
    configureTools(enabled) {
        const tools = this.nav3Service?.querySelector('collab-nav-3-menu .tools');
        if (!tools)
            return;
        tools.style.opacity = enabled ? '1' : '.2';
        tools.style.pointerEvents = enabled ? 'all' : 'none';
    }
    // Life cycle
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.setLanguages();
        this.configureTools(false);
    }
    connectedCallback() {
        super.connectedCallback();
        this.setEvents();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.clearPreview();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        const hasMsize = changedProperties.has('msize');
        if (changedProperties.has('modePreview')) {
            this.updatePreviewMode();
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<collab-spliter-vertical-var-fixed-100554 msize=${this.msize} withresize="false" fixedheight="100" complementcolor="var(--bg-primary-color)">

                <collab-spliter-horizontal-var-fixed-100554
                    slot="top"
                    complementcolor="var(--bg-primary-color);"
                    fixedwidth="30%"
                    fixedvisible= "closed" 
                >
                    <div slot="left" style="height:100%;" id="preview-container"></div>
                    <div slot="right" style="height:100%;" id="preview-details"></div>
                </collab-spliter-horizontal-var-fixed-100554>
                <div slot="bottom">
                    <collab-messages-prompt-102025
                        acceptAutoCompleteAgents="true"
                        scope="l${this.level}_preview"  
                        placeholder="${this.msg.promptPlaceholder}"
                        .onSend=${this.handleSend.bind(this)}
                    ></collab-messages-prompt-102025>
                </div>
            </collab-spliter-vertical-var-fixed-100554>`;
    }
    async handleSend(value, opt) {
        console.info('In development');
    }
};
__decorate([
    query('iframe')
], ServicePreview.prototype, "elPreview", void 0);
__decorate([
    property()
], ServicePreview.prototype, "modePreview", void 0);
__decorate([
    property({ type: Boolean })
], ServicePreview.prototype, "watch", void 0);
__decorate([
    property({ type: Boolean })
], ServicePreview.prototype, "light", void 0);
__decorate([
    property()
], ServicePreview.prototype, "msize", void 0);
__decorate([
    property()
], ServicePreview.prototype, "lang", void 0);
__decorate([
    state()
], ServicePreview.prototype, "actualFiles", void 0);
__decorate([
    state()
], ServicePreview.prototype, "actualModels", void 0);
__decorate([
    state()
], ServicePreview.prototype, "actualTheme", void 0);
__decorate([
    state()
], ServicePreview.prototype, "project", void 0);
__decorate([
    state()
], ServicePreview.prototype, "shortName", void 0);
__decorate([
    state()
], ServicePreview.prototype, "folder", void 0);
ServicePreview = __decorate([
    customElement('service-preview-102020')
], ServicePreview);
export { ServicePreview };
var PreviewType;
(function (PreviewType) {
    PreviewType[PreviewType["Desktop"] = 0] = "Desktop";
    PreviewType[PreviewType["Mobile"] = 1] = "Mobile";
})(PreviewType || (PreviewType = {}));
