/// <mls fileReference="_102020_/l2/auraOrganismBase.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
