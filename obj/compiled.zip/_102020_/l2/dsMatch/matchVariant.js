/// <mls fileReference="_102020_/l2/dsMatch/matchVariant.ts" enhancement="_blank" />
/**
 * @returns the match, or `null` only when the group has no molecules at all.
 */
export function matchVariant(group, dsRules, catalog) {
    // `filter` preserves catalog order → basis of the tie-break.
    const candidates = catalog.filter(m => m.group === group);
    if (candidates.length === 0)
        return null;
    let best = null;
    for (const entry of candidates) {
        const declared = Object.entries(entry.layoutConfig);
        // AND: every declared axis must match the DS.
        let ok = true;
        for (const [axis, value] of declared) {
            if (dsRules[axis] !== value) {
                ok = false;
                break;
            }
        }
        if (!ok)
            continue;
        const specificity = declared.length;
        // Strict `>` keeps the FIRST on a tie (catalog order).
        if (!best || specificity > best.specificity) {
            best = { entry, specificity };
        }
    }
    if (best)
        return { entry: best.entry, matched: true, specificity: best.specificity };
    // Deterministic fallback: no molecule matched → first of the group in catalog order.
    return { entry: candidates[0], matched: false, specificity: 0 };
}
