/// <mls fileReference="_102020_/l2/widgetPlaygroundState.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
