/// <mls fileReference="_102020_/l2/auraState.ts" enhancement="_blank" />
import { getState, setState, initState } from '/_102029_/l2/collabState.js';
const STATE_KEY = 'aura';
function getActualProject() {
    return mls.actualProject || null;
}
function getActualModule() {
    return loadAuraProject(getActualProject())?.actualModule ?? null;
}
function getActualLanguage() {
    return loadAuraProject(getActualProject())?.actualLanguage ?? null;
}
function getActualDevice() {
    return loadAuraProject(getActualProject())?.actualDevice ?? null;
}
function getActualLayout() {
    return loadAuraProject(getActualProject())?.actualLayout ?? null;
}
function getActualDesignSystem() {
    return loadAuraProject(getActualProject())?.actualDesignSystem ?? null;
}
function getActualPage() {
    return loadAuraProject(getActualProject())?.actualPage ?? null;
}
export function AuraInitState() {
    if (getAuraState())
        return;
    initState(STATE_KEY, {
        actualProject: getActualProject(),
        actualModule: getActualModule(),
        actualLanguage: getActualLanguage(),
        actualDevice: getActualDevice(),
        actualLayout: getActualLayout(),
        actualDesignSystem: getActualDesignSystem(),
        actualPage: getActualPage(),
    });
}
export function getAuraState() {
    return getState(STATE_KEY);
}
export function setAuraState(key, value) {
    setState(`${STATE_KEY}.${key}`, value);
}
// ─── localStorage ─────────────────────────────────────────────────────
const LS_KEY = 'AuraProjects';
function readStore() {
    try {
        return JSON.parse(localStorage.getItem(LS_KEY) ?? '{}');
    }
    catch {
        return {};
    }
}
function writeStore(store) {
    localStorage.setItem(LS_KEY, JSON.stringify(store));
}
export function saveAuraProject() {
    const state = getAuraState();
    const project = state.actualProject;
    if (!project)
        return;
    const store = readStore();
    store[project] = {
        actualModule: state.actualModule,
        actualLanguage: state.actualLanguage,
        actualDevice: state.actualDevice,
        actualLayout: state.actualLayout,
        actualDesignSystem: state.actualDesignSystem,
        actualPage: state.actualPage,
    };
    writeStore(store);
}
export function deleteAuraProject(project) {
    const store = readStore();
    if (!store[project])
        return;
    delete store[project];
    writeStore(store);
}
export function loadAuraProject(project) {
    if (!project)
        return null;
    const store = readStore();
    return store[project] ?? null;
}
export function restoreAuraProject(project) {
    const entry = loadAuraProject(project);
    if (!entry)
        return;
    setAuraState('actualProject', project);
    Object.keys(entry).forEach(key => {
        setAuraState(key, entry[key]);
    });
}
