/// <mls shortName="aura" project="102020" enhancement="_blank" />
const pendingRequests = {};
export class Aura {
    constructor() {
        this.mode = 'production';
        this.running = false;
    }
    open(name = 'collab') {
        if (this.running)
            return this;
        this.channel = new BroadcastChannel(name);
        return this;
    }
    listen(mode = 'production') {
        if (this.running)
            return this;
        if (!this.channel)
            throw new Error('Channel not opened');
        this.mode = mode;
        this.channel.onmessage = (event) => {
            if (event.data.type !== "fetch-response")
                return;
            const resolve = pendingRequests[event.data.id];
            if (!resolve)
                return;
            delete pendingRequests[event.data.id];
            resolve(new Response(event.data.body, {
                status: event.data.status,
                headers: event.data.headers
            }));
        };
        this.running = true;
        return this;
    }
    async send(url, options) {
        return new Promise((resolve, reject) => {
            if (!this.channel) {
                reject(new Error('Channel not opened'));
                return;
            }
            if (this.mode === 'production') {
                reject(new Error('Not prepared yet'));
                return;
            }
            const id = crypto.randomUUID();
            pendingRequests[id] = resolve;
            const server = url.split('/').shift();
            const opt = {
                type: "fetch-request",
                id: id,
                url,
                server,
                options: JSON.stringify(options)
            };
            this.channel.postMessage(opt);
        });
    }
    close() {
        this.channel?.close();
        this.channel = undefined;
        return this;
    }
}
