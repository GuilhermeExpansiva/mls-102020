/// <mls fileReference="_102020_/l2/plugins/selectOrganization.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import '/_102020_/l2/plugins/markdownViewer.js';
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    title: 'Organizations',
    desc: 'An organization groups multiple projects under the same umbrella. Select one to browse the projects available to your team.',
    allTitle: 'All Organizations',
    allDesc: 'Overview of all organizations available in the system.',
    customTitle: 'New Organization',
    customDesc: 'Create a new organization to group your projects.',
    projects: 'projects',
    noOrgs: 'No organizations found.',
    noResults: 'No organizations match your search.',
    createNew: 'New Organization',
    searchPlaceholder: 'Search organizations…',
    inDevelopment: 'In development',
};
const messages = {
    en: message_en,
    pt: {
        title: 'Organizações',
        desc: 'Uma organização agrupa vários projetos sob o mesmo guarda-chuva. Selecione uma para navegar pelos projetos disponíveis para o seu time.',
        allTitle: 'Todas as Organizações',
        allDesc: 'Visão geral de todas as organizações disponíveis no sistema.',
        customTitle: 'Nova Organização',
        customDesc: 'Crie uma nova organização para agrupar seus projetos.',
        projects: 'projetos',
        noOrgs: 'Nenhuma organização encontrada.',
        noResults: 'Nenhuma organização corresponde à sua busca.',
        createNew: 'Nova Organização',
        searchPlaceholder: 'Buscar organizações…',
        inDevelopment: 'Em desenvolvimento',
    },
    es: {
        title: 'Organizaciones',
        desc: 'Una organización agrupa múltiples proyectos bajo el mismo paraguas. Seleccione una para explorar los proyectos disponibles para su equipo.',
        allTitle: 'Todas las Organizaciones',
        allDesc: 'Visión general de todas las organizaciones disponibles en el sistema.',
        customTitle: 'Nueva Organización',
        customDesc: 'Cree una nueva organización para agrupar sus proyectos.',
        projects: 'proyectos',
        noOrgs: 'No se encontraron organizaciones.',
        noResults: 'Ninguna organización coincide con su búsqueda.',
        createNew: 'Nueva Organización',
        searchPlaceholder: 'Buscar organizaciones…',
        inDevelopment: 'En desarrollo',
    },
};
// ─── Component ───────────────────────────────────────────────────────
let PluginSelectOrganization = class PluginSelectOrganization extends StateLitElement {
    constructor() {
        super(...arguments);
        this.orgs = [];
        this.value = null;
        this._search = '';
        this._descriptions = new Map();
    }
    willUpdate(changed) {
        if (changed.has('value'))
            this._search = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang];
    }
    get _isAll() {
        return this.value === 0;
    }
    get _isCustom() {
        return this.value !== null && this.value > this.orgs.length;
    }
    get _selectedOrg() {
        if (this.value === null || this.value <= 0 || this.value > this.orgs.length)
            return null;
        return this.orgs[this.value - 1];
    }
    createRenderRoot() { return this; }
    render() {
        if (this._isAll)
            return this._renderAll();
        if (this._isCustom)
            return this._renderCustom();
        return this._renderSelected();
    }
    _renderSelected() {
        const org = this._selectedOrg;
        const max = this.orgs.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.title, org?.name ?? '', this.msg.desc, this.value ?? 0, 0, max)}
                ${org ? this._renderSelectedOrgDetail(org) : nothing}
            </div>
        `;
    }
    _renderSelectedOrgDetail(org) {
        const date = org.created_at
            ? new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short' }).format(new Date(org.created_at))
            : null;
        const description = this._descriptions.get(org.key) ?? org.description ?? '';
        return html `
            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-2.5
            ">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-sm font-semibold text-gray-700 dark:text-gray-300">${org.name}</span>
                    ${date ? html `<span class="text-sm text-gray-400 dark:text-gray-600 font-mono">(${date})</span>` : nothing}
                    <span class="text-gray-300 dark:text-gray-700">·</span>
                    <span class="
                        text-sm px-2 py-0.5 rounded-full font-medium
                        bg-indigo-100 dark:bg-indigo-900/30
                        text-indigo-600 dark:text-indigo-400
                    ">${org.projects.length} ${this.msg.projects}</span>
                </div>
            </div>

            <div class="
                rounded-lg border border-gray-200 dark:border-gray-800
                bg-gray-50 dark:bg-gray-900/50
                px-3 py-3
            ">
                <plugins--markdown-viewer-102020
                    .text=${description}
                    @md-save=${(e) => {
            this._descriptions.set(org.key, e.detail.value);
            this.requestUpdate();
        }}
                ></plugins--markdown-viewer-102020>
            </div>
        `;
    }
    _renderAll() {
        const q = this._search.toLowerCase();
        // @ts-ignore
        const actualOrg = mls?.l5?.actualOrg ?? -1;
        const filtered = this.orgs
            .map((org, i) => ({ org, selectValue: i + 1 }))
            .filter(({ org }) => !q || org.name.toLowerCase().includes(q))
            .sort((a, b) => {
            if (a.org.index === actualOrg)
                return -1;
            if (b.org.index === actualOrg)
                return 1;
            return 0;
        });
        const max = this.orgs.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.title, this.msg.allTitle, this.msg.allDesc, 0, 0, max)}
                <button
                    class="
                        self-end text-sm px-2.5 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors whitespace-nowrap
                    "
                    @click=${() => this._dispatchSelect(max)}
                >+ ${this.msg.createNew}</button>

                <input
                    type="text"
                    .value=${this._search}
                    placeholder=${this.msg.searchPlaceholder}
                    class="
                        w-full text-sm px-2.5 py-1.5 rounded-md
                        border border-gray-200 dark:border-gray-700
                        bg-white dark:bg-gray-900
                        text-gray-700 dark:text-gray-300
                        placeholder-gray-400 dark:placeholder-gray-600
                        focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                    "
                    @input=${(e) => { this._search = e.target.value; }}
                />

                ${this.orgs.length === 0
            ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noOrgs}</span>`
            : filtered.length === 0
                ? html `<span class="text-sm text-gray-400 dark:text-gray-600 italic">${this.msg.noResults}</span>`
                : html `
                            <div class="flex flex-col gap-1.5">
                                ${filtered.map(({ org, selectValue }) => this._renderOrgCard(org, selectValue))}
                            </div>
                        `}
            </div>
        `;
    }
    _renderCustom() {
        const max = this.orgs.length + 1;
        return html `
            <div class="flex flex-col gap-3">
                ${this._renderNavHeader(this.msg.title, this.msg.customTitle, this.msg.customDesc, max, 0, max)}
                <div class="
                    rounded-lg border border-amber-200 dark:border-amber-800/40
                    bg-amber-50 dark:bg-amber-900/10
                    px-3 py-2.5
                ">
                    <span class="text-sm text-amber-600 dark:text-amber-400">${this.msg.inDevelopment}</span>
                </div>
            </div>
        `;
    }
    _renderNavHeader(fixedLabel, itemName, desc, value, min, max) {
        const atMin = value <= min;
        const atMax = value >= max;
        const navBtn = (label, target, disabled) => html `
            <button
                class="px-1.5 py-1 rounded text-base font-mono leading-none transition-colors
                    ${disabled
            ? 'text-gray-300 dark:text-gray-700 cursor-default'
            : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer'}"
                ?disabled=${disabled}
                @click=${() => { if (!disabled)
            this._dispatchSelect(target); }}
            >${label}</button>
        `;
        return html `
            <div class="flex flex-col gap-1 border-b border-gray-200 dark:border-gray-700 pb-4">
                <span class="text-[10px] font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-600 text-center">${fixedLabel}</span>
                <div class="flex items-center">
                    <div class="flex items-center gap-0.5">
                        ${navBtn('«', min, atMin)}
                        ${navBtn('‹', value - 1, atMin)}
                    </div>
                    <span class="flex-1 text-center text-lg font-semibold text-gray-700 dark:text-gray-200">${itemName}</span>
                    <div class="flex items-center gap-0.5">
                        ${navBtn('›', value + 1, atMax)}
                        ${navBtn('»', max, atMax)}
                    </div>
                </div>
                <span class="text-sm text-gray-400 dark:text-gray-500 leading-relaxed text-center">${desc}</span>
            </div>
        `;
    }
    _renderOrgCard(org, selectValue) {
        const clickable = selectValue !== undefined;
        // @ts-ignore
        const isActive = org.index === (mls?.l5?.actualOrg ?? -1);
        return html `
            <div
                class="
                    rounded-lg border
                    ${isActive
            ? 'border-emerald-200 dark:border-emerald-700/50 bg-emerald-50 dark:bg-emerald-900/10'
            : 'border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50'}
                    px-3 py-2.5 flex items-center justify-between gap-2
                    ${clickable
            ? isActive
                ? 'cursor-pointer hover:bg-emerald-100 dark:hover:bg-emerald-900/20 transition-colors'
                : 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800/70 transition-colors'
            : ''}
                "
                @click=${clickable ? () => this._dispatchSelect(selectValue) : nothing}
            >
                <div class="flex items-center gap-2">
                    ${isActive ? html `<div class="w-1.5 h-1.5 rounded-full bg-emerald-500 dark:bg-emerald-400 shrink-0"></div>` : nothing}
                    <span class="text-sm font-medium text-gray-700 dark:text-gray-300">${org.name}</span>
                </div>
                <span class="
                    text-sm px-2 py-0.5 rounded-full font-medium
                    bg-indigo-100 dark:bg-indigo-900/30
                    text-indigo-600 dark:text-indigo-400
                ">${org.projects.length} ${this.msg.projects}</span>
            </div>
        `;
    }
    _dispatchSelect(value) {
        this.dispatchEvent(new CustomEvent('select-org', {
            detail: { value },
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], PluginSelectOrganization.prototype, "orgs", void 0);
__decorate([
    property({ attribute: false })
], PluginSelectOrganization.prototype, "value", void 0);
__decorate([
    state()
], PluginSelectOrganization.prototype, "_search", void 0);
PluginSelectOrganization = __decorate([
    customElement('plugins--select-organization-102020')
], PluginSelectOrganization);
export { PluginSelectOrganization };
