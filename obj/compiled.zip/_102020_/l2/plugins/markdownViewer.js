/// <mls fileReference="_102020_/l2/plugins/markdownViewer.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
// ─── marked (lazy CDN load) ───────────────────────────────────────────
let _markedFn = null;
let _markedLoading = false;
async function _loadMarked() {
    if (_markedFn || _markedLoading)
        return;
    _markedLoading = true;
    const url = 'https://esm.sh/marked@15';
    const mod = await import(url);
    _markedFn = (text) => mod.marked.parse(text);
}
// ─── i18n ─────────────────────────────────────────────────────────────
/// **collab_i18n_start**
const message_en = {
    edit: 'Edit',
    cancel: 'Cancel',
    save: 'Save',
};
const messages = {
    en: message_en,
    pt: { edit: 'Editar', cancel: 'Cancelar', save: 'Salvar' },
    es: { edit: 'Editar', cancel: 'Cancelar', save: 'Guardar' },
};
/// **collab_i18n_end**
// ─── Component ───────────────────────────────────────────────────────
let PluginMarkdownViewer = class PluginMarkdownViewer extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugins--markdown-viewer-102020 {
  display: block;
  border-radius: 0.5rem;
  padding: 0.75rem;
}
plugins--markdown-viewer-102020 [data-md] h1,
plugins--markdown-viewer-102020 [data-md] h2,
plugins--markdown-viewer-102020 [data-md] h3,
plugins--markdown-viewer-102020 [data-md] h4,
plugins--markdown-viewer-102020 [data-md] h5,
plugins--markdown-viewer-102020 [data-md] h6 {
  font-weight: 600;
  color: #374151;
  margin-top: 1em;
  margin-bottom: 0.35em;
  line-height: 1.3;
}
plugins--markdown-viewer-102020 [data-md] h1 {
  font-size: 1.6em;
}
plugins--markdown-viewer-102020 [data-md] h2 {
  font-size: 1.35em;
}
plugins--markdown-viewer-102020 [data-md] h3 {
  font-size: 1.15em;
}
plugins--markdown-viewer-102020 [data-md] p {
  margin-bottom: 0.6em;
}
plugins--markdown-viewer-102020 [data-md] p:last-child {
  margin-bottom: 0;
}
plugins--markdown-viewer-102020 [data-md] ul,
plugins--markdown-viewer-102020 [data-md] ol {
  padding-left: 1.5em;
  margin-bottom: 0.6em;
}
plugins--markdown-viewer-102020 [data-md] ul {
  list-style-type: disc;
}
plugins--markdown-viewer-102020 [data-md] ol {
  list-style-type: decimal;
}
plugins--markdown-viewer-102020 [data-md] li {
  margin-bottom: 0.2em;
}
plugins--markdown-viewer-102020 [data-md] strong {
  font-weight: 600;
  color: #374151;
}
plugins--markdown-viewer-102020 [data-md] em {
  font-style: italic;
}
plugins--markdown-viewer-102020 [data-md] code {
  font-family: ui-monospace, 'Cascadia Code', 'Fira Code', monospace;
  font-size: 0.88em;
  background: rgba(107, 114, 128, 0.1);
  padding: 0.1em 0.35em;
  border-radius: 3px;
}
plugins--markdown-viewer-102020 [data-md] pre {
  background: #f3f4f6;
  padding: 0.75em 1em;
  border-radius: 0.375rem;
  overflow-x: auto;
  margin-bottom: 0.6em;
}
plugins--markdown-viewer-102020 [data-md] pre code {
  background: none;
  padding: 0;
  font-size: 0.85em;
}
plugins--markdown-viewer-102020 [data-md] blockquote {
  border-left: 3px solid #d1d5db;
  padding-left: 0.875em;
  margin: 0.6em 0;
  color: #9ca3af;
  font-style: italic;
}
plugins--markdown-viewer-102020 [data-md] a {
  color: #6366f1;
  text-decoration: underline;
}
plugins--markdown-viewer-102020 [data-md] a:hover {
  color: #4f46e5;
}
plugins--markdown-viewer-102020 [data-md] hr {
  border: none;
  border-top: 1px solid #e5e7eb;
  margin: 0.75em 0;
}
plugins--markdown-viewer-102020 [data-md] table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 0.6em;
  font-size: 0.9em;
}
plugins--markdown-viewer-102020 [data-md] table th,
plugins--markdown-viewer-102020 [data-md] table td {
  border: 1px solid #e5e7eb;
  padding: 0.3em 0.6em;
  text-align: left;
}
plugins--markdown-viewer-102020 [data-md] table th {
  background: #f9fafb;
  font-weight: 600;
}
`);
        this.text = '';
        this._editing = false;
        this._editText = '';
    }
    get msg() {
        return messages[this.getMessageKey(messages)];
    }
    connectedCallback() {
        super.connectedCallback();
        _loadMarked().then(() => this.requestUpdate());
    }
    createRenderRoot() { return this; }
    updated() {
        if (!this._editing) {
            const el = this.querySelector('[data-md]');
            if (!el)
                return;
            el.innerHTML = (_markedFn && this.text?.trim())
                ? _markedFn(this.text)
                : '<span style="font-style:italic;opacity:0.4">—</span>';
        }
    }
    render() {
        return this._editing ? this._renderEdit() : this._renderView();
    }
    _renderView() {
        return html `
            <div class="flex items-start gap-2">
                <div
                    data-md
                    class="flex-1 min-w-0 text-xs text-gray-500 dark:text-gray-400 leading-relaxed"
                ></div>
                <button
                    class="
                        shrink-0 text-[10px] px-2 py-0.5 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-400 dark:text-gray-600
                        hover:text-gray-600 dark:hover:text-gray-400
                        hover:border-gray-300 dark:hover:border-gray-600
                        transition-colors
                    "
                    @click=${() => { this._editText = this.text ?? ''; this._editing = true; }}
                >${this.msg.edit}</button>
            </div>
        `;
    }
    _renderEdit() {
        return html `
            <textarea
                class="
                    w-full text-xs font-mono leading-relaxed resize-none
                    bg-white dark:bg-gray-900
                    border border-gray-300 dark:border-gray-700 rounded-md
                    px-2.5 py-2
                    text-gray-700 dark:text-gray-300
                    focus:outline-none focus:ring-1 focus:ring-indigo-400 dark:focus:ring-indigo-600
                "
                rows="6"
                .value=${this._editText}
                @input=${(e) => { this._editText = e.target.value; }}
            ></textarea>
            <div class="flex justify-end gap-2 mt-2">
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        border border-gray-200 dark:border-gray-700
                        text-gray-500 dark:text-gray-400
                        hover:bg-gray-100 dark:hover:bg-gray-800
                        transition-colors
                    "
                    @click=${() => { this._editing = false; }}
                >${this.msg.cancel}</button>
                <button
                    class="
                        text-xs px-3 py-1 rounded
                        bg-indigo-500 dark:bg-indigo-600 text-white
                        hover:bg-indigo-600 dark:hover:bg-indigo-500
                        transition-colors
                    "
                    @click=${() => { this._save(); }}
                >${this.msg.save}</button>
            </div>
        `;
    }
    _save() {
        this.dispatchEvent(new CustomEvent('md-save', {
            detail: { value: this._editText },
            bubbles: true,
            composed: true,
        }));
        this._editing = false;
    }
};
__decorate([
    property({ attribute: false })
], PluginMarkdownViewer.prototype, "text", void 0);
__decorate([
    state()
], PluginMarkdownViewer.prototype, "_editing", void 0);
__decorate([
    state()
], PluginMarkdownViewer.prototype, "_editText", void 0);
PluginMarkdownViewer = __decorate([
    customElement('plugins--markdown-viewer-102020')
], PluginMarkdownViewer);
export { PluginMarkdownViewer };
