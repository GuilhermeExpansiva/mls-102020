/// <mls fileReference="_102020_/l2/agents/agentNewMoleculePlanner.ts" enhancement="_100554_/l2/enhancementAgent.ts"/>
import { skills as skillList } from '/_102020_/l2/skills/molecules/index';
export function createAgent() {
    return {
        agentName: "agentNewMoleculePlanner",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "Agent Planner for a new moleculle",
        visibility: "public",
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                        .replace("{{ groups }}", JSON.stringify(skillList, null, 2))
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Planner...`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (!['flexible', 'result'].includes(payload?.type))
        throw new Error(`Payload type invalid: ${payload?.type}`);
    console.info(payload.result.group);
    let status = 'completed';
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    if (context.isTest || payload.type === 'result')
        return [updateStatus];
    const isValidGroup = skillList.find((item) => item.name === payload.result.group);
    if (!isValidGroup)
        throw new Error(`[afterPromptStep] invalid group: ${payload.result.group}`);
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepTitle: 'Preparing requisits',
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentNewMoleculePlanner2",
            prompt: JSON.stringify(payload.result),
            rags: null,
        }
    };
    const intents = [newStep];
    return intents;
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->


Tasks: Understand the purpose of the widget by analyzing the original user prompt and identify the correct group 
If the original prompt is not about creating a web component, return an error asking the user to redo the request.

##Avaliables groups
{{ groups }}

## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: {
            group: string,
            prompt: string // user prompt fixed if needed
        };
    } |
    {
        type: "result";
        result: string
    }
`;
//#endregion 
