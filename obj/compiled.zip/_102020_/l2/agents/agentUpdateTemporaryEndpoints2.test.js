/// <mls fileReference="_102020_/l2/agents/agentUpdateTemporaryEndpoints2.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
