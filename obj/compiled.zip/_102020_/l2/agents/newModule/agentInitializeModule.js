/// <mls fileReference="_102020_/l2/agents/newModule/agentInitializeModule.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { getAgentStepByAgentName } from "/_102027_/l2/aiAgentHelper.js";
import { finishClarification } from "/_102027_/l2/aiAgentOrchestration.js";
import '/_102025_/l2/widgetQuestionsForClarification.js';
export function createAgent() {
    return {
        agentName: "agentInitializeModule",
        agentProject: 102020,
        agentFolder: "agents/newModule",
        agentDescription: "Create New Module on current project",
        visibility: "public",
        beforePromptImplicit,
        afterPromptStep,
        beforeClarificationStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const folders = Array.from(new Set(Object.values(mls.stor.files)
        .filter(f => f.project === mls.actualProject && f.level !== 3 && f.folder)
        .map(f => f.folder)));
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1.replace("{{folders}}", folders.join(", "))
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: `New module`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type === "result") {
        throw new Error(payload?.result);
    }
    if (payload?.type !== 'clarification' || !payload.json)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    console.log("afterPrompt", payload.json);
    return [];
}
async function beforeClarificationStep(agent, context, parentStep, step, hookSequential, json) {
    if (!context.task)
        throw new Error(`[beforeClarificationStep] invalid task: undefined`);
    let status = 'completed';
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: 'Teste step title 2',
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentToBeConceptual",
            prompt: "{{clarification}}",
            rags: null,
        }
    };
    const intentsToClarification = [newStep, updateStatus];
    // Build the clarification widget locally (it lives in mls-102025, the production
    // frontend) and wire it to the shared orchestration via finishClarification.
    let ret = json;
    if (typeof json === 'string')
        ret = JSON.parse(json || '');
    const clarificationValue = {
        taskId: context.task.PK,
        stepId: 0,
        title: ret.title,
        legends: ret.legends || [],
        userLanguage: ret.userLanguage || '',
        questions: ret.questions,
    };
    const div = document.createElement('div');
    const clariEl = document.createElement('widget-questions-for-clarification-102025');
    clariEl.addEventListener('clarification-finish', (e) => {
        const { detail } = e;
        const { value, action } = detail;
        const normalizedValue = value == null ? '' : typeof value === 'object' ? JSON.stringify(value) : String(value);
        finishClarification(agent, step.stepId, parentStep.stepId, intentsToClarification, context, normalizedValue, action);
    });
    clariEl.value = clarificationValue;
    clariEl.setAttribute('mode', 'new');
    div.appendChild(clariEl);
    return div;
}
const system1 = `
<!-- modelType: codeinstruct -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10, code2 (kimi 2.5) -->

You are an assistant responsible for helping create a new module in the current project for collab.codes. Your task is to analyze the user's request and return a JSON object in the format specified under 'Output format'. Use the same language as the user in the prompt.

Analyze the user's request:
- If invalid or not about creating a new system/module → return error
- If valid → return a clarification

## Already existing modules
{{folders}}

## Output format
Return only valid JSON in the following structure:
export type Output1 =
  {
    type: "clarification";
    json: Clarification1
  } | {
    type: "result"; // for errors or invalid user prompt
    result: string;
  };

export interface Clarification1 {
  userLanguage: string; // language detected in prompt, iso, ex: 'en'
  title: "Clarification 1/2";
  userPrompt: string; // put the userPrompt here, no syntax error
  questions: {
    roles: Question; // roles - e.g. 'admin', 'public', 'client', 'operator', 'financial'
    publicTarget: Question; // publicTarget
    tone: Question; // tone - e.g. Friendly, professional, and concise. Always aim to clarify without assuming.
    languages: Question; // languages - use default language from prompt, default is only one languages
    moduleName: Question; // moduleName - suggest a module name , search in "Already existing modules"
    visualStyle: Question; // visual style of the site - e.g. 'Clean & minimalist', 'Dark & modern', 'Light & friendly', 'Corporate & professional', 'Bold & vibrant'
    openQuestion1: Question; // open question to clarify features,
    openQuestion2: Question; // open question to clarify features,
    openQuestion3: Question; // open question to clarify features,
  },
  legends: [ // translate
    "This is the first clarification ",
    "before creating somethings"
  ];
}

export interface Question {
  type: "open";
  question: string;
  answer: string; // AI-suggested default answer. This answer simulates how a real user would respond. Write in first person and with a natural tone.
}
`;
//#endregion
export function getPayload1(agent, context) {
    if (!agent || !context || !context.task)
        throw new Error(`[${agent.agentName}](getPayload1) Invalid context or agent`);
    const agentStep = getAgentStepByAgentName(context.task, agent.agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agent.agentName}](getPayload1) no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[1]; // [0]-> original clarification, [1]->final clarification
    if (!resultStep || resultStep.type !== "clarification" || !resultStep.json)
        throw new Error(`[${agent.agentName}] [getPayload] No step clarification found for this agent.`);
    let payload1 = resultStep.json;
    if (!payload1 || (typeof payload1 === "string") || !payload1.legends)
        throw new Error(`[${agent.agentName}] (getPayload1) Invalid clarification response`);
    // get userPrompt
    // payload1.userPrompt = agentStep?.interaction?.input.find((input) => input.type === 'human')?.content || '';
    return payload1;
}
