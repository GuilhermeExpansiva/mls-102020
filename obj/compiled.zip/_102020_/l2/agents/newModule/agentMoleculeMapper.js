/// <mls fileReference="_102020_/l2/agents/newModule/agentMoleculeMapper.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { findPreviousAgentStep } from '/_102027_/l2/aiAgentHelper.js';
import { getMaterializeOrchestrator } from '/_102020_/l2/agents/newModule/materializeOrchestrator.js';
export function createAgent() {
    return {
        agentName: "agentMoleculeMapper",
        agentProject: 102020,
        agentFolder: "agents/newModule",
        agentDescription: "Maps page UI elements to molecule groups and variants from mls-102040",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const info = JSON.parse(userPrompt);
    const prompt = await buildPrompt(info.path);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: prompt }
            ],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: info.path,
            longTermMemory: { path: info.path, onlyStep: "true" }
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const info = JSON.parse(args);
    const prompt = await buildPrompt(info.path);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: prompt,
        systemPrompt: system1
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = step.interaction?.payload?.[0];
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid payload: ${JSON.stringify(payload)}`);
    const output = payload.result;
    const intents = await processOutput(context, output, parentStep);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status: 'completed'
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output, parentStep) {
    const stepOri = context.task
        ? (findPreviousAgentStep(context.task, parentStep.stepId))?.stepId
        : parentStep.stepId;
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: stepOri || parentStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: 'agentMoleculeRewriter',
            prompt: JSON.stringify({ path: output.path, map: output.map, usedGroups: output.usedGroups }),
            rags: [],
        }
    };
    return [newStep];
}
async function buildPrompt(path) {
    const pathNorm = path.startsWith('/') ? path.slice(1) : path;
    const f = mls.stor.convertFileReferenceToFile(pathNorm);
    const key = mls.stor.getKeyToFile(f);
    const sf = mls.stor.files[key];
    if (!sf)
        throw new Error(`[agentMoleculeMapper] File not found: ${path}`);
    const pageSrc = await sf.getContent();
    const orch = getMaterializeOrchestrator(pathNorm);
    const catalog = await orch.getSkill('_102020_/l2/agents/newModule/catalog.ts');
    return `## Page source\n\`\`\`typescript\n${pageSrc}\n\`\`\`\n\n## Molecule catalog\n${catalog}`;
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You must return ONLY a valid JSON object. No preamble, no explanation, no markdown
fences, no text before or after the JSON. Start your response with { and end with }

## Task
Analyze the provided Lit web component page and map each replaceable UI element
to the most appropriate molecule from the catalog.

## Rules
- Only map concrete interactive elements: text inputs, number inputs, date/time pickers,
  money fields, buttons, selects, checkboxes, toggles, file uploads, search bars, etc.
- Do NOT map structural/layout elements: div, section, header, main, aside, form wrappers,
  grid containers, decorative spans
- For each element, choose the group and variant that best match the field name and context
- Group name must be exactly as listed in the catalog (all lowercase, no spaces)
- Variant must be exactly one of the variants listed for that group
- usedGroups must contain only the distinct groups actually present in the map (no duplicates)

## Output format

export type Output = {
  type: "flexible";
  result: {
    path: string;
    map: Array<{
      elementDescription: string;
      group: string;
      variant: string;
      reason: string;
    }>;
    usedGroups: string[];
  }
}

`;
//#endregion
