/// <mls fileReference="_102020_/l2/agents/newModule/agentMaterializePageLit.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { findPreviousAgentStep } from '/_102027_/l2/aiAgentHelper.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import { convertFileNameToTag, convertTagToFileName } from '/_102027_/l2/utils.js';
import { getMaterializeOrchestrator } from '/_102020_/l2/agents/newModule/materializeOrchestrator.js';
import { addModuleNav, addModuleRoute } from '/_102020_/l2/newModule/astModuleFront.js';
import { addNav, addPage } from '/_102020_/l2/newModule/astIndex.js';
export function createAgent() {
    return {
        agentName: "agentMaterializePageLit",
        agentProject: 102020,
        agentFolder: "agents/newModule",
        agentDescription: "new agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const info = JSON.parse(userPrompt);
    const moduleName = info.moduleName || context.task?.iaCompressed?.longMemory['moduleName'];
    const device = info.device || context.task?.iaCompressed?.longMemory['device'] || 'web';
    const type = info.type || context.task?.iaCompressed?.longMemory['type'] || 'page11';
    info.project = mls.actualProject || 0;
    const orch = getMaterializeOrchestrator(info.path);
    info.item = await orch.getToExecuteOnlyMaterialize(info.id);
    const prompt = await getSkill(info, moduleName, device, type);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: prompt }
            ],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: info.path,
            longTermMemory: { moduleName: info.moduleName, device, type, onlyStep: "true" }
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    console.info('--------agentMaterializePageLit--------');
    const info = JSON.parse(args);
    info.project = mls.actualProject || 0;
    const moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    const device = context.task?.iaCompressed?.longMemory['device'] || 'web';
    const type = context.task?.iaCompressed?.longMemory['type'] || 'page11';
    const prompt = await getSkill(info, moduleName, device, type);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: prompt,
        systemPrompt: system1
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output, agent, parentStep);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output, agent, parentStep) {
    const onlyThisStep = (context.task?.iaCompressed?.longMemory['onlyStep'] || 'false') === 'true';
    output.outputPath = output.outputPath.startsWith('/') ? output.outputPath.slice(1) : output.outputPath;
    const orch = getMaterializeOrchestrator(output.path);
    await orch.createStorFile(output.outputPath, parseAISource(output.srcFile));
    const info = mls.stor.convertFileReferenceToFile(output.outputPath);
    if (info.project === 0)
        info.project = mls.actualProject || 0;
    const tag = convertFileNameToTag(info);
    const srcHtml = `<${tag}></${tag}>`;
    await orch.createStorFile(output.outputPath.replace('.ts', '.html'), srcHtml);
    await addModuleRoutes(context, info.shortName, tag);
    await addIndexPage(context, info.shortName, tag);
    const stepOri = context.task ? (findPreviousAgentStep(context.task, parentStep.stepId))?.stepId : parentStep.stepId;
    const group = await orch.processGroup(output.id);
    const newSteps = [];
    Object.keys(group).forEach((g) => {
        const info = group[g];
        info.forEach((i) => {
            const newStep = {
                type: "add-step",
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: stepOri || parentStep.stepId,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    status: 'waiting_human_input',
                    nextSteps: [],
                    agentName: g,
                    prompt: JSON.stringify({ path: output.path, item: i }),
                    rags: [],
                }
            };
            if (!onlyThisStep)
                newSteps.push(newStep);
        });
    });
    return newSteps;
}
async function addModuleRoutes(context, shortName, tag) {
    let moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!moduleName)
        throw new Error('Not found moduleName 2: agentMaterializePageLit');
    const key = mls.stor.getKeyToFile({ project: mls.actualProject || 0, level: 2, folder: `${moduleName}`, shortName: "module", extension: ".ts" });
    if (!mls.stor.files[key])
        throw new Error('[agentMaterializePageLit]Not found module file');
    const info = convertTagToFileName(tag);
    info.extension = '.js';
    info.level = 2;
    let fileReference = mls.stor.convertFileToFileReference(info);
    fileReference = fileReference.startsWith('/') ? fileReference : '/' + fileReference;
    const sf = mls.stor.files[key];
    let src = await sf.getContent();
    src = addModuleNav(src, { id: shortName, label: shortName, href: `/${moduleName}/${shortName}`, description: shortName });
    src = addModuleRoute(src, {
        path: `/${moduleName}/${shortName}`,
        aliases: [],
        entrypoint: fileReference.replace('.ts', '.js'),
        tag,
        title: shortName,
    });
    await saveFile(mls.stor.convertFileToFileReference(sf), src);
}
async function addIndexPage(context, shortName, tag) {
    let moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!moduleName)
        throw new Error('Not found moduleName 3: agentMaterializePageLit');
    const key = mls.stor.getKeyToFile({ project: mls.actualProject || 0, level: 2, folder: `${moduleName}`, shortName: "index", extension: ".ts" });
    if (!mls.stor.files[key])
        throw new Error('[agentMaterializePageLit]Not found index file');
    const info = convertTagToFileName(tag);
    info.extension = '.js';
    info.level = 2;
    let fileReference = mls.stor.convertFileToFileReference(info);
    fileReference = fileReference.startsWith('/') ? fileReference : '/' + fileReference;
    const sf = mls.stor.files[key];
    let src = await sf.getContent();
    src = addNav(src, { label: shortName, href: `/${moduleName}/${shortName}` });
    src = addPage(src, {
        path: `/${moduleName}/${shortName}`,
        title: shortName,
        tagName: tag,
        loader: fileReference,
    });
    await saveFile(mls.stor.convertFileToFileReference(sf), src);
}
async function saveFile(ref, src) {
    const info = mls.stor.convertFileReferenceToFile(ref);
    const k = mls.stor.getKeyToFile(info);
    let sf = mls.stor.files[k];
    if (!sf) {
        const param = {
            ...info,
            source: src
        };
        sf = await createStorFile(param, true, true, true);
    }
    else {
        const m = await sf.getOrCreateModel();
        if (m && m.model)
            m.model.setValue(src);
    }
    await mls.stor.localStor.setContent(sf, { contentType: 'string', content: src });
}
async function getSkill(info, moduleName, device, type) {
    const project = info.project || 0;
    const mod = await import(`/_${project}_/l2/${moduleName}/module.js`);
    if (!mod || !mod.moduleGenome)
        throw new Error('[agentMaterializePageLit] Not found moduleGenome');
    const genomeKey = Object.keys(mod.moduleGenome).find(k => k.startsWith(`${device}/`) && k.endsWith(`/${type}`));
    if (!genomeKey)
        throw new Error(`[agentMaterializePageLit] no genome key found for device "${device}" and type "${type}"`);
    const genome = mod.moduleGenome[genomeKey];
    if (!genome)
        throw new Error(`[agentMaterializePageLit] no genome config for key "${genomeKey}"`);
    const prj = await import(`/_${project}_/l2/project.js`);
    if (!prj || !prj.projectConfig)
        throw new Error('[agentMaterializePageLit] Not found projectConfig');
    if (!prj.projectConfig.layouts)
        throw new Error('[agentMaterializePageLit] Not found projectConfig layout dont config');
    const layout = Object.values(prj.projectConfig.layouts).find((v) => v.name === genome.layout);
    if (!layout)
        throw new Error('[agentMaterializePageLit] Not found projectConfig layout dont config to:' + genome.layout);
    const fileName = info.item.outputPath.startsWith('/') ? info.item.outputPath.slice(1) : info.item.outputPath;
    const genomeKeyNorm = genomeKey.endsWith('/') ? genomeKey.slice(0, -1) : genomeKey;
    info.item.outputPath = `_${project}_/l2/${moduleName}/${genomeKeyNorm}/${fileName}`;
    const orch = getMaterializeOrchestrator(info.path);
    const user = await orch.getVar(info.path, info.item.specVar);
    const skill = await orch.getSkill(layout.skill);
    const prompt = `##Skill\n${skill}\n\n##User data\n${user}\n\n##User info\n${JSON.stringify(info)}`;
    return prompt;
}
function parseAISource(raw) {
    return raw;
    decodeUnicodeEscapes(raw);
}
function decodeUnicodeEscapes(src) {
    return src.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You must return ONLY a valid JSON object. No preamble, no explanation, no markdown
fences, no text before or after the JSON. Start your response with { and end with }


## Output format
The srcFile value must be a single-line JSON string.
Escape ALL special characters inside it:
  - newlines     → \n
  - tabs         → \t
  - double quotes → \"
  - backslashes  → \\
Never embed raw multiline code blocks inside a JSON string value.

Return strictly this structure:

export type Output =
  {
    type: "flexible";
    result: {
      path: string; // same value by "User info";
      id: string; // same value by "User info";
      outputPath: string, // same value by "User info";
      srcFile: string
    }
  }

`;
//#endregion 
