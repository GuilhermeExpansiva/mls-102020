/// <mls fileReference="_102020_/l2/agents/agentNewMolecule.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { appendLongTermMemory } from '/_102027_/l2/aiAgentHelper.js';
import { convertFileNameToTag } from '/_102027_/l2/utils';
// import { skill as skillDesing } from '/_102020_/l2/skills/aura/design.js';
import { skill as skillAura } from '/_102020_/l2/skills/aura/overview.js';
import { skill as skillMolecule } from '/_102020_/l2/skills/aura/moleculeGeneration2.js';
import { skills as skillList } from '/_102020_/l2/skills/molecules/index';
export function createAgent() {
    return {
        agentName: "agentNewMolecule",
        agentProject: 102020,
        agentFolder: "agents",
        agentDescription: "New agent",
        visibility: "public",
        beforePromptAtomic,
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptAtomic(agent, context, file, userPrompt) {
    if (userPrompt)
        throw new Error(`[beforePromptAtomic] invalid args: '${userPrompt}'`);
    return [];
}
;
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const baseMolecule = await getBaseMolecule();
    const userPrompt2 = await getSystemUser(context, userPrompt);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                        // .replace("{{systemSkillDesign}}", skillDesing)
                        .replace("{{systemSkillAura}}", skillAura)
                        .replace("{{systemSkillMolecule}}", skillMolecule)
                        .replace("{{systemBaseMolecule}}", baseMolecule)
                }, {
                    type: "human",
                    content: userPrompt2
                }],
            taskTitle: `Creating molecule`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    const baseMolecule = await getBaseMolecule();
    const userPrompt = await getSystemUser(context, args);
    const continueIntent = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: userPrompt,
        systemPrompt: system1
            // .replace("{{systemSkillDesign}}", skillDesing)
            .replace("{{systemSkillAura}}", skillAura)
            .replace("{{systemSkillMolecule}}", skillMolecule)
            .replace("{{systemBaseMolecule}}", baseMolecule)
    };
    return [continueIntent];
}
async function getSystemUser(context, fileReference) {
    const path = mls.stor.getPathToFile(fileReference);
    const files = await mls.stor.getFiles({ ...path, loadContent: false });
    if (!files.ts)
        throw new Error(`[getSystemUser] invalid file: ${fileReference}`);
    const data = await getMoleculeSkill(files.ts);
    const skillByGroup = await getGroupSkill(data.group);
    const tagName = convertFileNameToTag(path);
    await appendLongTermMemory(context, { 'group': data.group });
    const system2 = `

    ## TagName : ${tagName}

    ## File Reference : ${data.fileReference}
    
    ## Skill Group: ${data.group}
    \`\`\`
        ${skillByGroup}
    \`\`\`

    `;
    return system2;
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output) {
    console.info(output);
    const fileRef = await updateFiles(context, output);
    const group = context.task?.iaCompressed?.longMemory['group'];
    console.info({ fileRef, group: group });
    const newStep = {
        type: "add-step",
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: 1,
        stepTitle: 'Preparing playground',
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            status: 'waiting_human_input',
            nextSteps: [],
            agentName: "agentNewMoleculePlayground",
            prompt: JSON.stringify({ group: group, fileReference: fileRef }),
            rags: null,
        }
    };
    return [newStep];
}
async function updateFiles(context, result) {
    const molecule = result.ts;
    const fileReference = molecule.trim().split('\n')[0];
    const tripleSlash = mls.common.tripleslash.parseXMLTripleSlash(fileReference);
    let fileInfo = mls.stor.convertFileReferenceToFile(tripleSlash.variables['fileReference']);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
    const paramsTs = { ...fileInfo, content: molecule, versionRef: new Date().toISOString(), extension: ".ts" };
    await updateStorFile(paramsTs);
    return tripleSlash.variables['fileReference'];
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentNewMolecule] Invalid storFile');
    const path = mls.stor.getKeyToFile(params);
    console.log(`[agentNewMolecule] updating file: ${path}`);
    console.log(`[agentNewMolecule] updating content: ${params.content}`);
    const models = await file.getOrCreateModel();
    models.model.setValue(params.content);
    mls.editor.forceModelUpdate(models.model);
}
async function getGroupSkill(group) {
    const path = skillList.find((item) => item.name === group)?.skillReference;
    if (!path)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    const module = await import(path);
    if (!module || !module.skill)
        throw new Error(`[getGroupSkill] skill for group not found: ${path}`);
    if (typeof module.skill !== 'string')
        throw new Error(`[getGroupSkill] invalid type of skill: ${path}, must be string`);
    return module.skill;
}
async function getBaseMolecule() {
    const key = mls.stor.getKeyToFile({ project: 102020, shortName: 'moleculeBase', folder: '', extension: '.ts', level: 2 });
    const storFile = mls.stor.files[key];
    if (!storFile)
        return '';
    return await storFile.getContent();
}
async function getMoleculeSkill(file) {
    const path = `/_${file.project}_/${file.folder ? file.folder + '/' : ''}${file.shortName}.defs.js`;
    const defs = await import(path);
    const fileReference = mls.stor.convertFileToFileReference(file);
    if (!defs)
        throw new Error(`[getMoleculeSkill] defs not found: ${path}`);
    if (!defs.skill)
        throw new Error(`[getMoleculeSkill] defs skill not found: ${path}`);
    if (!defs.group)
        throw new Error(`[getMoleculeSkill] defs group not found: ${path}`);
    return {
        skill: defs.skill,
        group: defs.group,
        fileReference
    };
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You are a senior Frontend Architect and Staff Software Engineer with 20+ years of experience building large-scale web applications using TypeScript, Lit, and state-driven architectures.

You must generate production-ready code that compiles without errors.
Task: Generate a molecule according the user request.

## Aura Overview
\`\`\`
{{systemSkillAura}}
\`\`\`

## Molecule Skill
\`\`\`
{{systemSkillMolecule}}
\`\`\`

## Molecule Class Base
\`\`\`typescript
{{systemBaseMolecule}}
\`\`\`

## Desing Skill
\`\`\`
{{systemSkillDesign}}
\`\`\`


## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: Result;
    }

export type Result = {
    ts: string,
}

`;
//#endregion 
