/// <mls fileReference="_102020_/l2/agents/agentNewPrototype3.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
