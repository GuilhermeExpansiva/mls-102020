/// <mls fileReference="_102020_/l2/agentNewSolution/agentFinalizeSolutionPlan.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, createPlannerPromptReadyIntent, createPlannerVariableToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, findStepByPlanId, getActorIdSet, getPlannerOutput, getPlanningContextSnapshot, hasAcceptedNowArtifact, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { saveNewSolutionAgentTracePayload, saveNewSolutionPlanArtifacts } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
import { getBlueprintReviewOutput } from '/_102020_/l2/agentNewSolution/agentBlueprintReview.js';
import { getSolutionBlueprintOutput } from '/_102020_/l2/agentNewSolution/agentSolutionBlueprint.js';
import { finalSolutionPlanResultSchema } from '/_102020_/l2/agentNewSolution/agentSolutionPlanSchemas.js';
export function createAgent() {
    return {
        agentName: 'agentFinalizeSolutionPlan',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Finalize the solution plan after blueprint review',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const FINALIZE_SOLUTION_PLAN_TOOL_NAME = 'submitFinalSolutionPlan';
export const FINALIZE_SOLUTION_PLAN_STEP_ID = '08-finalize-solution-plan';
const FINALIZE_SOLUTION_PLAN_ALIASES = [FINALIZE_SOLUTION_PLAN_STEP_ID, 'plan-finalize-solution-plan'];
const finalizeSolutionPlanToolSchema = createPlannerVariableToolSchema(FINALIZE_SOLUTION_PLAN_TOOL_NAME, 'Submit the final solution plan after applying blueprint review findings.', finalSolutionPlanResultSchema);
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentFinalizeSolutionPlan](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const snapshot = getPlanningContextSnapshot(context);
    const blueprint = getSolutionBlueprintOutput(context);
    const review = getBlueprintReviewOutput(context);
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(FINALIZE_SOLUTION_PLAN_TOOL_NAME), buildHumanPrompt(args, blueprint, review, snapshot), finalizeSolutionPlanToolSchema, FINALIZE_SOLUTION_PLAN_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractFinalizeSolutionPlanOutput(payload);
        validateFinalizeSolutionPlanOutput(output, context);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentFinalizeSolutionPlan returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentFinalizeSolutionPlan returned status needs_input; keeping corrected plan draft.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    // TODO-FINAL-019: advisory actor-contract check at the source. Every actor reference in the
    // final plan must be one of actors[].actorId (no hard-coded/translated names). Non-fatal here
    // (downstream index validators are the hard gates); surfaces drift early via console.warn.
    if (status === 'completed' && output && output.status === 'ok')
        warnFinalizeActorConsistency(output);
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    if (status === 'completed' && output)
        await saveNewSolutionPlanArtifacts(context, agent.agentName, step, output);
    const intents = [
        createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? 'input' : undefined),
    ];
    if (status === 'completed') {
        const blueprintStep = findStepByPlanId(context, 'plan-solution-blueprint');
        if (blueprintStep?.type === 'agent') {
            intents.push(createPlannerUpdateStatusIntent(context, parentStep, blueprintStep, hookSequential, 'completed', undefined, 'input_output'));
        }
    }
    return intents;
}
export function getFinalizeSolutionPlanOutput(context) {
    return getPlannerOutput(context, 'agentFinalizeSolutionPlan', finalizeSolutionPlanConfig, output => validateFinalizeSolutionPlanOutput(output, context));
}
function extractFinalizeSolutionPlanOutput(payload) {
    return extractPlannerOutput(payload, finalizeSolutionPlanConfig);
}
const finalizeSolutionPlanConfig = {
    toolName: FINALIZE_SOLUTION_PLAN_TOOL_NAME,
    stepId: FINALIZE_SOLUTION_PLAN_STEP_ID,
    stepIdAliases: FINALIZE_SOLUTION_PLAN_ALIASES,
    normalizeResult: normalizeFinalSolutionPlanResult,
};
function normalizeFinalSolutionPlanResult(value) {
    const result = assertRecord(value, 'result');
    const ontology = assertRecord(result.ontology, 'result.ontology');
    const approvedArtifacts = assertRecord(result.approvedArtifacts, 'result.approvedArtifacts');
    return {
        module: assertRecord(result.module, 'result.module'),
        actors: assertArray(result.actors, 'result.actors'),
        capabilities: assertArray(result.capabilities, 'result.capabilities'),
        ontology: {
            entities: assertRecord(ontology.entities, 'result.ontology.entities'),
        },
        rules: assertArray(result.rules, 'result.rules'),
        relationships: assertArray(result.relationships, 'result.relationships'),
        userActions: assertArray(result.userActions, 'result.userActions'),
        approvedArtifacts: {
            pages: assertArray(approvedArtifacts.pages, 'result.approvedArtifacts.pages'),
            workflows: assertArray(approvedArtifacts.workflows, 'result.approvedArtifacts.workflows'),
            plugins: assertArray(approvedArtifacts.plugins, 'result.approvedArtifacts.plugins'),
            agents: assertArray(approvedArtifacts.agents, 'result.approvedArtifacts.agents'),
            horizontalModules: assertArray(approvedArtifacts.horizontalModules, 'result.approvedArtifacts.horizontalModules'),
            mdm: assertArray(approvedArtifacts.mdm, 'result.approvedArtifacts.mdm'),
            metricTables: assertArray(approvedArtifacts.metricTables, 'result.approvedArtifacts.metricTables'),
            metricDashboards: assertArray(approvedArtifacts.metricDashboards, 'result.approvedArtifacts.metricDashboards'),
            usecaseEntities: assertArray(approvedArtifacts.usecaseEntities, 'result.approvedArtifacts.usecaseEntities'),
        },
        decisions: assertArray(result.decisions, 'result.decisions'),
        deferredItems: assertArray(result.deferredItems, 'result.deferredItems'),
    };
}
function validateFinalizeSolutionPlanOutput(output, context) {
    const snapshot = getPlanningContextSnapshot(context);
    if (output.status === 'ok' && output.result.approvedArtifacts.mdm.length === 0)
        throw new Error('final solution plan must keep MDM');
    if (output.status === 'ok' && snapshot.initialMetricsRequested) {
        if (output.result.approvedArtifacts.metricTables.length === 0)
            throw new Error('initial metrics requested, but final plan has no metricTables');
        if (output.result.approvedArtifacts.metricDashboards.length === 0)
            throw new Error('initial metrics requested, but final plan has no metricDashboards');
    }
    if (output.status === 'ok' && hasAcceptedNowArtifact(snapshot.implementationDecisions, 'usecaseEntity') && output.result.approvedArtifacts.usecaseEntities.length === 0) {
        throw new Error('accepted usecaseEntity planning, but final plan has no usecaseEntities');
    }
    if (output.status === 'needs_input' && output.questions.length === 0)
        throw new Error('needs_input final plan must include questions');
}
// TODO-FINAL-019: warn (non-fatal) about actor references that are not declared in actors[].actorId.
function warnFinalizeActorConsistency(output) {
    const actorIds = getActorIdSet(output.result.actors);
    if (actorIds.size === 0)
        return;
    const unknown = new Set();
    const check = (value) => {
        if (typeof value === 'string' && value.trim() && !actorIds.has(value))
            unknown.add(value);
    };
    const asRecords = (value) => Array.isArray(value) ? value.filter((v) => !!v && typeof v === 'object') : [];
    for (const cap of asRecords(output.result.capabilities))
        check(cap.actor);
    for (const ua of asRecords(output.result.userActions))
        check(ua.actor);
    for (const page of asRecords(output.result.approvedArtifacts.pages))
        check(page.actor);
    for (const dash of asRecords(output.result.approvedArtifacts.metricDashboards))
        check(dash.actor);
    for (const wf of asRecords(output.result.approvedArtifacts.workflows)) {
        if (Array.isArray(wf.actors))
            wf.actors.forEach(check);
        else
            check(wf.actor);
    }
    if (unknown.size > 0) {
        console.warn(`[agentFinalizeSolutionPlan] actor refs not in actors[].actorId (TODO-FINAL-019): ${[...unknown].join(', ')}. Downstream index validators will reject these.`);
    }
}
function buildHumanPrompt(args, blueprint, review, snapshot) {
    return `## Planned step args
${args}

## Solution blueprint
${JSON.stringify(blueprint, null, 2)}

## Blueprint review
${JSON.stringify(review, null, 2)}

## Accepted implementation decisions
${JSON.stringify(snapshot.implementationDecisions, null, 2)}

## Initial metrics/dashboard requested
${snapshot.initialMetricsRequested}
`;
}
const systemPrompt = `
<!-- modelType: codeinstruct -->

You are agentFinalizeSolutionPlan for the collab.codes "newSolution" flow.
Apply the blueprint review and produce the final solution plan.
Use the same language as the user for labels, descriptions, questions, and trace.
Use English camelCase identifiers for ids and PascalCase for entity names.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Rules
- Fix all review issues with severity "error".
- Keep later items in deferredItems.
- Do not remove MDM.
- Do not remove approved initial metrics/dashboard.
- Do not remove layer_3 usecase planning when BFF commands, writes, lifecycle changes, or metric updates exist.
- Keep rules centralized in rules with stable ruleId values.
- Page definitions and BFF commands must reference rules by ruleId.
- Keep ontology.entities as an object map keyed by PascalCase entity id. Do not require duplicating entityId inside each entity value.
- Do not continue if an error cannot be fixed from available context; return status "needs_input" with questions.
`;
