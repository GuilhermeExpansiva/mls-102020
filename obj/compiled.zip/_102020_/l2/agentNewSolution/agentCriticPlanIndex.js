/// <mls fileReference="_102020_/l2/agentNewSolution/agentCriticPlanIndex.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { MAX_PLAN_INDEX_CRITIC_ATTEMPTS, REPAIR_PLAN_INDEX_AGENT_NAME, createPlanIndexReviewStepIntent, createPlannerPromptReadyIntent, createPlannerUpdateStatusIntent, extractPlannerOutput, findLatestPlanIndexReviewStep, findParentStepOfStep, parsePlanIndexReviewArgs, resolveIndexStepForReview, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { PLAN_INDEX_CRITIQUE_TOOL_NAME, buildEmptyHealthReport, critiqueFindingsToHealth, getPlanIndexReviewConfig, maxAttemptsForLocalErrors, planIndexCritiqueExtractConfig, planIndexCritiqueToolSchema, } from '/_102020_/l2/agentNewSolution/agentPlanIndexReview.js';
import { saveNewSolutionAgentTracePayload, } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentCriticPlanIndex',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Criticize one plan index before releasing its dependent definition steps',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentCriticPlanIndex](beforePromptStep) invalid params');
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const reviewArgs = parsePlanIndexReviewArgs(args || step.prompt);
    const config = getPlanIndexReviewConfig(reviewArgs.indexName);
    // Critic steps are designed as direct children of the index step, but the hook's parentStep
    // is not always the real parent (task5 incident) — resolve the index step defensively.
    const indexStep = resolveIndexStepForReview(context, parentStep, config.sourceAgentName);
    let output;
    let localFindings;
    try {
        output = config.getCurrentOutput(context);
        localFindings = config.runLocalCheckpoint(context, output);
    }
    catch (error) {
        // The index payload became unreadable between generation and review: fail early and clearly.
        const message = error instanceof Error ? error.message : String(error);
        return failIndexIntents(context, indexStep, step, hookSequential, `critic could not read ${reviewArgs.indexName}: ${message}`);
    }
    // Empty/disabled index: nothing to criticize, approve without spending an LLM call.
    if (config.skipCriticWhen?.(output)) {
        const healthReport = buildEmptyHealthReport();
        healthReport.attempts = reviewArgs.attempt;
        healthReport.localWarnings = localFindings.warnings;
        healthReport.notes.push('critic skipped: empty or disabled index');
        return approveIndexIntents(context, config, indexStep, step, hookSequential, output, healthReport);
    }
    // deterministic local errors go straight to repair, no critic LLM needed.
    if (localFindings.errors.length > 0) {
        // Circuit breaker (task5 incident): from attempt 2 on, a repair MUST be visible to this
        // critic (completed, or in_progress with payload). If none is, every further round would
        // revalidate the same unrepaired index — fail fast with the real cause instead of burning
        // the whole repair budget on LLM calls that change nothing.
        if (reviewArgs.attempt > 1 && !findLatestPlanIndexReviewStep(context, REPAIR_PLAN_INDEX_AGENT_NAME, reviewArgs.indexName, true)) {
            return failIndexIntents(context, indexStep, step, hookSequential, `critic attempt ${reviewArgs.attempt} still sees the unrepaired ${reviewArgs.indexName} (no repair payload visible — orchestration issue, see task5 incident); aborting the repair loop early`);
        }
        // T-017: when every local error has a mechanical repair (id normalization / referential
        // integrity), grant extra attempts — they do not consume the semantic critic budget.
        const maxAttempts = maxAttemptsForLocalErrors(localFindings.errors, MAX_PLAN_INDEX_CRITIC_ATTEMPTS);
        if (reviewArgs.attempt >= maxAttempts) {
            const summary = localFindings.errors.map(item => item.message).join('; ');
            return failIndexIntents(context, indexStep, step, hookSequential, `local checkpoint still failing after ${reviewArgs.attempt} attempts: ${summary}`);
        }
        return [
            createPlanIndexReviewStepIntent(context, indexStep, REPAIR_PLAN_INDEX_AGENT_NAME, reviewArgs.indexName, reviewArgs.attempt, `Repair ${reviewArgs.indexName} (attempt ${reviewArgs.attempt})`),
            createPlannerUpdateStatusIntent(context, indexStep, step, hookSequential, 'completed', `local checkpoint found ${localFindings.errors.length} error(s); skipping critic LLM and requesting repair`),
        ];
    }
    return [
        createPlannerPromptReadyIntent(context, indexStep, hookSequential, args || step.prompt || '', systemPrompt.split('{{toolName}}').join(PLAN_INDEX_CRITIQUE_TOOL_NAME), buildCriticHumanPrompt(context, config, output, localFindings, reviewArgs.attempt), planIndexCritiqueToolSchema, PLAN_INDEX_CRITIQUE_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}](afterPromptStep) task invalid`);
    const reviewArgs = parsePlanIndexReviewArgs(step.prompt);
    const config = getPlanIndexReviewConfig(reviewArgs.indexName);
    const indexStep = resolveIndexStepForReview(context, parentStep, config.sourceAgentName);
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    let output;
    let localFindings;
    try {
        output = config.getCurrentOutput(context);
        localFindings = config.runLocalCheckpoint(context, output);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return failIndexIntents(context, indexStep, step, hookSequential, `critic could not read ${reviewArgs.indexName}: ${message}`);
    }
    let critique;
    let criticFallbackNote;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing critic payload');
        critique = extractPlannerOutput(payload, planIndexCritiqueExtractConfig);
        if (critique.status !== 'ok')
            throw new Error(`critic returned status ${critique.status}`);
    }
    catch (error) {
        // The critic is a quality gate, not a new blocker: when the gate itself fails,
        // fall back to the pre-critic behavior (approve with a warning note in the checkpoint).
        criticFallbackNote = `critic LLM failed, approved by fallback: ${error instanceof Error ? error.message : String(error)}`;
        critique = undefined;
    }
    const healthReport = buildEmptyHealthReport();
    healthReport.attempts = reviewArgs.attempt;
    healthReport.localErrors = localFindings.errors;
    healthReport.localWarnings = localFindings.warnings;
    if (critique) {
        healthReport.criticErrors = critiqueFindingsToHealth(critique.result.errors, 'error');
        healthReport.criticWarnings = critiqueFindingsToHealth(critique.result.warnings, 'warning');
        healthReport.notes.push(...critique.result.notes);
    }
    if (criticFallbackNote)
        healthReport.notes.push(criticFallbackNote);
    const hasErrors = !!critique && (!critique.result.approved || critique.result.errors.length > 0);
    if (!hasErrors) {
        return approveIndexIntents(context, config, indexStep, step, hookSequential, output, healthReport);
    }
    if (reviewArgs.attempt >= MAX_PLAN_INDEX_CRITIC_ATTEMPTS) {
        const summary = critique.result.errors.map(item => `${item.code}: ${item.message}`).join('; ');
        return failIndexIntents(context, indexStep, step, hookSequential, `critic rejected ${reviewArgs.indexName} after ${reviewArgs.attempt} attempts: ${summary}`);
    }
    // Add the repair step BEFORE completing this critic step, so the index step always keeps
    // a non-terminal child and is not auto-completed by the orchestrator.
    return [
        createPlanIndexReviewStepIntent(context, indexStep, REPAIR_PLAN_INDEX_AGENT_NAME, reviewArgs.indexName, reviewArgs.attempt, `Repair ${reviewArgs.indexName} (attempt ${reviewArgs.attempt})`),
        createPlannerUpdateStatusIntent(context, indexStep, step, hookSequential, 'completed', `critic found ${critique.result.errors.length} error(s) on ${reviewArgs.indexName}; requesting repair`, 'input'),
    ];
}
async function approveIndexIntents(context, config, indexStep, criticStep, hookSequential, output, healthReport) {
    // freeze the approved index in the manifest/checkpoint before releasing children.
    await config.onApproved(context, indexStep, output, healthReport);
    const indexParent = findParentStepOfStep(context, indexStep.stepId);
    const intents = [
        createPlannerUpdateStatusIntent(context, indexStep, criticStep, hookSequential, 'completed', `${config.indexName} approved (attempt ${healthReport.attempts}); checkpoint frozen`, 
        // the critique payload is dead after approval (healthReport already frozen in
        // the checkpoint, no further getLatestCritiqueJson read) — clear it fully to keep the task light.
        'input_output'),
        createPlannerUpdateStatusIntent(context, (indexParent && indexParent.type === 'agent' ? indexParent : indexStep), indexStep, hookSequential, 'completed', `${config.indexName} frozen after critic approval`, 'input'),
        // E2-006 (strategic4Clean F1, belt-and-braces): re-send a cleaner-only completion for the
        // index step — same status, NO traceMsg. The index step is often auto-completed by the
        // orchestrator when its last critic/repair child finishes, and in the observed run the
        // cleaner of the intent above was not applied (inputs+tools of the 5 index steps stayed in
        // the task, ~94KB). This extra intent hits the backend "clean & save" fast path
        // (cleaner && step.status === status && !traceMsg), which demonstrably works in production
        // (it is how the blueprint payload is cleared by the finalize step). Idempotent on backends
        // that already cleaned via the intent above.
        createPlannerUpdateStatusIntent(context, (indexParent && indexParent.type === 'agent' ? indexParent : indexStep), indexStep, hookSequential, 'completed', undefined, 'input'),
    ];
    intents.push(...config.createChildrenIntents(context, output));
    return intents;
}
function failIndexIntents(context, indexStep, criticStep, hookSequential, traceMsg) {
    const intents = [
        createPlannerUpdateStatusIntent(context, indexStep, criticStep, hookSequential, 'failed', traceMsg),
    ];
    // Only fail the index step when its parent is resolvable as an agent step. Reaching up to a
    // grandparent whose id no longer resolves (e.g. after a manual restart) makes the backend
    // throw "Parent step not found", which breaks the restart. Skipping is safe: the critic/repair
    // step is already failed, surfacing the reason.
    const indexParent = findParentStepOfStep(context, indexStep.stepId);
    if (indexParent && indexParent.type === 'agent') {
        intents.push(createPlannerUpdateStatusIntent(context, indexParent, indexStep, hookSequential, 'failed', traceMsg));
    }
    return intents;
}
function buildCriticHumanPrompt(context, config, output, localFindings, attempt) {
    return `## Index under review
${config.indexName} (${config.description}), critic attempt ${attempt}.

## Contract focus for this index
${config.contractFocus}

## Current index (result only)
${JSON.stringify(output.result, null, 2)}

## Deterministic local findings (already computed by code)
${JSON.stringify(localFindings, null, 2)}

## Minimal planning context
${JSON.stringify(config.buildReviewContext(context), null, 2)}
`;
}
const systemPrompt = `
<!-- modelType: codepro -->
<!-- x-tool-strict: true -->

You are agentCriticPlanIndex for the collab.codes "newSolution" flow.
Criticize ONLY the single plan index provided. Do not review other indices or artifacts.
Use the same language as the user for messages and notes.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## How to classify findings
- "errors": contract violations, broken references, scope decisions that child definition agents cannot fix later (wrong ownership, missing approved artifact, invented item, wrong actor, wrong executionMode, wrong resolution).
- "warnings": acceptable modeling choices, style issues, or improvements that must NOT block the flow. Example: a page input modeled as an object that contains the identifier internally is acceptable when its contract is clear.
- approved must be true only when errors is empty.
- Do not invent new scope; judge the index against the provided contract focus and minimal context only.
- Repeat the deterministic local findings only if you confirm them; never contradict deterministic reference checks.
- Keep findings short, each with a stable code, a clear message, and a path inside the index when possible.
`;
