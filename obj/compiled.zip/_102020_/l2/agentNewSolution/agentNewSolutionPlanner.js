/// <mls fileReference="_102020_/l2/agentNewSolution/agentNewSolutionPlanner.ts" enhancement="_102027_/l2/enhancementAgent"/>
export function createAgent() {
    return {
        agentName: 'agentNewSolutionPlanner',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Planner group wrapper for new solution planning',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !parentStep || !step)
        throw new Error('[agentNewSolutionPlanner](beforePromptStep) invalid params');
    if (!context.task)
        throw new Error('[agentNewSolutionPlanner](beforePromptStep) task invalid');
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status: 'completed',
    };
    return [updateStatus];
}
