/// <mls fileReference="_102020_/l2/agentNewSolution/agentSolutionBlueprint.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, createPlannerPromptReadyIntent, createPlannerVariableToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, getPlannerOutput, getPlanningContextSnapshot, hasAcceptedNowArtifact, readPlatformSkill, withPlatformSkill, hydrateNewSolutionOutputs, coerceOntologyEnumArrays, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { MODULE_NAME_FINAL_PLAN_ID, TEMP_MODULE_FOLDER, getApprovedModuleName, getInitialModuleName, migrateTempModuleFolder, reserveAvailableModuleName, saveNewSolutionAgentTracePayload, } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
import { solutionBlueprintResultSchema } from '/_102020_/l2/agentNewSolution/agentSolutionPlanSchemas.js';
export function createAgent() {
    return {
        agentName: 'agentSolutionBlueprint',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Create a detailed blueprint for the new solution',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const SOLUTION_BLUEPRINT_TOOL_NAME = 'submitSolutionBlueprint';
export const SOLUTION_BLUEPRINT_STEP_ID = '06-solution-blueprint';
const SOLUTION_BLUEPRINT_ALIASES = [SOLUTION_BLUEPRINT_STEP_ID, 'plan-solution-blueprint'];
const solutionBlueprintToolSchema = createPlannerVariableToolSchema(SOLUTION_BLUEPRINT_TOOL_NAME, 'Submit the detailed solution blueprint for the newSolution planner.', solutionBlueprintResultSchema);
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    await hydrateNewSolutionOutputs(context); // F-06: outputs/ cache for cleaned payloads
    if (!agent || !step)
        throw new Error('[agentSolutionBlueprint](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const snapshot = getPlanningContextSnapshot(context);
    const platformSkill = await readPlatformSkill();
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, withPlatformSkill(systemPrompt.split('{{toolName}}').join(SOLUTION_BLUEPRINT_TOOL_NAME), platformSkill), buildHumanPrompt(args, snapshot), solutionBlueprintToolSchema, SOLUTION_BLUEPRINT_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    await hydrateNewSolutionOutputs(context); // F-06: outputs/ cache for cleaned payloads
    let status = 'completed';
    let traceMsg;
    let output;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractSolutionBlueprintOutput(payload);
        validateSolutionBlueprintOutput(output, context);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentSolutionBlueprint returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentSolutionBlueprint returned status needs_input; keeping validated draft for downstream planning.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    const canonicalSaved = await saveNewSolutionAgentTracePayload(context, agent.agentName, step); // F-06
    const intents = [];
    // Temp-folder naming (2026-06-12): THIS is where the module name becomes final. The LLM has
    // interpreted the user's free-text clarification answer (any language) and emitted
    // module.moduleName; confirm it (collision-suffix against existing folders), migrate every
    // _traceTemp file to the confirmed folder and record the name for getApprovedModuleName.
    // Idempotency guard: a blueprint re-run must NOT reserve a second folder (suffix drift) when
    // the name was already confirmed by a previous completion.
    const alreadyConfirmed = getApprovedModuleName(context);
    if (status === 'completed' && output && output.status === 'ok' && (!alreadyConfirmed || alreadyConfirmed === TEMP_MODULE_FOLDER)) {
        try {
            const requested = output.result.module.moduleName;
            const finalName = reserveAvailableModuleName(requested, getInitialModuleName(context));
            await migrateTempModuleFolder(finalName);
            intents.push(createModuleNameFinalResultIntent(context, parentStep, finalName));
            console.log(`[${agent.agentName}] module name confirmed: ${finalName}`);
        }
        catch (error) {
            // Non-fatal: writes keep going to _traceTemp; the name can be confirmed manually later.
            console.warn(`[${agent.agentName}] module name confirmation failed (writes stay in ${TEMP_MODULE_FOLDER}):`, error);
        }
    }
    intents.push(createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? (canonicalSaved ? 'input_output' : 'input') : undefined));
    return intents;
}
/** Records the LLM-confirmed module name as a result step (planId 'module-name-final') — the
 * single source read by getApprovedModuleName from this point on. Exported so the finalize step
 * can confirm the name as a FALLBACK when this hook failed after the LLM succeeded. */
export function createModuleNameFinalResultIntent(context, parentStep, moduleName) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step: {
            type: 'result',
            stepId: 0,
            interaction: null,
            stepTitle: `Module name: ${moduleName}`,
            status: 'completed',
            nextSteps: [],
            result: JSON.stringify({ moduleName }),
            planning: {
                planId: MODULE_NAME_FINAL_PLAN_ID,
                dependsOn: ['plan-solution-blueprint'],
                executionMode: 'manual_later',
                executionHost: 'client',
            },
        },
    };
}
export function getSolutionBlueprintOutput(context) {
    return getPlannerOutput(context, 'agentSolutionBlueprint', solutionBlueprintConfig, output => validateSolutionBlueprintOutput(output, context));
}
function extractSolutionBlueprintOutput(payload) {
    return extractPlannerOutput(payload, solutionBlueprintConfig);
}
const solutionBlueprintConfig = {
    toolName: SOLUTION_BLUEPRINT_TOOL_NAME,
    stepId: SOLUTION_BLUEPRINT_STEP_ID,
    preNormalizeResult: coerceOntologyEnumArrays,
    stepIdAliases: SOLUTION_BLUEPRINT_ALIASES,
    normalizeResult: normalizeSolutionBlueprintResult,
};
function normalizeSolutionBlueprintResult(value) {
    const result = assertRecord(value, 'result');
    const ontology = assertRecord(result.ontology, 'result.ontology');
    const artifactPlan = assertRecord(result.artifactPlan, 'result.artifactPlan');
    return {
        module: assertRecord(result.module, 'result.module'),
        actors: assertArray(result.actors, 'result.actors'),
        capabilities: assertArray(result.capabilities, 'result.capabilities'),
        ontology: {
            entities: assertRecord(ontology.entities, 'result.ontology.entities'),
        },
        rules: assertArray(result.rules, 'result.rules'),
        relationships: assertArray(result.relationships, 'result.relationships'),
        userActions: assertArray(result.userActions, 'result.userActions'),
        artifactPlan: {
            pages: assertArray(artifactPlan.pages, 'result.artifactPlan.pages'),
            workflows: assertArray(artifactPlan.workflows, 'result.artifactPlan.workflows'),
            plugins: assertArray(artifactPlan.plugins, 'result.artifactPlan.plugins'),
            agents: assertArray(artifactPlan.agents, 'result.artifactPlan.agents'),
            horizontalModules: assertArray(artifactPlan.horizontalModules, 'result.artifactPlan.horizontalModules'),
            mdm: assertArray(artifactPlan.mdm, 'result.artifactPlan.mdm'),
            metricTables: assertArray(artifactPlan.metricTables, 'result.artifactPlan.metricTables'),
            metricDashboards: assertArray(artifactPlan.metricDashboards, 'result.artifactPlan.metricDashboards'),
            usecaseEntities: assertArray(artifactPlan.usecaseEntities, 'result.artifactPlan.usecaseEntities'),
        },
        coverage: assertArray(result.coverage, 'result.coverage'),
    };
}
function validateSolutionBlueprintOutput(output, context) {
    if (output.status === 'ok' && output.result.artifactPlan.mdm.length === 0)
        throw new Error('solution blueprint must include MDM artifact plan');
    // T-001 moved to the per-entity definition fan-out (F-02): the blueprint is a slim MAP and no
    // longer carries the canonical fields. assertOntologyEntityFields is enforced there.
    const snapshot = getPlanningContextSnapshot(context);
    if (output.status === 'ok' && snapshot.initialMetricsRequested) {
        if (output.result.artifactPlan.metricTables.length === 0)
            throw new Error('initial metrics requested, but blueprint has no metricTables');
        if (output.result.artifactPlan.metricDashboards.length === 0)
            throw new Error('initial metrics requested, but blueprint has no metricDashboards');
    }
    if (output.status === 'ok' && hasAcceptedNowArtifact(snapshot.implementationDecisions, 'usecaseEntity') && output.result.artifactPlan.usecaseEntities.length === 0) {
        throw new Error('accepted usecaseEntity planning, but blueprint has no usecaseEntities');
    }
}
function buildHumanPrompt(args, snapshot) {
    return `## Planned step args
${args}

## Initial user prompt
${snapshot.initialPlan.userPrompt}

## Initial plan
${JSON.stringify(snapshot.initialPlan, null, 2)}

## Clarification answer
${JSON.stringify(snapshot.clarificationAnswer, null, 2)}

## Discovered scope
${JSON.stringify(snapshot.discoveredScope, null, 2)}

## Implementation recommendations
${JSON.stringify(snapshot.recommendations, null, 2)}

## Accepted implementation decisions
${JSON.stringify(snapshot.implementationDecisions, null, 2)}

## Initial metrics/dashboard requested
${snapshot.initialMetricsRequested}
`;
}
const systemPrompt = `
<!-- modelType: codeinstruct -->
<!-- x-tool-strict: true -->

You are agentSolutionBlueprint for the collab.codes "newSolution" flow.
Create a detailed solution blueprint from the prompt, clarification, discovered scope, recommendations, and approved implementation decisions.
Use the same language as the user for labels, descriptions, questions, and trace.
Use English camelCase identifiers for ids and PascalCase for entity names.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Result shape
In result, return:
- module with moduleName, purpose, businessDomain, languages, and visualStyle.
- actors.
- capabilities.
- module.moduleName: the user's clarification answer is FREE TEXT in their language and may mix affirmation words with the name (e.g. "sim cafeShow" means "yes, cafeShow"). Interpret it: extract the intended name; when the answer only confirms, keep the suggested/tentative name. The name must be a single camelCase identifier — never include affirmation/filler words.
- ontology.entities as an object map keyed by PascalCase entity id. The blueprint is a MAP, not the detailed model: each value includes title, description and ownership (plus entityId/kind/statusEnum/lifecycleStates when already known; statusEnum and lifecycleStates, when present, are ARRAYS of strings — never a single string). Do NOT detail fields here — the complete field list (with per-field enums) is produced later by the per-entity definition stage. Focus the effort on getting the entity LIST, ownership and relationships right.
- centralized rules.
- relationships.
- userActions.
- artifactPlan with pages, workflows, plugins, agents, horizontalModules, mdm, metricTables, metricDashboards, and usecaseEntities.
- coverage.

## Rules
- Do not use hard-coded entities, actions, pages, or workflows from a sample domain.
- Infer the core commitment of the requested domain (e.g. booking, order, request, contract, subscription, approval, service request, or similar lifecycle/relationship).
- Every core commitment must reference the selected subject, resource, service, product, or person that makes the commitment meaningful. Derive names from the prompt and ontology.
- Include explicit user actions for all required selections, confirmations, and lifecycle changes implied by the domain.
- Include MDM domains for stable master data such as customers, accounts, products, assets, suppliers, staff, locations, or reusable records.
- Every entity owned by the solution (ownership moduleOwned or mdmOwned) must declare its ownership explicitly. Field lists are NOT required here (detailed later per entity); when you already know a few key fields you MAY include them, but never let field detailing reduce the breadth of the entity map.
- When the request MAINTAINS or EXTENDS an existing module, entities already persisted by that module are ownership "existingModuleOwned" — never moduleOwned (would duplicate the table) and never mdmOwned (reserved for shared master data).
- Include operational metric tables and an admin dashboard when initial metrics/dashboard was accepted.
- Include layer_3 usecase entities when the solution has BFF commands, writes, lifecycle changes, or metric updates.
- Backend layer rules must be respected: BFF is layer_2, use cases are layer_3, real tables are layer_1.
- Do not make payments, scheduling, adoption, or unrelated features part of the MVP when the prompt or decisions excluded them.
- Use rules with stable ruleId values. Do not leave rule text loose in pages.
- Use status "needs_input" only when a safe blueprint cannot be drafted without another client decision.
`;
