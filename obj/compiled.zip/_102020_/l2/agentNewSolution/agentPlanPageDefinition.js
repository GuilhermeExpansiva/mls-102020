/// <mls fileReference="_102020_/l2/agentNewSolution/agentPlanPageDefinition.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { assertArray, assertRecord, assertString, createDynamicAgentStepIntent, createPlannerPromptReadyIntent, createPlannerVariableToolSchema, createPlannerUpdateStatusIntent, extractPlannerOutput, findStepByPlanId, getPlannerOutputs, } from '/_102020_/l2/agentNewSolution/agentPlanningShared.js';
import { getFinalizeSolutionPlanOutput } from '/_102020_/l2/agentNewSolution/agentFinalizeSolutionPlan.js';
import { saveNewSolutionAgentTracePayload } from '/_102020_/l2/agentNewSolution/agentNewSolutionArtifacts.js';
import { getPlanAgentsOutput } from '/_102020_/l2/agentNewSolution/agentPlanAgents.js';
import { getPlanHorizontalsOutput } from '/_102020_/l2/agentNewSolution/agentPlanHorizontals.js';
import { getPlanMDMOutput } from '/_102020_/l2/agentNewSolution/agentPlanMDM.js';
import { getPlanMetricTableDefinitionOutputs } from '/_102020_/l2/agentNewSolution/agentPlanMetricTableDefinition.js';
import { getPlanMetricsIndexOutput } from '/_102020_/l2/agentNewSolution/agentPlanMetricsIndex.js';
import { getPlanPageIndexOutput } from '/_102020_/l2/agentNewSolution/agentPlanPageIndex.js';
import { getPlanPersistenceIndexOutput } from '/_102020_/l2/agentNewSolution/agentPlanPersistenceIndex.js';
import { getPlanPluginsOutput } from '/_102020_/l2/agentNewSolution/agentPlanPlugins.js';
import { getPlanTableDefinitionOutputs } from '/_102020_/l2/agentNewSolution/agentPlanTableDefinition.js';
import { getPlanUsecaseEntitiesOutput } from '/_102020_/l2/agentNewSolution/agentPlanUsecaseEntities.js';
import { getPlanWorkflowDefinitionOutputs } from '/_102020_/l2/agentNewSolution/agentPlanWorkflowDefinition.js';
import { getPlanWorkflowIndexOutput } from '/_102020_/l2/agentNewSolution/agentPlanWorkflowIndex.js';
export function createAgent() {
    return {
        agentName: 'agentPlanPageDefinition',
        agentProject: 102020,
        agentFolder: 'agentNewSolution',
        agentDescription: 'Plan one page definition and its BFF commands from the page index',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
export const PLAN_PAGE_DEFINITION_TOOL_NAME = 'submitPageDefinitionPlan';
export const PLAN_PAGE_DEFINITION_STEP_ID = 'plan-page-definition';
const PLAN_PAGE_DEFINITION_ALIASES = [PLAN_PAGE_DEFINITION_STEP_ID, 'plan-page-definition'];
const navigationRefSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['direction', 'pageId', 'trigger'],
    properties: {
        direction: { type: 'string' },
        pageId: { type: 'string' },
        trigger: { type: 'string' },
        description: { type: 'string' },
    },
};
const pageInputSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['name', 'type', 'sources'],
    properties: {
        name: { type: 'string' },
        type: { type: 'string' },
        required: { type: 'boolean' },
        sources: { type: 'array', items: { type: 'string' } },
        description: { type: 'string' },
        entityRef: { type: 'string' },
        fieldRef: { type: 'string' },
    },
};
const organismSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['organismName', 'purpose', 'userActions', 'requiredEntities', 'readsFields', 'writesFields', 'rulesApplied'],
    properties: {
        organismName: { type: 'string' },
        purpose: { type: 'string' },
        userActions: { type: 'array', items: { type: 'string' } },
        requiredEntities: { type: 'array', items: { type: 'string' } },
        readsFields: { type: 'array', items: { type: 'string' } },
        writesFields: { type: 'array', items: { type: 'string' } },
        rulesApplied: { type: 'array', items: { type: 'string' } },
    },
};
const sectionSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['sectionName', 'mode', 'organisms'],
    properties: {
        sectionName: { type: 'string' },
        mode: { type: 'string' },
        organisms: { type: 'array', items: organismSchema },
    },
};
const bffCommandSchema = {
    type: 'object',
    additionalProperties: false,
    required: [
        'commandName', 'purpose', 'kind', 'input', 'output',
        'readsEntities', 'writesEntities', 'readsTables', 'writesTables',
        'usecaseRefs', 'layerContract', 'rulesApplied'
    ],
    properties: {
        commandName: { type: 'string' },
        purpose: { type: 'string' },
        kind: { enum: ['query', 'command', 'mutation'] },
        input: { type: 'object', additionalProperties: true },
        output: { type: 'object', additionalProperties: true },
        readsEntities: { type: 'array', items: { type: 'string' } },
        writesEntities: { type: 'array', items: { type: 'string' } },
        readsTables: { type: 'array', items: { type: 'string' } },
        writesTables: { type: 'array', items: { type: 'string' } },
        usecaseRefs: { type: 'array', items: { type: 'string' } },
        layerContract: {
            type: 'object',
            additionalProperties: false,
            required: ['controllerLayer', 'mustCallLayer', 'directTableAccessForbidden'],
            properties: {
                controllerLayer: { type: 'string' },
                mustCallLayer: { type: 'string' },
                directTableAccessForbidden: { type: 'boolean' },
            },
        },
        rulesApplied: { type: 'array', items: { type: 'string' } },
    },
};
const planPageDefinitionToolSchema = createPlannerVariableToolSchema(PLAN_PAGE_DEFINITION_TOOL_NAME, 'Submit one page definition plan (pageDefinition + bffCommands) for the current page selector.', {
    type: 'object',
    additionalProperties: false,
    required: ['pageDefinition', 'bffCommands'],
    properties: {
        pageDefinition: {
            type: 'object',
            additionalProperties: false,
            required: [
                'pageId', 'pageName', 'actor', 'purpose', 'capabilities',
                'flowRefs', 'pluginRefs', 'mdmRefs', 'pageInputs', 'navigationRefs', 'sections'
            ],
            properties: {
                pageId: { type: 'string' },
                pageName: { type: 'string' },
                actor: { type: 'string' },
                purpose: { type: 'string' },
                capabilities: { type: 'array', items: { type: 'string' } },
                flowRefs: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['experienceFlows', 'entityLifecycles', 'taskWorkflows', 'automations'],
                    properties: {
                        experienceFlows: { type: 'array', items: { type: 'string' } },
                        entityLifecycles: { type: 'array', items: { type: 'string' } },
                        taskWorkflows: { type: 'array', items: { type: 'string' } },
                        automations: { type: 'array', items: { type: 'string' } },
                    },
                },
                pluginRefs: { type: 'array', items: { type: 'string' } },
                mdmRefs: { type: 'array', items: { type: 'string' } },
                pageInputs: { type: 'array', items: pageInputSchema },
                navigationRefs: { type: 'array', items: navigationRefSchema },
                sections: { type: 'array', items: sectionSchema },
            },
        },
        bffCommands: { type: 'array', items: bffCommandSchema },
    },
});
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!agent || !step)
        throw new Error('[agentPlanPageDefinition](beforePromptStep) invalid params');
    if (!args)
        throw new Error(`[${agent.agentName}](beforePromptStep) page selector args invalid`);
    if (!context.task)
        throw new Error(`[${agent.agentName}](beforePromptStep) task invalid`);
    const finalPlan = getFinalizeSolutionPlanOutput(context);
    const mdm = getPlanMDMOutput(context);
    const horizontals = getPlanHorizontalsOutput(context);
    const plugins = getPlanPluginsOutput(context);
    const persistenceIndex = getPlanPersistenceIndexOutput(context);
    const tableDefinitions = getPlanTableDefinitionOutputs(context);
    const metricsIndex = getPlanMetricsIndexOutput(context);
    const metricTableDefinitions = getPlanMetricTableDefinitionOutputs(context);
    const usecasePlan = getPlanUsecaseEntitiesOutput(context);
    const workflowIndex = getPlanWorkflowIndexOutput(context);
    const workflowDefinitions = getPlanWorkflowDefinitionOutputs(context);
    const agentsPlan = getPlanAgentsOutput(context);
    const pageIndex = getPlanPageIndexOutput(context);
    const pageIndexItem = pageIndex.result.pages.find(p => p.pageId === args);
    if (!pageIndexItem)
        throw new Error(`[${agent.agentName}](beforePromptStep) page selector not found in index: ${args}`);
    return [
        createPlannerPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt.split('{{toolName}}').join(PLAN_PAGE_DEFINITION_TOOL_NAME), buildHumanPrompt(args, pageIndexItem, pageIndex, finalPlan, mdm, horizontals, plugins, persistenceIndex, tableDefinitions, metricsIndex, metricTableDefinitions, usecasePlan, workflowIndex, workflowDefinitions, agentsPlan), planPageDefinitionToolSchema, PLAN_PAGE_DEFINITION_TOOL_NAME),
    ];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let traceMsg;
    let output;
    const pageSelector = step.prompt || '';
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        output = extractPlanPageDefinitionOutput(payload);
        validatePlanPageDefinitionOutput(output, pageSelector);
        if (output.status === 'failed') {
            status = 'failed';
            traceMsg = 'agentPlanPageDefinition returned status failed';
        }
        else if (output.status === 'needs_input') {
            traceMsg = 'agentPlanPageDefinition returned status needs_input; keeping page definition draft.';
        }
    }
    catch (error) {
        status = 'failed';
        traceMsg = error instanceof Error ? error.message : String(error);
        console.error(`[${agent.agentName}](afterPromptStep) ${traceMsg}`);
    }
    await saveNewSolutionAgentTracePayload(context, agent.agentName, step);
    const updateIntent = createPlannerUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, status === 'completed' ? 'input' : undefined);
    const nextIntents = status === 'completed' && output ? createNextPageDefinitionIntent(context, step, output) : [];
    if (nextIntents.some(intent => intent.type === 'add-step'))
        return [...nextIntents, updateIntent];
    return [updateIntent, ...nextIntents];
}
export function getPlanPageDefinitionOutputs(context) {
    return getPlannerOutputs(context, 'agentPlanPageDefinition', planPageDefinitionConfig, output => validatePlanPageDefinitionOutput(output, output.result.pageDefinition.pageId));
}
function extractPlanPageDefinitionOutput(payload) {
    return extractPlannerOutput(payload, planPageDefinitionConfig);
}
const planPageDefinitionConfig = {
    toolName: PLAN_PAGE_DEFINITION_TOOL_NAME,
    stepId: PLAN_PAGE_DEFINITION_STEP_ID,
    stepIdAliases: PLAN_PAGE_DEFINITION_ALIASES,
    normalizeResult: normalizePlanPageDefinitionResult,
};
function normalizePlanPageDefinitionResult(value) {
    const result = assertRecord(value, 'result');
    const pageDefinition = assertRecord(result.pageDefinition, 'result.pageDefinition');
    const bffCommands = assertArray(result.bffCommands || [], 'result.bffCommands');
    return {
        pageDefinition: normalizePageDefinition(pageDefinition, 'result.pageDefinition'),
        bffCommands: bffCommands.map((cmd, i) => normalizeBffCommand(cmd, `result.bffCommands[${i}]`)),
    };
}
function normalizePageDefinition(value, path) {
    const p = assertRecord(value, path);
    const flowRefs = assertRecord(p.flowRefs, `${path}.flowRefs`);
    return {
        pageId: assertString(p.pageId, `${path}.pageId`),
        pageName: assertString(p.pageName, `${path}.pageName`),
        actor: assertString(p.actor, `${path}.actor`),
        purpose: assertString(p.purpose, `${path}.purpose`),
        capabilities: normalizeStringArray(p.capabilities, `${path}.capabilities`),
        flowRefs: {
            experienceFlows: normalizeStringArray(flowRefs.experienceFlows, `${path}.flowRefs.experienceFlows`),
            entityLifecycles: normalizeStringArray(flowRefs.entityLifecycles, `${path}.flowRefs.entityLifecycles`),
            taskWorkflows: normalizeStringArray(flowRefs.taskWorkflows, `${path}.flowRefs.taskWorkflows`),
            automations: normalizeStringArray(flowRefs.automations, `${path}.flowRefs.automations`),
        },
        pluginRefs: normalizeStringArray(p.pluginRefs, `${path}.pluginRefs`),
        mdmRefs: normalizeStringArray(p.mdmRefs, `${path}.mdmRefs`),
        pageInputs: assertArray(p.pageInputs || [], `${path}.pageInputs`).map((inp, i) => normalizePageInput(inp, `${path}.pageInputs[${i}]`)),
        navigationRefs: assertArray(p.navigationRefs || [], `${path}.navigationRefs`).map((nr, i) => normalizeNavigationRef(nr, `${path}.navigationRefs[${i}]`)),
        sections: assertArray(p.sections || [], `${path}.sections`).map((sec, i) => normalizeSection(sec, `${path}.sections[${i}]`)),
    };
}
function normalizePageInput(value, path) {
    const inp = assertRecord(value, path);
    return {
        name: assertString(inp.name, `${path}.name`),
        type: assertString(inp.type, `${path}.type`),
        required: typeof inp.required === 'boolean' ? inp.required : undefined,
        sources: normalizeStringArray(inp.sources, `${path}.sources`),
        description: optionalStringValue(inp.description),
        entityRef: optionalStringValue(inp.entityRef),
        fieldRef: optionalStringValue(inp.fieldRef),
    };
}
function normalizeNavigationRef(value, path) {
    const nr = assertRecord(value, path);
    return {
        direction: assertString(nr.direction, `${path}.direction`),
        pageId: assertString(nr.pageId, `${path}.pageId`),
        trigger: assertString(nr.trigger, `${path}.trigger`),
        description: optionalStringValue(nr.description),
    };
}
function normalizeSection(value, path) {
    const sec = assertRecord(value, path);
    return {
        sectionName: assertString(sec.sectionName, `${path}.sectionName`),
        mode: assertString(sec.mode, `${path}.mode`),
        organisms: assertArray(sec.organisms || [], `${path}.organisms`).map((org, i) => normalizeOrganism(org, `${path}.organisms[${i}]`)),
    };
}
function normalizeOrganism(value, path) {
    const org = assertRecord(value, path);
    return {
        organismName: assertString(org.organismName, `${path}.organismName`),
        purpose: assertString(org.purpose, `${path}.purpose`),
        userActions: normalizeStringArray(org.userActions, `${path}.userActions`),
        requiredEntities: normalizeStringArray(org.requiredEntities, `${path}.requiredEntities`),
        readsFields: normalizeStringArray(org.readsFields, `${path}.readsFields`),
        writesFields: normalizeStringArray(org.writesFields, `${path}.writesFields`),
        rulesApplied: normalizeStringArray(org.rulesApplied, `${path}.rulesApplied`),
    };
}
function normalizeBffCommand(value, path) {
    const cmd = assertRecord(value, path);
    const layerContract = assertRecord(cmd.layerContract, `${path}.layerContract`);
    return {
        commandName: assertString(cmd.commandName, `${path}.commandName`),
        purpose: assertString(cmd.purpose, `${path}.purpose`),
        kind: assertString(cmd.kind, `${path}.kind`),
        input: cmd.input || {},
        output: cmd.output || {},
        readsEntities: normalizeStringArray(cmd.readsEntities, `${path}.readsEntities`),
        writesEntities: normalizeStringArray(cmd.writesEntities, `${path}.writesEntities`),
        readsTables: normalizeStringArray(cmd.readsTables, `${path}.readsTables`),
        writesTables: normalizeStringArray(cmd.writesTables, `${path}.writesTables`),
        usecaseRefs: normalizeStringArray(cmd.usecaseRefs, `${path}.usecaseRefs`),
        layerContract: {
            controllerLayer: assertString(layerContract.controllerLayer, `${path}.layerContract.controllerLayer`),
            mustCallLayer: assertString(layerContract.mustCallLayer, `${path}.layerContract.mustCallLayer`),
            directTableAccessForbidden: !!layerContract.directTableAccessForbidden,
        },
        rulesApplied: normalizeStringArray(cmd.rulesApplied, `${path}.rulesApplied`),
    };
}
function normalizeStringArray(value, path) {
    return assertArray(value || [], path).map((item, index) => assertString(item, `${path}[${index}]`));
}
function optionalStringValue(value) {
    if (value === undefined || value === null || value === '')
        return undefined;
    if (typeof value === 'string')
        return value.trim() || undefined;
    return undefined;
}
function validatePlanPageDefinitionOutput(output, pageSelector) {
    const page = output.result.pageDefinition;
    if (!page.pageId || page.pageId !== pageSelector) {
        throw new Error(`pageDefinition.pageId must match selector ${pageSelector}`);
    }
    if (output.status === 'needs_input' && output.questions.length === 0) {
        throw new Error('needs_input page definition must include questions');
    }
    // Basic structural checks per prompt guidance
    if (output.status === 'ok') {
        if (!Array.isArray(page.pageInputs))
            throw new Error('pageDefinition.pageInputs must be an array (even if empty)');
        if (!Array.isArray(page.navigationRefs))
            throw new Error('pageDefinition.navigationRefs must be an array (even if empty)');
        if (!Array.isArray(page.sections))
            throw new Error('pageDefinition.sections must be present');
    }
}
function createNextPageDefinitionIntent(context, currentStep, currentOutput) {
    const pageIndex = getPlanPageIndexOutput(context);
    const covered = new Set(getPlanPageDefinitionOutputs(context).map(output => output.result.pageDefinition.pageId));
    covered.add(currentOutput.result.pageDefinition.pageId);
    const nextPage = pageIndex.result.pages.find(p => !covered.has(p.pageId));
    const placeholder = findStepByPlanId(context, 'plan-page-definition');
    if (!placeholder || placeholder.type !== 'agent')
        return [];
    if (nextPage) {
        const insertParent = placeholder.status === 'completed' ? currentStep : placeholder;
        return [
            createDynamicAgentStepIntent(context, placeholder, 'agentPlanPageDefinition', `plan-page-definition:${nextPage.pageId}`, `Plan page ${nextPage.pageId}`, nextPage.pageId, insertParent),
        ];
    }
    if (placeholder.status === 'completed')
        return [];
    return [createPlannerUpdateStatusIntent(context, placeholder, placeholder, 0, 'completed', 'All dynamic page definitions completed.')];
}
function buildHumanPrompt(args, pageIndexItem, pageIndex, finalPlan, mdm, horizontals, plugins, persistenceIndex, tableDefinitions, metricsIndex, metricTableDefinitions, usecasePlan, workflowIndex, workflowDefinitions, agentsPlan) {
    return `## Current page selector
${args}

## Page index item (selected)
${JSON.stringify(pageIndexItem, null, 2)}

## Full page index (for navigation and cross-refs)
${JSON.stringify(pageIndex, null, 2)}

## Final solution plan
${JSON.stringify(finalPlan, null, 2)}

## MDM plan
${JSON.stringify(mdm, null, 2)}

## Horizontals plan
${JSON.stringify(horizontals, null, 2)}

## Plugin plan
${JSON.stringify(plugins, null, 2)}

## Persistence index
${JSON.stringify(persistenceIndex, null, 2)}

## Table definitions
${JSON.stringify(tableDefinitions, null, 2)}

## Metrics index
${JSON.stringify(metricsIndex, null, 2)}

## Metric table definitions
${JSON.stringify(metricTableDefinitions, null, 2)}

## Usecase plan
${JSON.stringify(usecasePlan, null, 2)}

## Workflow index
${JSON.stringify(workflowIndex, null, 2)}

## Workflow definitions
${JSON.stringify(workflowDefinitions, null, 2)}

## Agents plan
${JSON.stringify(agentsPlan, null, 2)}
`;
}
const systemPrompt = `
<!-- modelType: codeinstruct -->

You are agentPlanPageDefinition for the collab.codes "newSolution" flow.
Plan exactly one page definition and its supporting BFF commands for the current page selector.
Use the same language as the user for page names, purposes, descriptions, questions, and trace.
Use English camelCase identifiers for pageId and commandName.

## Tool mode
Call the "{{toolName}}" tool with only these top-level arguments: status, result, questions, and trace. Put questions and trace beside result, never inside result. Do not include type, runId, stepId, schemaVersion, toolName, or arguments; the harness fills those fields.
Do not return prose.

## Rules
- Generate one page only: the page whose pageId equals the current selector (from page index item).
- Read the matching PageIndexItem for actor, purpose, capabilities, flowRefs, hints, and bffCommandHints.
- Derive sections/organisms from capabilities, primary user actions, and required selections for commitment pages.
- Every organism that needs backend data must have at least one corresponding BFF command.
- BFF commands must declare kind (query/command/mutation), explicit input/output shapes, readsEntities/writesEntities, readsTables/writesTables for module-owned tables, and usecaseRefs.
- layerContract must be { controllerLayer: "layer_2_controllers", mustCallLayer: "layer_3_usecases", directTableAccessForbidden: true }.
- Do not put MDM/horizontal/plugin-owned tables in readsTables/writesTables; use mdmRefs/pluginRefs and entity refs instead.
- Metric dashboard pages must use the actor declared for metrics in the final plan (commonly an "admin" or back-office actor) and must read metric data only via usecaseRefs.
- pageInputs describe the page boundary contract (route params, query, session, prior step result, etc.). Use empty array when the page can open standalone.
- For detail/status/edit/confirmation pages, declare required external identifiers (the id of the main subject or commitment record from the ontology) in pageInputs with appropriate sources (routeParam, previousStepResult, ...). Never use names from any sample domain.
- navigationRefs are lightweight references only (direction, pageId, trigger, optional description). Never include inputMapping.
- Commitment/confirmation pages (booking, order, request, subscription, contract, or the domain-equivalent commitment action) must include selection organisms before the confirm action; selection organisms must read the selected entity fields and the confirm command must write the relationship to the commitment entity. All names must come from the final plan and ontology.
- Use rule ids from catalogs (e.g. RULE_*) in rulesApplied; never loose rule text.
- flowRefs must correctly categorize references into experienceFlows / entityLifecycles / taskWorkflows / automations and match existing workflow ids.
- Do not generate frontend code, materialization, or .defs implementation details.
- defs are produced later; focus on the conceptual page + BFF contract.
- If information is insufficient for a firm plan, return status "needs_input" with questions.
`;
