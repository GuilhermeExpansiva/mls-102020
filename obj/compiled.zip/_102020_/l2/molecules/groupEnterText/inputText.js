var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102020_/l2/molecules/groupEnterText/inputText.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// INPUT TEXT MOLECULE
// =============================================================================
// Skill Group: enter + text
// This molecule is presentation-only. No business logic.
// - No Shadow DOM
// - Receives data via properties
// - Emits interaction events
// =============================================================================
import { html, nothing, unsafeHTML, ifDefined } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_100554_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    requiredMark: '*',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        requiredMark: '*',
        loading: 'Carregando...',
    },
};
/// **collab_i18n_end**
let InputTextMolecule = class InputTextMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS (Contract: enter + text)
        // =========================================================================
        this.slotTags = ['Label', 'Prefix', 'Suffix', 'Helper', 'Error'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = '';
        this.name = '';
        this.type = 'text';
        this.placeholder = '';
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        this.error = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.uid = `it-${Math.random().toString(16).slice(2)}`;
    }
    // =========================================================================
    // DERIVED
    // =========================================================================
    get isErrored() {
        return Boolean(this.error) || this.hasSlot('Error');
    }
    get errorMessage() {
        const slotMsg = this.getSlotContent('Error');
        return slotMsg;
    }
    get helperMessage() {
        return this.getSlotContent('Helper');
    }
    get describedBy() {
        const ids = [];
        // Priority: error > helper
        if (this.isErrored) {
            ids.push(`input-error-${this.uid}`);
        }
        else if (this.hasSlot('Helper')) {
            ids.push(`input-helper-${this.uid}`);
        }
        return ids.length ? ids.join(' ') : undefined;
    }
    get labelId() {
        return this.hasSlot('Label') ? `input-label-${this.uid}` : undefined;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    dispatchInputEvent(nextValue) {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: nextValue },
        }));
    }
    dispatchChangeEvent(nextValue) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: nextValue },
        }));
    }
    handleInput(e) {
        if (this.disabled || this.readonly)
            return;
        const el = e.target;
        const nextValue = el.value;
        // Controlled-ish: update our value immediately so UI stays in sync.
        this.value = nextValue;
        this.dispatchInputEvent(nextValue);
    }
    handleChange(e) {
        if (this.disabled || this.readonly)
            return;
        const el = e.target;
        const nextValue = el.value;
        this.value = nextValue;
        this.dispatchChangeEvent(nextValue);
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleBlur() {
        if (this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        if (e.key === 'Enter') {
            // For readonly, we still allow enter event (focus interaction) but do not change value.
            this.dispatchEvent(new CustomEvent('enter', {
                bubbles: true,
                composed: true,
                detail: { value: this.value ?? '' },
            }));
        }
    }
    // =========================================================================
    // RENDER HELPERS
    // =========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled ? 'opacity-60' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getInputWrapClasses() {
        const base = [
            'flex items-stretch w-full rounded-md border transition',
            'bg-white',
        ];
        const state = this.isErrored
            ? ['border-rose-500', 'focus-within:ring-2 focus-within:ring-rose-500/40']
            : ['border-slate-300', 'focus-within:ring-2 focus-within:ring-sky-500/40', 'hover:border-slate-400'];
        const disabled = this.disabled
            ? ['bg-slate-100', 'border-slate-200', 'cursor-not-allowed']
            : ['cursor-text'];
        const ro = this.readonly && !this.disabled
            ? ['bg-slate-50']
            : [];
        return [...base, ...state, ...disabled, ...ro]
            .filter(Boolean)
            .join(' ');
    }
    getInputClasses() {
        return [
            'w-full min-w-0',
            'px-3 py-2',
            'text-sm text-slate-900',
            'placeholder:text-slate-400',
            'bg-transparent',
            'outline-none',
            this.disabled ? 'cursor-not-allowed select-none' : '',
            this.readonly && !this.disabled ? 'cursor-default' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html `${nothing}`;
        const labelText = this.getSlotContent('Label');
        const labelClasses = [
            'mb-1 block text-sm font-medium',
            this.disabled ? 'text-slate-500' : 'text-slate-700',
        ]
            .filter(Boolean)
            .join(' ');
        return html `
      <label id=${`input-label-${this.uid}`} class=${labelClasses}>
        ${unsafeHTML(labelText)}
        ${this.required
            ? html `<span class="ml-1 text-rose-600" aria-hidden="true">${this.msg.requiredMark}</span>`
            : nothing}
      </label>
    `;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html `${nothing}`;
        return html `
      <div class="flex items-center pl-3 pr-1 text-slate-500">
        <div class="flex items-center">${unsafeHTML(this.getSlotContent('Prefix'))}</div>
      </div>
    `;
    }
    renderSuffixOrLoading() {
        if (this.loading) {
            return html `
        <div class="flex items-center gap-2 pl-2 pr-3 text-slate-500">
          <span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-slate-600" aria-hidden="true"></span>
          <span class="text-xs">${this.msg.loading}</span>
        </div>
      `;
        }
        if (!this.hasSlot('Suffix'))
            return html `${nothing}`;
        return html `
      <div class="flex items-center pl-1 pr-3 text-slate-500">
        <div class="flex items-center">${unsafeHTML(this.getSlotContent('Suffix'))}</div>
      </div>
    `;
    }
    renderBelowText() {
        // Priority: error > helper
        if (this.isErrored) {
            const msg = this.errorMessage;
            if (!msg)
                return html `${nothing}`;
            return html `
        <div
          id=${`input-error-${this.uid}`}
          class="mt-1 text-sm text-rose-600 whitespace-pre-line"
          role="alert"
        >
          ${unsafeHTML(msg)}
        </div>
      `;
        }
        if (this.hasSlot('Helper')) {
            const helper = this.helperMessage;
            return html `
        <div id=${`input-helper-${this.uid}`} class="mt-1 text-sm text-slate-500 whitespace-pre-line">
          ${unsafeHTML(helper)}
        </div>
      `;
        }
        return html `${nothing}`;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const ariaInvalid = this.isErrored ? 'true' : 'false';
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}

        <div class=${this.getInputWrapClasses()}>
          ${this.renderPrefix()}

          <input
            class=${this.getInputClasses()}
            .value=${this.value ?? ''}
            type=${this.type || 'text'}
            name=${ifDefined(this.name || undefined)}
            placeholder=${ifDefined(this.placeholder || undefined)}
            maxlength=${ifDefined(this.maxlength)}
            minlength=${ifDefined(this.minlength)}
            pattern=${ifDefined(this.pattern)}
            autocomplete=${ifDefined(this.autocomplete)}
            inputmode=${ifDefined(this.inputmode)}
            ?disabled=${this.disabled}
            ?readonly=${this.readonly}
            aria-disabled=${this.disabled ? 'true' : 'false'}
            aria-readonly=${this.readonly ? 'true' : 'false'}
            aria-required=${this.required ? 'true' : 'false'}
            aria-invalid=${ariaInvalid}
            aria-labelledby=${ifDefined(this.labelId)}
            aria-describedby=${ifDefined(this.describedBy)}
            @input=${this.handleInput}
            @change=${this.handleChange}
            @focus=${this.handleFocus}
            @blur=${this.handleBlur}
            @keydown=${this.handleKeyDown}
          />

          ${this.renderSuffixOrLoading()}
        </div>

        ${this.renderBelowText()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], InputTextMolecule.prototype, "value", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "name", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "type", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "placeholder", void 0);
__decorate([
    property({ type: Number })
], InputTextMolecule.prototype, "maxlength", void 0);
__decorate([
    property({ type: Number })
], InputTextMolecule.prototype, "minlength", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "autocomplete", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "inputmode", void 0);
__decorate([
    property({ type: Boolean })
], InputTextMolecule.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], InputTextMolecule.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], InputTextMolecule.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], InputTextMolecule.prototype, "loading", void 0);
__decorate([
    property({ type: String })
], InputTextMolecule.prototype, "error", void 0);
__decorate([
    state()
], InputTextMolecule.prototype, "uid", void 0);
InputTextMolecule = __decorate([
    customElement('molecules--group-enter-text--input-text-102020')
], InputTextMolecule);
export { InputTextMolecule };
