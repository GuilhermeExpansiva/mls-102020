/// <mls fileReference="_102020_/l2/molecules/card.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
