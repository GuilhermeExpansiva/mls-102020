var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102020_/l2/molecules/groupselectone/ml-select-dropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML SELECT DROPDOWN MOLECULE
// =============================================================================
// Skill Group: select + one
// This molecule does NOT contain business logic.
import { html, nothing, unsafeHTML, ifDefined } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    required: 'Required field',
    searchPlaceholder: 'Search...',
    viewEmpty: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        required: 'Campo obrigatório',
        searchPlaceholder: 'Buscar...',
        viewEmpty: '—',
    },
};
let MlSelectDropdownMolecule = class MlSelectDropdownMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.activeIndex = -1;
        // ===========================================================================
        // PRIVATE FIELDS
        // ===========================================================================
        this.labelId = `ml-label-${Math.random().toString(36).slice(2)}`;
        this.helperId = `ml-helper-${Math.random().toString(36).slice(2)}`;
        this.errorId = `ml-error-${Math.random().toString(36).slice(2)}`;
        this.visibleItems = [];
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.handleDocumentClick = (event) => {
            if (!this.isOpen)
                return;
            const path = event.composedPath();
            if (!path.includes(this)) {
                this.isOpen = false;
                this.activeIndex = -1;
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.handleDocumentClick);
    }
    disconnectedCallback() {
        document.removeEventListener('click', this.handleDocumentClick);
        super.disconnectedCallback();
    }
    updated() {
        if ((this.loading || this.disabled || this.readonly || !this.isEditing) && this.isOpen) {
            this.isOpen = false;
            this.activeIndex = -1;
        }
    }
    handleTriggerClick() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.setActiveIndexFromValue();
        }
        else {
            this.activeIndex = -1;
        }
    }
    handleTriggerKeyDown(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const key = event.key;
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            event.preventDefault();
            this.openDropdown();
            this.moveActiveIndex(key === 'ArrowDown' ? 1 : -1);
        }
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            if (!this.isOpen) {
                this.openDropdown();
            }
            else if (this.activeIndex >= 0) {
                const item = this.visibleItems[this.activeIndex];
                if (item && !item.disabled) {
                    this.selectItem(item.value);
                }
            }
        }
        if (key === 'Escape' && this.isOpen) {
            event.preventDefault();
            this.closeDropdown();
        }
    }
    handlePanelKeyDown(event) {
        const key = event.key;
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            event.preventDefault();
            this.moveActiveIndex(key === 'ArrowDown' ? 1 : -1);
        }
        if (key === 'Enter' && this.activeIndex >= 0) {
            event.preventDefault();
            const item = this.visibleItems[this.activeIndex];
            if (item && !item.disabled) {
                this.selectItem(item.value);
            }
        }
        if (key === 'Escape') {
            event.preventDefault();
            this.closeDropdown();
        }
    }
    handleSearchInput(event) {
        const input = event.target;
        this.searchQuery = input.value;
        this.setActiveIndexFromValue();
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleItemClick(item) {
        if (item.disabled)
            return;
        this.selectItem(item.value);
    }
    handleItemMouseEnter(index) {
        this.activeIndex = index;
    }
    // ===========================================================================
    // INTERNAL HELPERS
    // ===========================================================================
    openDropdown() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.isOpen) {
            this.isOpen = true;
            this.setActiveIndexFromValue();
        }
    }
    closeDropdown() {
        this.isOpen = false;
        this.activeIndex = -1;
    }
    selectItem(value) {
        if (this.disabled || this.readonly)
            return;
        this.value = value;
        this.isOpen = false;
        this.searchQuery = '';
        this.activeIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    setActiveIndexFromValue() {
        const items = this.computeVisibleItems();
        this.visibleItems = items;
        const idx = items.findIndex(item => item.value === this.value);
        this.activeIndex = idx >= 0 ? idx : (items.length > 0 ? 0 : -1);
    }
    moveActiveIndex(direction) {
        const items = this.visibleItems.length ? this.visibleItems : this.computeVisibleItems();
        if (!items.length)
            return;
        let index = this.activeIndex;
        let safety = 0;
        while (safety < items.length) {
            index = (index + direction + items.length) % items.length;
            if (!items[index].disabled) {
                this.activeIndex = index;
                return;
            }
            safety += 1;
        }
    }
    computeVisibleItems() {
        const allGroups = this.getSlots('Group').map(group => {
            const label = group.getAttribute('label') || '';
            const items = Array.from(group.querySelectorAll('Item')).map(el => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML,
                disabled: el.hasAttribute('disabled'),
            }));
            return { label, items };
        });
        const directItems = this.getSlots('Item')
            .filter(el => !el.closest('Group'))
            .map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            disabled: el.hasAttribute('disabled'),
        }));
        const query = this.searchable ? this.searchQuery.trim().toLowerCase() : '';
        const matches = (label) => !query || label.toLowerCase().includes(query);
        const filteredGroups = allGroups.map(group => ({
            ...group,
            items: group.items.filter(item => matches(item.label)),
        })).filter(group => group.items.length > 0);
        const filteredDirectItems = directItems.filter(item => matches(item.label));
        return [...filteredGroups.flatMap(group => group.items), ...filteredDirectItems];
    }
    getTriggerClasses(hasError) {
        return [
            'w-full flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            this.isOpen
                ? 'ring-2 ring-sky-500 dark:ring-sky-400'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'absolute z-10 mt-1 w-full rounded-lg border shadow-lg',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
        ].join(' ');
    }
    getItemClasses(item, isSelected, isActive) {
        return [
            'w-full rounded-md px-3 py-2 text-sm transition border',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border-sky-500 dark:border-sky-400'
                : 'text-slate-900 dark:text-slate-100 border-transparent',
            !item.disabled && !isSelected
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : '',
            item.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
            isActive && !item.disabled ? 'ring-2 ring-sky-500 dark:ring-sky-400' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const allItems = this.getSlots('Item').map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            disabled: el.hasAttribute('disabled'),
        }));
        const groups = this.getSlots('Group').map(group => ({
            label: group.getAttribute('label') || '',
            items: Array.from(group.querySelectorAll('Item')).map(el => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML,
                disabled: el.hasAttribute('disabled'),
            })),
        }));
        const directItems = this.getSlots('Item').filter(el => !el.closest('Group')).map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            disabled: el.hasAttribute('disabled'),
        }));
        const selectedLabel = allItems.find(item => item.value === this.value)?.label || null;
        const requiredError = this.required && !this.value && !this.error;
        const errorMessage = this.error || (requiredError ? this.msg.required : '');
        const hasError = Boolean(errorMessage);
        const hasLabel = this.hasSlot('Label');
        const hasHelper = this.hasSlot('Helper');
        const hasTrigger = this.hasSlot('Trigger');
        const labelText = hasLabel ? this.getSlotContent('Label') : '';
        const triggerContent = selectedLabel
            ? unsafeHTML(selectedLabel)
            : hasTrigger
                ? unsafeHTML(this.getSlotContent('Trigger'))
                : (this.placeholder || this.msg.placeholder || this.msg.viewEmpty);
        const viewContent = selectedLabel
            ? unsafeHTML(selectedLabel)
            : hasTrigger
                ? unsafeHTML(this.getSlotContent('Trigger'))
                : (this.placeholder || this.msg.viewEmpty);
        if (!this.isEditing) {
            return html `
<div class="w-full">
${hasLabel
                ? html `<label id=${this.labelId} class="mb-1 block text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(labelText)}</label>`
                : nothing}
<div class="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100">
${typeof viewContent === 'string' ? viewContent : viewContent}
</div>
</div>
`;
        }
        const query = this.searchable ? this.searchQuery.trim().toLowerCase() : '';
        const matches = (label) => !query || label.toLowerCase().includes(query);
        const filteredGroups = groups.map(group => ({
            ...group,
            items: group.items.filter(item => matches(item.label)),
        })).filter(group => group.items.length > 0);
        const filteredDirectItems = directItems.filter(item => matches(item.label));
        this.visibleItems = [...filteredGroups.flatMap(group => group.items), ...filteredDirectItems];
        let runningIndex = -1;
        return html `
<div class="relative w-full">
${hasLabel
            ? html `<label id=${this.labelId} class="mb-1 block text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(labelText)}</label>`
            : nothing}

${this.name
            ? html `<input type="hidden" name=${ifDefined(this.name || undefined)} .value=${this.value ?? ''} />`
            : nothing}

<button
class=${this.getTriggerClasses(hasError)}
type="button"
role="combobox"
aria-haspopup="listbox"
aria-expanded=${this.isOpen ? 'true' : 'false'}
aria-labelledby=${ifDefined(hasLabel ? this.labelId : undefined)}
aria-describedby=${ifDefined(hasError ? this.errorId : hasHelper ? this.helperId : undefined)}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
?disabled=${this.disabled}
@click=${this.handleTriggerClick}
@keydown=${this.handleTriggerKeyDown}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
>
<span class="truncate">
${this.loading
            ? html `<span class="text-slate-500 dark:text-slate-400">${this.msg.loading}</span>`
            : typeof triggerContent === 'string'
                ? triggerContent
                : triggerContent}
</span>
<span class="text-slate-500 dark:text-slate-400">▾</span>
</button>

${this.isOpen
            ? html `
<div class=${this.getPanelClasses()} role="listbox" @keydown=${this.handlePanelKeyDown}>
<div class="p-2">
${this.searchable
                ? html `
<input
class="w-full rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400"
type="text"
placeholder=${this.msg.searchPlaceholder}
.value=${this.searchQuery}
@input=${this.handleSearchInput}
/>
`
                : nothing}
</div>
<div class="max-h-60 overflow-auto px-2 pb-2">
${filteredGroups.length > 0
                ? html `${filteredGroups.map(group => html `
<div class="py-2">
<div class="px-2 text-xs font-semibold text-slate-600 dark:text-slate-400">${group.label}</div>
<div class="mt-1 space-y-1">
${group.items.map(item => {
                    runningIndex += 1;
                    const index = runningIndex;
                    const isSelected = item.value === this.value;
                    const isActive = index === this.activeIndex;
                    return html `
<div
class=${this.getItemClasses(item, isSelected, isActive)}
role="option"
aria-selected=${isSelected ? 'true' : 'false'}
aria-disabled=${item.disabled ? 'true' : 'false'}
@click=${() => this.handleItemClick(item)}
@mouseenter=${() => this.handleItemMouseEnter(index)}
>
${unsafeHTML(item.label)}
</div>
`;
                })}
</div>
</div>
`)}
${filteredDirectItems.length > 0
                    ? html `<div class="space-y-1">
${filteredDirectItems.map(item => {
                        runningIndex += 1;
                        const index = runningIndex;
                        const isSelected = item.value === this.value;
                        const isActive = index === this.activeIndex;
                        return html `
<div
class=${this.getItemClasses(item, isSelected, isActive)}
role="option"
aria-selected=${isSelected ? 'true' : 'false'}
aria-disabled=${item.disabled ? 'true' : 'false'}
@click=${() => this.handleItemClick(item)}
@mouseenter=${() => this.handleItemMouseEnter(index)}
>
${unsafeHTML(item.label)}
</div>
`;
                    })}
</div>`
                    : nothing}
${this.visibleItems.length === 0
                    ? html `<div class="px-3 py-2 text-sm text-slate-500 dark:text-slate-400">
${this.hasSlot('Empty') ? unsafeHTML(this.getSlotContent('Empty')) : this.msg.noResults}
</div>`
                    : nothing}
</div>
</div>
`
                : nothing}

${hasError
                ? html `<p id=${this.errorId} class="mt-1 text-xs text-red-600 dark:text-red-400">${unsafeHTML(String(errorMessage))}</p>`
                : hasHelper
                    ? html `<p id=${this.helperId} class="mt-1 text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`
                    : nothing}
</div>
` : ;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlSelectDropdownMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "activeIndex", void 0);
MlSelectDropdownMolecule = __decorate([
    customElement('groupselectone--ml-select-dropdown')
], MlSelectDropdownMolecule);
export { MlSelectDropdownMolecule };
