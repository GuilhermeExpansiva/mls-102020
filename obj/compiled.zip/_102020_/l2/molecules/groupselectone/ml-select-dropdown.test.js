/// <mls fileReference="_102020_/l2/molecules/groupselectone/ml-select-dropdown.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
