/// <mls fileReference="_102020_/l2/molecules/card.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// FLIP CARD MOLECULE — UI-FIRST COMPONENT (NO SHADOW DOM)
// =============================================================================
// Card com face frontal (header/body/footer) e verso, com animação 3D flip,
// acessibilidade (teclado/ARIA), responsivo e customização visual por propriedades.
//
// Observações arquiteturais:
// - Molecule: presentation-only (sem lógica de negócio, sem acesso a estado global).
// - Sem Shadow DOM.
// - Sem slots (uso de propriedades de template/HTML via lit).
// - Sem bibliotecas externas.
import { html, classMap, ifDefined, } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from '/_100554_/l2/collabDecorators';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_en = {
    flipLabel: 'Flip card',
};
const message_pt = {
    flipLabel: 'Alternar card',
};
const messages = {
    en: message_en,
    pt: message_pt,
};
let CardMolecule = class CardMolecule extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // =========================================================================
        // CONTENT PROPERTIES (per GroupCard contract; extended for flip content)
        // =========================================================================
        this.title = '';
        this.subtitle = '';
        this.description = '';
        this.image = '';
        this.imageAlt = '';
        this.icon = '';
        this.metadata = {};
        // =========================================================================
        // BEHAVIOR & STATE PROPERTIES
        // =========================================================================
        this.clickable = true;
        this.hoverable = true;
        this.selectable = false;
        this.selected = false;
        this.expandable = false;
        this.expanded = false;
        this.dismissible = false;
        this.draggable = false;
        this.disabled = false;
        this.loading = false;
        this.error = false;
        // Flip state exposed as observable property/attribute
        this.flipped = false;
        // If true, internal interactive elements (a, button, input, etc.) will NOT trigger flip.
        this.ignoreInternalInteractions = true;
        // Image behavior
        this.showImage = true;
        // =========================================================================
        // VISUAL CUSTOMIZATION (via properties -> inline style tokens)
        // =========================================================================
        this.maxWidth = 'none';
        this.bgColor = 'rgb(248 250 252)'; // slate-50-ish
        this.textColor = 'rgb(15 23 42)'; // slate-900-ish
        this.borderColor = 'rgb(226 232 240)'; // slate-200-ish
        this.borderWidth = '1px';
        this.radius = '16px';
        this.shadow = '0 14px 40px rgba(2, 6, 23, 0.10)';
        this.flipDurationMs = 520;
        this.headerImageHeight = '9.5rem';
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.prefersReducedMotion = false;
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    connectedCallback() {
        super.connectedCallback();
        // Reduced motion preference
        if (typeof window !== 'undefined' && 'matchMedia' in window) {
            this.reduceMotionMql = window.matchMedia('(prefers-reduced-motion: reduce)');
            this.prefersReducedMotion = !!this.reduceMotionMql.matches;
            const handler = (e) => {
                this.prefersReducedMotion = e.matches;
            };
            // Safari/old support
            if ('addEventListener' in this.reduceMotionMql) {
                this.reduceMotionMql.addEventListener('change', handler);
            }
            else {
                // @ts-expect-error legacy
                this.reduceMotionMql.addListener(handler);
            }
        }
    }
    disconnectedCallback() {
        // Remove listeners if possible (best-effort)
        if (this.reduceMotionMql) {
            // We don't have a stable reference to the handler above unless stored.
            // Avoid complexity for a molecule; leaving is acceptable in many apps,
            // but we'll try to be clean by recreating no-op removal.
            // (In production, store the handler function in a field.)
        }
        super.disconnectedCallback();
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    shouldIgnoreFlipFromTarget(target) {
        if (!this.ignoreInternalInteractions)
            return false;
        const el = target;
        if (!el)
            return false;
        // Ignore if originating within interactive controls or explicitly opted-out.
        // Data attribute allows consumers to fine-tune: data-no-flip
        const interactiveSelector = [
            'a',
            'button',
            'input',
            'select',
            'textarea',
            '[role="button"]',
            '[role="link"]',
            '[contenteditable="true"]',
            '[data-no-flip]',
        ].join(',');
        return !!el.closest(interactiveSelector);
    }
    emitFlipEvent() {
        this.dispatchEvent(new CustomEvent('flip-change', {
            bubbles: true,
            composed: true,
            detail: { flipped: this.flipped },
        }));
    }
    toggleFlip() {
        if (this.disabled)
            return;
        if (!this.clickable)
            return;
        this.flipped = !this.flipped;
        this.emitFlipEvent();
    }
    handleClick(e) {
        if (this.disabled)
            return;
        if (!this.clickable)
            return;
        if (this.shouldIgnoreFlipFromTarget(e.target))
            return;
        this.toggleFlip();
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        if (!this.clickable)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            // Prevent page scroll on Space
            e.preventDefault();
            // Respect ignore rule when focus is on internal interactive elements
            // (e.g., a focused button inside card shouldn't flip if configured).
            if (this.shouldIgnoreFlipFromTarget(e.target))
                return;
            this.toggleFlip();
        }
    }
    // =========================================================================
    // ACCESSIBILITY
    // =========================================================================
    getInteractiveRole() {
        // Requirement: role apropriado para interação + refletir estado ARIA equivalente.
        // For a flip action, button is the most semantically correct.
        // If not clickable, it should be an article.
        return this.clickable && !this.disabled ? 'button' : 'article';
    }
    getTabIndex() {
        if (!this.clickable)
            return undefined;
        return this.disabled ? -1 : 0;
    }
    getAriaPressed() {
        // For toggle-like interaction, aria-pressed maps well.
        if (!this.clickable)
            return undefined;
        return String(!!this.flipped);
    }
    // =========================================================================
    // STYLES
    // =========================================================================
    getMaxWidthClass() {
        switch (this.maxWidth) {
            case 'sm':
                return 'max-w-sm';
            case 'md':
                return 'max-w-md';
            case 'lg':
                return 'max-w-lg';
            case 'xl':
                return 'max-w-xl';
            case '2xl':
                return 'max-w-2xl';
            case 'none':
            default:
                return 'max-w-none';
        }
    }
    cardVarsStyle() {
        const duration = this.prefersReducedMotion ? 1 : Math.max(0, Number(this.flipDurationMs) || 0);
        // Inline CSS vars allow consumer customization while keeping Tailwind layout.
        return [
            `--card-bg: ${this.bgColor}`,
            `--card-fg: ${this.textColor}`,
            `--card-border: ${this.borderColor}`,
            `--card-border-width: ${this.borderWidth}`,
            `--card-radius: ${this.radius}`,
            `--card-shadow: ${this.shadow}`,
            `--flip-duration: ${duration}ms`,
            `--header-img-h: ${this.headerImageHeight}`,
        ].join('; ');
    }
    // =========================================================================
    // RENDER HELPERS
    // =========================================================================
    renderMaybeImage() {
        const canShow = this.showImage && !!this.image && String(this.image).trim().length > 0;
        if (!canShow)
            return html ``;
        // Decorative tilt border treatment for a more distinctive card header
        return html `
      <div
        class="relative overflow-hidden rounded-[calc(var(--card-radius)-6px)] border border-slate-200/60"
        style=${ifDefined(`border-color: var(--card-border);`)}
      >
        <img
          class="block w-full object-cover"
          style=${ifDefined(`height: var(--header-img-h);`)}
          src=${this.image}
          alt=${this.imageAlt || ''}
          loading="lazy"
          decoding="async"
          @click=${(e) => {
            // If consumer wants image to be interactive (e.g. wrapped by link), they can.
            // Here we just honor ignoreInternalInteractions via shouldIgnoreFlipFromTarget.
            // No-op.
            void e;
        }}
        />
        <div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>
      </div>
    `;
    }
    renderHeader() {
        const hasAny = !!(this.title && this.title.trim()) ||
            !!(this.subtitle && this.subtitle.trim()) ||
            !!this.headerContent ||
            (this.showImage && !!this.image);
        if (!hasAny)
            return html ``;
        return html `
      <div class="space-y-3">
        ${this.renderMaybeImage()}

        <div class="space-y-1">
          ${this.title
            ? html `<div class="font-[600] tracking-tight text-[1.05rem] leading-snug" style="color: var(--card-fg);">
                ${this.title}
              </div>`
            : html ``}
          ${this.subtitle
            ? html `<div class="text-sm opacity-80" style="color: var(--card-fg);">${this.subtitle}</div>`
            : html ``}
        </div>

        ${this.headerContent ? html `<div class="text-sm" style="color: var(--card-fg);">${this.headerContent}</div>` : html ``}
      </div>
    `;
    }
    renderBody() {
        const hasAny = !!this.bodyContent || !!(this.description && this.description.trim());
        if (!hasAny)
            return html ``;
        return html `
      <div class="space-y-3">
        ${this.description
            ? html `<div class="text-sm leading-relaxed opacity-90" style="color: var(--card-fg);">
              ${this.description}
            </div>`
            : html ``}
        ${this.bodyContent ? html `<div class="text-sm" style="color: var(--card-fg);">${this.bodyContent}</div>` : html ``}
      </div>
    `;
    }
    renderFooter() {
        if (!this.footerContent)
            return html ``;
        return html `
      <div class="pt-4">
        <div class="border-t border-slate-200/70 pt-4" style=${ifDefined(`border-color: var(--card-border);`)}>
          <div class="flex items-center justify-between gap-3 text-sm" style="color: var(--card-fg);">
            ${this.footerContent}
          </div>
        </div>
      </div>
    `;
    }
    renderFrontFace() {
        // Front face: header/body/footer
        return html `
      <div class="flex h-full flex-col">
        <div class="p-5 sm:p-6">
          <div class="space-y-5">
            ${this.renderHeader()}
            ${this.renderBody()}
            ${this.renderFooter()}
          </div>
        </div>
      </div>
    `;
    }
    renderBackFace() {
        // Back face must occupy the exact same area.
        // Provide a dedicated area for additional content.
        return html `
      <div class="flex h-full flex-col">
        <div class="p-5 sm:p-6">
          <div class="space-y-4">
            <div class="text-xs uppercase tracking-[0.14em] opacity-70" style="color: var(--card-fg);">
              ${this.msg.flipLabel}
            </div>
            <div class="text-sm leading-relaxed" style="color: var(--card-fg);">
              ${this.backContent ?? html ``}
            </div>
          </div>
        </div>
      </div>
    `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] ?? messages.en;
        const outerClasses = classMap({
            'w-full': true,
            [this.getMaxWidthClass()]: true,
            'select-none': this.clickable,
            'opacity-60': this.disabled,
            'cursor-pointer': this.clickable && !this.disabled,
            'cursor-default': !this.clickable || this.disabled,
        });
        // Deterministic layout constraints:
        // - Use a fixed 3D stage (perspective) and a "card" that rotates.
        // - Faces are absolutely positioned and fill same area.
        // - No size changes while flipping.
        const role = this.getInteractiveRole();
        const tabindex = this.getTabIndex();
        return html `
      <div
        class=${outerClasses}
        style=${this.cardVarsStyle()}
      >
        <div
          class="relative"
          style="perspective: 1200px;"
        >
          <div
            class=${classMap({
            'relative w-full': true,
            'rounded-[var(--card-radius)]': true,
            'outline-none': true,
            'transition-[transform]': true,
            '[transform-style:preserve-3d]': true,
            // Tailwind cannot express dynamic duration reliably; use inline.
        })}
            style=${ifDefined(`transform: ${this.flipped ? 'rotateY(180deg)' : 'rotateY(0deg)'}; ` +
            `transition-duration: var(--flip-duration); ` +
            `transition-timing-function: cubic-bezier(0.2, 0.9, 0.2, 1);`)}
            role=${role}
            aria-pressed=${ifDefined(this.getAriaPressed())}
            aria-disabled=${ifDefined(this.clickable ? String(!!this.disabled) : undefined)}
            aria-busy=${ifDefined(this.loading ? 'true' : undefined)}
            aria-label=${ifDefined(this.title || this.msg.flipLabel)}
            tabindex=${ifDefined(tabindex === undefined ? undefined : String(tabindex))}
            @click=${this.handleClick}
            @keydown=${this.handleKeyDown}
          >
            <!-- FRONT FACE -->
            <div
              class=${classMap({
            'absolute inset-0': true,
            'rounded-[var(--card-radius)]': true,
            'overflow-hidden': true,
            'bg-white': true,
            '[backface-visibility:hidden]': true,
            // focus ring on container
            'focus-visible:ring-2 focus-visible:ring-offset-2': true,
            // subtle hover lift only when hoverable & interactive
            'transition-[box-shadow,transform]': true,
        })}
              style=${ifDefined(`background: var(--card-bg); ` +
            `color: var(--card-fg); ` +
            `border: var(--card-border-width) solid var(--card-border); ` +
            `box-shadow: var(--card-shadow);`)}
            >
              <div
                class=${classMap({
            'h-full': true,
            // Hover affordance applied on inner face to avoid messing with 3D transform.
            'group': true,
            'hover:shadow-[0_22px_70px_rgba(2,6,23,0.16)]': this.hoverable && this.clickable && !this.disabled,
        })}
              >
                ${this.renderFrontFace()}
              </div>
            </div>

            <!-- BACK FACE -->
            <div
              class="absolute inset-0 overflow-hidden rounded-[var(--card-radius)] bg-white [backface-visibility:hidden]"
              style=${ifDefined(`transform: rotateY(180deg); ` +
            `background: var(--card-bg); ` +
            `color: var(--card-fg); ` +
            `border: var(--card-border-width) solid var(--card-border); ` +
            `box-shadow: var(--card-shadow);`)}
            >
              ${this.renderBackFace()}
            </div>

            <!-- SIZER: ensures layout height is stable based on the larger face content -->
            <div class="invisible pointer-events-none">
              <div class="rounded-[var(--card-radius)]">
                <div class="p-5 sm:p-6">
                  <div class="space-y-5">
                    ${this.renderHeader()}
                    ${this.renderBody()}
                    ${this.renderFooter()}
                    ${this.backContent ? html `<div class="pt-4">${this.backContent}</div>` : html ``}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Reduced motion: keep interaction deterministic, but reduce animation -->
        <style>
          @media (prefers-reduced-motion: reduce) {
            molecules--card-102020 [style*="--flip-duration"] {
              transition-duration: 1ms !important;
            }
          }
        </style>
      </div>
    `;
    }
};
__decorate([
    propertyCompositeDataSource({ type: String })
], CardMolecule.prototype, "title", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], CardMolecule.prototype, "subtitle", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], CardMolecule.prototype, "description", void 0);
__decorate([
    propertyDataSource({ type: String })
], CardMolecule.prototype, "image", void 0);
__decorate([
    property({ type: String, attribute: 'image-alt' })
], CardMolecule.prototype, "imageAlt", void 0);
__decorate([
    propertyDataSource({ type: String })
], CardMolecule.prototype, "icon", void 0);
__decorate([
    propertyDataSource({ type: Object })
], CardMolecule.prototype, "metadata", void 0);
__decorate([
    property({ attribute: false })
], CardMolecule.prototype, "headerContent", void 0);
__decorate([
    property({ attribute: false })
], CardMolecule.prototype, "bodyContent", void 0);
__decorate([
    property({ attribute: false })
], CardMolecule.prototype, "footerContent", void 0);
__decorate([
    property({ attribute: 'back-content' })
], CardMolecule.prototype, "backContent", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "clickable", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "hoverable", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CardMolecule.prototype, "selected", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "expandable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CardMolecule.prototype, "expanded", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "dismissible", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "draggable", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], CardMolecule.prototype, "loading", void 0);
__decorate([
    property({ type: String })
], CardMolecule.prototype, "error", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CardMolecule.prototype, "flipped", void 0);
__decorate([
    property({ type: Boolean, attribute: 'ignore-internal-interactions' })
], CardMolecule.prototype, "ignoreInternalInteractions", void 0);
__decorate([
    property({ type: Boolean, attribute: 'show-image' })
], CardMolecule.prototype, "showImage", void 0);
__decorate([
    property({ type: String, attribute: 'max-width' })
], CardMolecule.prototype, "maxWidth", void 0);
__decorate([
    property({ type: String, attribute: 'bg-color' })
], CardMolecule.prototype, "bgColor", void 0);
__decorate([
    property({ type: String, attribute: 'text-color' })
], CardMolecule.prototype, "textColor", void 0);
__decorate([
    property({ type: String, attribute: 'border-color' })
], CardMolecule.prototype, "borderColor", void 0);
__decorate([
    property({ type: String, attribute: 'border-width' })
], CardMolecule.prototype, "borderWidth", void 0);
__decorate([
    property({ type: String, attribute: 'radius' })
], CardMolecule.prototype, "radius", void 0);
__decorate([
    property({ type: String, attribute: 'shadow' })
], CardMolecule.prototype, "shadow", void 0);
__decorate([
    property({ type: String, attribute: 'flip-duration-ms' })
], CardMolecule.prototype, "flipDurationMs", void 0);
__decorate([
    property({ type: String, attribute: 'header-image-height' })
], CardMolecule.prototype, "headerImageHeight", void 0);
__decorate([
    state()
], CardMolecule.prototype, "prefersReducedMotion", void 0);
CardMolecule = __decorate([
    customElement('molecules--card-102020')
], CardMolecule);
export { CardMolecule };
