/// <mls fileReference="_102020_/l2/molecules/groupviewchart/ml-pie-chart.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
