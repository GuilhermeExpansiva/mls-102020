var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102020_/l2/molecules/groupShowProgress/spinner.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SPINNER MOLECULE (show + progress group)
// =============================================================================
// Tag: molecules--group-show-progress--spinner-102020
// This molecule is a visual-only spinner/progress indicator. No slot tags.
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    label: 'Loading',
};
const messages = {
    en: message_en,
    pt: {
        label: 'Carregando',
    },
};
/// **collab_i18n_end**
let GroupShowProgressSpinnerMolecule = class GroupShowProgressSpinnerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // PROPERTIES
        // ===========================================================================
        /**
         * Progress value (0–100). null = indeterminate.
         */
        this.value = null;
        /**
         * Visual size: 'xs', 'sm', 'md', 'lg'
         */
        this.size = 'md';
        /**
         * Accessible label for screen readers
         */
        this.label = '';
        /**
         * Show numeric value (only in determinate mode)
         */
        this.showValue = false;
        /**
         * Spinner color (Tailwind color class, e.g. 'text-sky-500')
         */
        this.color = 'text-sky-500';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.clampedValue = null;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER (for derived value)
    // ===========================================================================
    handleIcaStateChange(key, value) {
        // Clamp value if needed
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.clampedValue = typeof value === 'number' && !isNaN(value)
                ? Math.max(0, Math.min(100, value))
                : null;
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        // Clamp value on first connect
        this.clampedValue = typeof this.value === 'number' && !isNaN(this.value)
            ? Math.max(0, Math.min(100, this.value))
            : null;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        const msg = messages[lang];
        const ariaLabel = this.label || msg.label;
        const sizeClass = this.getSizeClass(this.size);
        const colorClass = this.color || 'text-sky-500';
        const isIndeterminate = this.clampedValue === null;
        const percent = this.clampedValue ?? 0;
        // Accessibility attributes
        const a11y = {
            role: 'progressbar',
            'aria-label': ariaLabel,
            'aria-valuemin': isIndeterminate ? undefined : 0,
            'aria-valuemax': isIndeterminate ? undefined : 100,
            'aria-valuenow': isIndeterminate ? undefined : percent,
        };
        return html `
      <span
        class="inline-flex items-center justify-center ${sizeClass} ${colorClass}"
        ...=${a11y}
        tabindex="-1"
        aria-hidden="false"
        style="pointer-events:none;user-select:none;"
      >
        ${isIndeterminate
            ? this.renderIndeterminateSpinner(sizeClass, colorClass)
            : this.renderDeterminateSpinner(percent, sizeClass, colorClass)}
        ${!isIndeterminate && this.showValue
            ? html `<span class="ml-2 text-xs font-medium text-slate-500">${percent}%</span>`
            : nothing}
      </span>
    `;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    /**
     * Indeterminate spinner (animated SVG ring)
     */
    renderIndeterminateSpinner(sizeClass, colorClass) {
        // SVG spinner, always spinning
        return html `
      <svg
        class="animate-spin ${colorClass}"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        aria-hidden="true"
        focusable="false"
        width="100%"
        height="100%"
      >
        <circle
          class="opacity-25"
          cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"
        />
        <path
          class="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
        />
      </svg>
    `;
    }
    /**
     * Determinate spinner (progress ring)
     */
    renderDeterminateSpinner(percent, sizeClass, colorClass) {
        // SVG circular progress ring
        // 12px radius, 2px stroke, 2*PI*10 = 62.8
        const radius = 10;
        const stroke = 4;
        const normalizedRadius = radius - stroke / 2;
        const circumference = 2 * Math.PI * normalizedRadius;
        const progress = circumference * (1 - percent / 100);
        return html `
      <svg
        class="${colorClass}"
        width="24" height="24" viewBox="0 0 24 24"
        fill="none"
        aria-hidden="true"
        focusable="false"
      >
        <circle
          class="opacity-25"
          cx="12" cy="12" r="${normalizedRadius}"
          stroke="currentColor"
          stroke-width="${stroke}"
          fill="none"
        />
        <circle
          class="opacity-100 transition-all duration-300"
          cx="12" cy="12" r="${normalizedRadius}"
          stroke="currentColor"
          stroke-width="${stroke}"
          fill="none"
          stroke-dasharray="${circumference}"
          stroke-dashoffset="${progress}"
          stroke-linecap="round"
        />
      </svg>
    `;
    }
    // ===========================================================================
    // SIZE MAPPING
    // ===========================================================================
    getSizeClass(size) {
        switch ((size || '').toLowerCase()) {
            case 'xs':
                return 'w-4 h-4'; // 16px
            case 'sm':
                return 'w-6 h-6'; // 24px
            case 'lg':
                return 'w-12 h-12'; // 48px
            case 'md':
            default:
                return 'w-10 h-10'; // 40px
        }
    }
};
__decorate([
    propertyDataSource({ type: Number })
], GroupShowProgressSpinnerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupShowProgressSpinnerMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupShowProgressSpinnerMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], GroupShowProgressSpinnerMolecule.prototype, "showValue", void 0);
__decorate([
    property({ type: String })
], GroupShowProgressSpinnerMolecule.prototype, "color", void 0);
__decorate([
    state()
], GroupShowProgressSpinnerMolecule.prototype, "clampedValue", void 0);
GroupShowProgressSpinnerMolecule = __decorate([
    customElement('molecules--group-show-progress--spinner-102020')
], GroupShowProgressSpinnerMolecule);
export { GroupShowProgressSpinnerMolecule };
