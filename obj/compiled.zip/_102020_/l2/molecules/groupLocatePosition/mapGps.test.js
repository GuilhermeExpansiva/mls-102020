/// <mls fileReference="_102020_/l2/molecules/groupLocatePosition/mapGps.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
