/// <mls fileReference="_102020_/l2/molecules/index.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
