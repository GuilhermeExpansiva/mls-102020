/// <mls fileReference="_102020_/l2/molecules/groupEnterNumber/inputNumber.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
