var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102020_/l2/molecules/groupEnterNumber/inputStepper.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// INPUT STEPPER MOLECULE (enter + number)
// =============================================================================
// Tag: molecules--group-enter-number--input-stepper-102020
// Skill Group: groupEnterNumber (enter + number)
// This molecule does NOT contain business logic.
import { html, nothing, unsafeHTML, ifDefined } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102020_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Enter a number',
    loading: 'Loading...',
    empty: '—',
    decrement: 'Decrement',
    increment: 'Increment',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite um número',
        loading: 'Carregando...',
        empty: '—',
        decrement: 'Diminuir',
        increment: 'Aumentar',
    },
};
/// **collab_i18n_end**
let GroupEnterNumberInputStepperMolecule = class GroupEnterNumberInputStepperMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.rawValue = '';
    }
    // ===========================================================================
    // STATE CHANGE HANDLER (for derived value)
    // ==========================================================================
    handleIcaStateChange(key, value) {
        // Update rawValue when value changes externally
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.rawValue = this.formatToDisplay(value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // FORMAT/UTILS
    // ==========================================================================
    formatToDisplay(val) {
        if (val === null || val === undefined || isNaN(val))
            return '';
        const decimals = typeof this.decimals === 'number' ? this.decimals : 0;
        const locale = this.locale || undefined;
        try {
            return val.toLocaleString(locale, {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals,
            });
        }
        catch {
            return val.toString();
        }
    }
    parseRawToNumber(raw) {
        if (!raw)
            return null;
        let cleaned = raw.replace(/\s/g, '');
        // Handle locale decimal separator
        if (this.locale === 'pt-BR') {
            cleaned = cleaned.replace(/\./g, '').replace(/,/g, '.');
        }
        else if (this.locale === 'en-US') {
            cleaned = cleaned.replace(/,/g, '');
        }
        const num = parseFloat(cleaned);
        if (isNaN(num))
            return null;
        return this.roundToDecimals(num);
    }
    roundToDecimals(val) {
        const decimals = typeof this.decimals === 'number' ? this.decimals : 0;
        const factor = Math.pow(10, decimals);
        return Math.round(val * factor) / factor;
    }
    clamp(val) {
        if (val === null || val === undefined || isNaN(val))
            return null;
        if (this.min !== null && val < this.min)
            return this.min;
        if (this.max !== null && val > this.max)
            return this.max;
        return val;
    }
    // ===========================================================================
    // EVENT EMITTERS
    // ==========================================================================
    emitChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    emitInput() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    emitFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // STEPPER HANDLERS
    // ==========================================================================
    increment() {
        if (this.disabled || this.readonly || this.loading)
            return;
        const current = this.value ?? 0;
        let next = current + this.step;
        if (this.max !== null && next > this.max)
            next = this.max;
        this.value = this.roundToDecimals(next);
        this.rawValue = this.formatToDisplay(this.value);
        this.emitChange();
    }
    decrement() {
        if (this.disabled || this.readonly || this.loading)
            return;
        const current = this.value ?? 0;
        let next = current - this.step;
        if (this.min !== null && next < this.min)
            next = this.min;
        this.value = this.roundToDecimals(next);
        this.rawValue = this.formatToDisplay(this.value);
        this.emitChange();
    }
    // ===========================================================================
    // INPUT HANDLERS
    // ==========================================================================
    handleInput(e) {
        const input = e.target;
        this.rawValue = input.value;
        const parsed = this.parseRawToNumber(input.value);
        this.value = parsed;
        this.emitInput();
    }
    handleBlur() {
        // Clamp and normalize
        let parsed = this.parseRawToNumber(this.rawValue);
        parsed = this.clamp(parsed);
        if (parsed !== null && typeof parsed === 'number') {
            parsed = this.roundToDecimals(parsed);
        }
        this.value = parsed;
        this.rawValue = this.formatToDisplay(parsed);
        this.emitChange();
        this.emitBlur();
    }
    handleFocus() {
        this.emitFocus();
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Loading state
        if (this.loading) {
            return html `<div class="flex items-center gap-2 text-slate-400"><span class="animate-spin h-4 w-4 border-2 border-t-sky-500 border-slate-200 rounded-full"></span>${this.msg.loading}</div>`;
        }
        // View Mode
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        // Edit Mode
        return this.renderEditMode();
    }
    renderViewMode() {
        const label = this.hasSlot('Label') ? html `<div class="mb-1 text-sm font-medium text-slate-700" id="label">${unsafeHTML(this.getSlotContent('Label'))}</div>` : nothing;
        const prefix = this.hasSlot('Prefix') ? html `<span class="mr-1">${unsafeHTML(this.getSlotContent('Prefix'))}</span>` : nothing;
        const suffix = this.hasSlot('Suffix') ? html `<span class="ml-1">${unsafeHTML(this.getSlotContent('Suffix'))}</span>` : nothing;
        const display = (this.value === null || this.value === undefined || isNaN(this.value))
            ? this.msg.empty
            : this.formatToDisplay(this.value);
        return html `
      <div class="flex flex-col w-full">
        ${label}
        <div class="flex items-center text-base text-slate-900 min-h-[2.5rem]">
          ${prefix}
          <span>${display}</span>
          ${suffix}
        </div>
      </div>
    `;
    }
    renderEditMode() {
        const label = this.hasSlot('Label') ? html `<div class="mb-1 text-sm font-medium text-slate-700" id="label">${unsafeHTML(this.getSlotContent('Label'))}</div>` : nothing;
        const prefix = this.hasSlot('Prefix') ? html `<span class="mr-1">${unsafeHTML(this.getSlotContent('Prefix'))}</span>` : nothing;
        const suffix = this.hasSlot('Suffix') ? html `<span class="ml-1">${unsafeHTML(this.getSlotContent('Suffix'))}</span>` : nothing;
        const error = this.error && this.error !== '';
        const inputId = this.name ? `input-${this.name}` : 'input-number';
        const describedBy = error ? 'error' : (this.hasSlot('Helper') ? 'helper' : undefined);
        const placeholder = this.placeholder || this.msg.placeholder;
        // Visual state classes
        const inputClasses = [
            'block w-full px-3 py-2 text-base rounded-md border transition',
            error ? 'border-red-500 focus:ring-red-500' : 'border-slate-300 focus:border-sky-500 focus:ring-sky-500',
            this.disabled ? 'bg-slate-100 opacity-60 cursor-not-allowed' : 'bg-white',
            this.readonly ? 'bg-slate-50 cursor-default' : '',
        ].join(' ');
        return html `
      <div class="flex flex-col w-full">
        ${label}
        <div class="flex items-center gap-1">
          <!-- Stepper Decrement -->
          <button
            type="button"
            class="h-9 w-9 flex items-center justify-center rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="${this.msg.decrement}"
            ?disabled=${this.disabled || this.readonly}
            @click=${this.decrement}
            tabindex="-1"
          >
            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><rect x="3" y="7.25" width="10" height="1.5" rx="0.75" fill="currentColor"/></svg>
          </button>
          <!-- Prefix -->
          ${prefix}
          <!-- Input -->
          <input
            id="${inputId}"
            class="${inputClasses}"
            type="text"
            inputmode="decimal"
            .value=${this.rawValue}
            ?disabled=${this.disabled || this.loading}
            ?readonly=${this.readonly}
            aria-labelledby="label"
            aria-describedby="${ifDefined(describedBy)}"
            aria-invalid="${error ? 'true' : 'false'}"
            aria-required="${this.required ? 'true' : 'false'}"
            placeholder="${placeholder}"
            @input=${this.handleInput}
            @blur=${this.handleBlur}
            @focus=${this.handleFocus}
            name="${this.name}"
            autocomplete="off"
            spellcheck="false"
          />
          <!-- Suffix -->
          ${suffix}
          <!-- Stepper Increment -->
          <button
            type="button"
            class="h-9 w-9 flex items-center justify-center rounded-md border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="${this.msg.increment}"
            ?disabled=${this.disabled || this.readonly}
            @click=${this.increment}
            tabindex="-1"
          >
            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><rect x="3" y="7.25" width="10" height="1.5" rx="0.75" fill="currentColor"/><rect x="7.25" y="3" width="1.5" height="10" rx="0.75" fill="currentColor"/></svg>
          </button>
        </div>
        <!-- Error or Helper -->
        ${error
            ? html `<div id="error" class="mt-1 text-sm text-red-600">${this.error}</div>`
            : (this.hasSlot('Helper')
                ? html `<div id="helper" class="mt-1 text-sm text-slate-500">${unsafeHTML(this.getSlotContent('Helper'))}</div>`
                : nothing)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterNumberInputStepperMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterNumberInputStepperMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterNumberInputStepperMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterNumberInputStepperMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterNumberInputStepperMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterNumberInputStepperMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterNumberInputStepperMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterNumberInputStepperMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterNumberInputStepperMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], GroupEnterNumberInputStepperMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterNumberInputStepperMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterNumberInputStepperMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterNumberInputStepperMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterNumberInputStepperMolecule.prototype, "loading", void 0);
__decorate([
    state()
], GroupEnterNumberInputStepperMolecule.prototype, "rawValue", void 0);
GroupEnterNumberInputStepperMolecule = __decorate([
    customElement('molecules--group-enter-number--input-stepper-102020')
], GroupEnterNumberInputStepperMolecule);
export { GroupEnterNumberInputStepperMolecule };
