/// <mls fileReference="_102020_/l2/molecules/groupEnterNumber/inputStepper.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
