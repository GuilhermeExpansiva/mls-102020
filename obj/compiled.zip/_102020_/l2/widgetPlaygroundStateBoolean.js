/// <mls fileReference="_102020_/l2/widgetPlaygroundStateBoolean.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { propertyDataSource } from '/_102027_/l2/collabDecorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let WcInputBoolean102020 = class WcInputBoolean102020 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-playground-state-boolean-102020{display:block;margin-bottom:.5rem}`);
        this.value = false;
        this.disabled = false;
    }
    render() {
        return html `
      <div class="flex flex-col gap-1">

        <label class="flex items-center justify-between cursor-pointer">

          <div class="flex flex-col">
            ${this.label ? html `
              <span class="text-sm font-medium text-gray-700">
                ${this.label}
              </span>
            ` : null}

            ${this.hint ? html `
              <span class="text-xs text-gray-500">
                ${this.hint}
              </span>
            ` : null}
          </div>

          <div class="relative inline-flex items-center">
            <input
              type="checkbox"
              class="sr-only peer"
              .checked=${this.value}
              ?disabled=${this.disabled}
              @change=${this.handleChange}
            />

            <div class="
              w-11 h-6 rounded-full transition
              bg-gray-300

              peer-checked:bg-blue-500
              peer-disabled:bg-gray-200

              after:content-['']
              after:absolute after:top-[2px] after:left-[2px]
              after:w-5 after:h-5
              after:bg-white after:rounded-full
              after:transition

              peer-checked:after:translate-x-5
            "></div>
          </div>

        </label>

      </div>
    `;
    }
    handleChange(event) {
        const input = event.target;
        this.value = input.checked;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], WcInputBoolean102020.prototype, "value", void 0);
__decorate([
    property({ type: String })
], WcInputBoolean102020.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputBoolean102020.prototype, "label", void 0);
__decorate([
    property({ type: Boolean })
], WcInputBoolean102020.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputBoolean102020.prototype, "hint", void 0);
WcInputBoolean102020 = __decorate([
    customElement('widget-playground-state-boolean-102020')
], WcInputBoolean102020);
export { WcInputBoolean102020 };
