/// <mls fileReference="_102020_/l2/agentMaterializeSolution/ast/astCollab.ts" enhancement="_blank"/>
// ============================================================
// NAVIGATION
// ============================================================
export function getNavigation(source, projectId, moduleId) {
    const obj = parse(source);
    return findModule(obj, projectId, moduleId)?.navigation ?? [];
}
export function hasNavigation(source, projectId, moduleId, id) {
    return getNavigation(source, projectId, moduleId).some(n => n.id === id);
}
export function addNavigation(source, projectId, moduleId, entry, throwIfExists = false) {
    if (hasNavigation(source, projectId, moduleId, entry.id)) {
        if (throwIfExists)
            throw new Error(`Nav id "${entry.id}" already exists.`);
        return source;
    }
    const obj = parse(source);
    const mod = requireModule(obj, projectId, moduleId);
    if (!Array.isArray(mod.navigation))
        mod.navigation = [];
    mod.navigation.push(entry);
    return serialize(obj);
}
export function removeNavigation(source, projectId, moduleId, id) {
    const obj = parse(source);
    const mod = requireModule(obj, projectId, moduleId);
    if (!Array.isArray(mod.navigation))
        return source;
    mod.navigation = mod.navigation.filter((n) => n.id !== id);
    return serialize(obj);
}
// ============================================================
// PAGES
// ============================================================
export function getPages(source, projectId, moduleId) {
    return findModule(parse(source), projectId, moduleId)?.frontend?.pages ?? [];
}
export function hasPage(source, projectId, moduleId, pageId) {
    return getPages(source, projectId, moduleId).some(p => p.pageId === pageId);
}
export function addPage(source, projectId, moduleId, entry, throwIfExists = false) {
    if (hasPage(source, projectId, moduleId, entry.pageId)) {
        if (throwIfExists)
            throw new Error(`Page "${entry.pageId}" already exists.`);
        return source;
    }
    const obj = parse(source);
    const mod = requireModule(obj, projectId, moduleId);
    if (!mod.frontend || typeof mod.frontend !== 'object')
        mod.frontend = {};
    if (!Array.isArray(mod.frontend.pages))
        mod.frontend.pages = [];
    mod.frontend.pages.push(entry);
    return serialize(obj);
}
export function removePage(source, projectId, moduleId, pageId) {
    const obj = parse(source);
    const mod = requireModule(obj, projectId, moduleId);
    if (!mod.frontend?.pages)
        return source;
    mod.frontend.pages = mod.frontend.pages.filter((p) => p.pageId !== pageId);
    return serialize(obj);
}
// ============================================================
// INTERNAL
// ============================================================
function parse(source) {
    try {
        return JSON.parse(source);
    }
    catch (e) {
        throw new Error(`[astCollab] invalid JSON: ${e.message}`);
    }
}
function serialize(obj) {
    return JSON.stringify(obj, null, 2);
}
function findModule(obj, projectId, moduleId) {
    const modules = obj?.projects?.[projectId]?.modules;
    if (!Array.isArray(modules))
        return null;
    return modules.find((m) => m.moduleId === moduleId) ?? null;
}
function requireModule(obj, projectId, moduleId) {
    const mod = findModule(obj, projectId, moduleId);
    if (!mod)
        throw new Error(`[astCollab] module "${moduleId}" not found in project "${projectId}"`);
    return mod;
}
// ============================================================
// USE CASE
// ============================================================
/*

test('add + remove navigation', () => {
  let out = addNavigation(SRC, '102043', 'cafeFlow', {
    id: 'newPage',
    label: 'Nova Página',
    href: '/cafe-flow/nova',
    description: 'Descrição.',
  });
  eq(getNavigation(out, '102043', 'cafeFlow').length, prevLen + 1);

  out = removeNavigation(out, '102043', 'cafeFlow', 'newPage');
  eq(getNavigation(out, '102043', 'cafeFlow').length, prevLen);
});

test('add + remove page', () => {
  let out = addPage(SRC, '102043', 'cafeFlow', {
    pageId: 'newPage',
    route: '/cafe-flow/nova',
    source: 'l2/cafeFlow/novaPage.ts',
    definition: 'l2/cafeFlow/novaPage.defs.ts',
    componentTag: 'cafe-flow-nova-page-102043',
  });
  eq(getPages(out, '102043', 'cafeFlow').length, prevLen + 1);

  out = removePage(out, '102043', 'cafeFlow', 'newPage');
  eq(getPages(out, '102043', 'cafeFlow').length, prevLen);
});

*/
