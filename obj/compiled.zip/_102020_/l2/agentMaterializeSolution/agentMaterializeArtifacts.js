/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.ts" enhancement="_blank"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
// ─── Path helpers ─────────────────────────────────────────────────────────────
/** _102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs.ts */
export function toMlsPath(project, level, folder, shortName, extension) {
    const folderPart = folder ? `${folder}/` : '';
    return `_${project}_/l${level}/${folderPart}${shortName}${extension}`;
}
// ─── project.json ─────────────────────────────────────────────────────────────
export async function readProjectJson() {
    try {
        const project = mls.actualProject || 0;
        const fileInfo = { project, level: 5, folder: '', shortName: 'project', extension: '.json' };
        const key = mls.stor.getKeyToFile(fileInfo);
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        const raw = await file.getContent();
        const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (!parsed || !Array.isArray(parsed.modules))
            return null;
        return parsed;
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] readProjectJson failed', err);
        return null;
    }
}
// ─── Scan ─────────────────────────────────────────────────────────────────────
const L1_LAYERS = ['layer_1_external', 'layer_4_entities', 'layer_3_usecases', 'layer_2_controllers'];
export function scanL1DefsFiles(project, moduleName) {
    const result = [];
    try {
        for (const layer of L1_LAYERS) {
            const folder = `${moduleName}/${layer}`;
            for (const f of Object.values(mls.stor.files)) {
                if (f.project !== project)
                    continue;
                if (f.level !== 1)
                    continue;
                if (f.folder !== folder)
                    continue;
                if (f.extension !== '.defs.ts')
                    continue;
                if (f.status === 'deleted')
                    continue;
                result.push({
                    project,
                    level: 1,
                    folder,
                    shortName: f.shortName,
                    moduleName,
                    mlsPath: toMlsPath(project, 1, folder, f.shortName, '.defs.ts'),
                });
            }
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] scanL1DefsFiles failed', err);
    }
    return result;
}
export async function scanL1DefsWithPipeline(project, moduleName) {
    const result = [];
    try {
        for (const layer of L1_LAYERS) {
            const folder = `${moduleName}/${layer}`;
            for (const f of Object.values(mls.stor.files)) {
                if (f.project !== project)
                    continue;
                if (f.level !== 1)
                    continue;
                if (f.folder !== folder)
                    continue;
                if (f.extension !== '.defs.ts')
                    continue;
                if (f.status === 'deleted')
                    continue;
                if (f.shortName === 'module' || f.shortName === 'index')
                    continue;
                const content = String(await f.getContent());
                const pipeline = parsePipelineFromContent(content);
                if (!pipeline || pipeline.length === 0)
                    continue;
                result.push({ folder, shortName: f.shortName, pipeline });
            }
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] scanL1DefsWithPipeline failed', err);
    }
    return result;
}
export function scanL2PageDefsFiles(project, moduleName) {
    const result = [];
    try {
        const SKIP = new Set(['layer_2_contracts', 'project']);
        for (const f of Object.values(mls.stor.files)) {
            if (f.project !== project)
                continue;
            if (f.level !== 2)
                continue;
            if (f.folder !== moduleName)
                continue;
            if (f.extension !== '.defs.ts')
                continue;
            if (f.status === 'deleted')
                continue;
            if (SKIP.has(f.shortName))
                continue;
            result.push({
                project,
                level: 2,
                folder: moduleName,
                shortName: f.shortName,
                moduleName,
                mlsPath: toMlsPath(project, 2, moduleName, f.shortName, '.defs.ts'),
            });
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] scanL2PageDefsFiles failed', err);
    }
    return result;
}
// ─── Dep layer listing ────────────────────────────────────────────────────────
// Returns the .defs.ts MLS paths for the dependency layer of a given L1 layer.
// Used to show the LLM what's available so it can decide which files to reference.
export function listDepLayerPaths(project, moduleName, forLayer) {
    const depLayer = {
        layer_4_entities: 'layer_1_external',
        layer_3_usecases: 'layer_4_entities',
        layer_2_controllers: 'layer_3_usecases',
    };
    const dep = depLayer[forLayer];
    if (!dep)
        return [];
    const folder = `${moduleName}/${dep}`;
    const result = [];
    try {
        for (const f of Object.values(mls.stor.files)) {
            if (f.project !== project)
                continue;
            if (f.level !== 1)
                continue;
            if (f.folder !== folder)
                continue;
            if (f.extension !== '.defs.ts')
                continue;
            if (f.status === 'deleted')
                continue;
            result.push(toMlsPath(project, 1, folder, f.shortName, '.defs.ts'));
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] listDepLayerPaths failed', err);
    }
    return result;
}
// ─── File content reader ──────────────────────────────────────────────────────
export async function getFileContent(project, level, folder, shortName, extension) {
    try {
        const fileInfo = { project, level, folder, shortName, extension };
        const key = mls.stor.getKeyToFile(fileInfo);
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        return String(await file.getContent());
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] getFileContent failed', err);
        return null;
    }
}
// ─── Append pipeline to existing .defs.ts ────────────────────────────────────
export async function appendPipelineToFile(project, level, folder, shortName, items) {
    try {
        const fileInfo = { project, level, folder, shortName, extension: '.defs.ts' };
        const key = mls.stor.getKeyToFile(fileInfo);
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return false;
        const existing = String(await file.getContent());
        if (existing.includes('export const pipeline'))
            return true; // already done
        const pipelineSrc = `\nexport const pipeline = ${JSON.stringify(items, null, 2)} as const;\n`;
        const newContent = existing.trimEnd() + '\n' + pipelineSrc;
        await mls.stor.localStor.setContent(file, { contentType: 'string', content: newContent });
        // Read-back verify
        const readBack = String(await file.getContent());
        return readBack.includes('export const pipeline');
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] appendPipelineToFile failed', err);
        return false;
    }
}
// ─── Create new .defs.ts file ─────────────────────────────────────────────────
export async function createDefsFile(project, level, folder, shortName, definitionJson, items) {
    try {
        const fileRef = toMlsPath(project, level, folder, shortName, '.defs.ts');
        const defStr = JSON.stringify(definitionJson, null, 2);
        const source = [
            `/// <mls fileReference="${fileRef}" enhancement="_blank"/>`,
            ``,
            `export const definition = \``,
            `## Definition`,
            '\\`\\`\\`JSON',
            defStr,
            '\\`\\`\\`',
            `\`;`,
            ``,
            `export const pipeline = ${JSON.stringify(items, null, 2)} as const;`,
            ``,
        ].join('\n');
        const fileInfo = { project, level, folder, shortName, extension: '.defs.ts' };
        const key = mls.stor.getKeyToFile(fileInfo);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            storFile = await createStorFile({ ...fileInfo, source }, false, false, false);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: source });
        // Read-back verify
        const readBack = String(await storFile.getContent());
        return readBack.includes('export const pipeline');
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] createDefsFile failed', err);
        return false;
    }
}
// ─── esbuild helpers (shared, used by agentMaterializeL2 and agentMaterializeGen) ──
export async function getEsbuild() {
    const w = window;
    const url = 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esm/browser.js';
    if (!w.__esbuildInstance)
        w.__esbuildInstance = import(url);
    const esbuild = await w.__esbuildInstance;
    if (!w.__esbuildReady) {
        w.__esbuildReady = esbuild.initialize({
            wasmURL: 'https://cdn.jsdelivr.net/npm/esbuild-wasm@0.25.4/esbuild.wasm',
        });
    }
    await w.__esbuildReady;
    return esbuild;
}
export async function loadModuleByBuild(path) {
    try {
        const info = mls.stor.convertFileReferenceToFile(path);
        if (!info)
            return null;
        const key = mls.stor.getKeyToFile(info);
        const sf = mls.stor.files[key];
        if (!sf)
            return null;
        const src = await sf.getContent();
        const esbuild = await getEsbuild();
        const result = await esbuild.transform(src, { loader: 'ts', format: 'esm', target: 'esnext' });
        const blob = new Blob([result.code], { type: 'text/javascript' });
        const blobUrl = URL.createObjectURL(blob);
        try {
            return await import(blobUrl);
        }
        finally {
            URL.revokeObjectURL(blobUrl);
        }
    }
    catch {
        return null;
    }
}
// ─── Fase 2: Generation helpers ──────────────────────────────────────────────
/** Extract the `pipeline` array from a .defs.ts content string. */
export function parsePipelineFromContent(content) {
    try {
        const match = content.match(/export\s+const\s+pipeline\s*=\s*([\s\S]*?)\s+as\s+const\s*;/);
        if (!match)
            return null;
        return JSON.parse(match[1]);
    }
    catch {
        return null;
    }
}
/** Extract the `definition` template literal value from a .defs.ts content string. */
export function parseDefinitionFromContent(content) {
    const match = content.match(/export\s+const\s+definition\s*=\s*`([\s\S]*?)`;/);
    return match ? match[1].trim() : content;
}
/**
 * Returns the updatedAt timestamp (ms) of a file, or a sentinel, or null.
 *
 * null              → file does not exist → needs generation
 * Number.MAX_SAFE_INTEGER → file exists, no timestamp, status 'new'|'changed'
 *                       → treat as very recent, DO NOT regenerate
 * null (second case) → file exists, no timestamp, other status
 *                       → cannot determine staleness, treat as missing → regenerate
 * >0                → normal timestamp comparison
 */
export function getFileModified(project, level, folder, shortName, extension) {
    try {
        const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension });
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        if (file.updatedAt)
            return Date.parse(file.updatedAt);
        const status = file.status;
        return (status === 'new' || status === 'changed') ? Number.MAX_SAFE_INTEGER : null;
    }
    catch {
        return null;
    }
}
/** Read any file by its full MLS path string. */
export async function getContentByMlsPath(mlsPath) {
    try {
        const info = mls.stor.convertFileReferenceToFile(mlsPath);
        const key = mls.stor.getKeyToFile(info);
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        return String(await file.getContent());
    }
    catch {
        return null;
    }
}
/** Parse a MLS path like `_102043_/l2/cafeFlow/web/contracts/page.defs.ts`. */
export function parseMlsPath(mlsPath) {
    const match = mlsPath.match(/^_(\d+)_\/l(\d+)\/(.+)$/);
    if (!match)
        return null;
    const project = parseInt(match[1], 10);
    const level = parseInt(match[2], 10);
    const rest = match[3];
    const lastSlash = rest.lastIndexOf('/');
    const folder = lastSlash >= 0 ? rest.slice(0, lastSlash) : '';
    const filename = lastSlash >= 0 ? rest.slice(lastSlash + 1) : rest;
    let shortName, extension;
    if (filename.endsWith('.defs.ts')) {
        shortName = filename.slice(0, -'.defs.ts'.length);
        extension = '.defs.ts';
    }
    else {
        const dot = filename.lastIndexOf('.');
        shortName = dot >= 0 ? filename.slice(0, dot) : filename;
        extension = dot >= 0 ? filename.slice(dot) : '';
    }
    return { project, level, folder, shortName, extension };
}
/**
 * Scan all l2 .defs.ts in sub-folders of a module that contain a pipeline export.
 * Excludes top-level source files (folder === moduleName).
 */
export async function scanL2DefsWithPipeline(project, moduleName) {
    const result = [];
    try {
        const prefix = moduleName + '/';
        for (const f of Object.values(mls.stor.files)) {
            if (f.project !== project)
                continue;
            if (f.level !== 2)
                continue;
            if (f.extension !== '.defs.ts')
                continue;
            if (f.status === 'deleted')
                continue;
            if (f.shortName === 'module' || f.shortName === 'index')
                continue;
            const folder = f.folder;
            if (folder === moduleName)
                continue;
            if (!folder.startsWith(prefix))
                continue;
            const content = String(await f.getContent());
            const pipeline = parsePipelineFromContent(content);
            if (!pipeline || pipeline.length === 0)
                continue;
            result.push({ project, level: 2, folder, shortName: f.shortName, pipeline });
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] scanL2DefsWithPipeline failed', err);
    }
    return result;
}
/** Save (create or overwrite) a generated .ts file. */
export async function saveGeneratedTs(project, level, folder, shortName, content) {
    try {
        const fileInfo = { project, level, folder, shortName, extension: '.ts' };
        const key = mls.stor.getKeyToFile(fileInfo);
        let file = mls.stor.files[key];
        if (!file) {
            file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
        }
        else {
            const model = await file.getOrCreateModel();
            if (model)
                model.model.setValue(content);
        }
        await mls.stor.localStor.setContent(file, { contentType: 'string', content });
        return true;
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] saveGeneratedTs failed', err);
        return false;
    }
}
/**
 * Load rules.defs.ts for a module, filter by ruleIds and return the matched rule objects.
 * File: _<project>_/l5/<moduleName>/rules.defs.ts — exports `rulesPlan` with `data.rules[]`.
 */
export async function loadRulesForIds(project, moduleName, ruleIds) {
    if (!ruleIds.length)
        return [];
    const path = toMlsPath(project, 5, moduleName, 'rules', '.defs.ts');
    const content = await getContentByMlsPath(path);
    if (!content)
        return [];
    try {
        const match = content.match(/export\s+const\s+rulesPlan\s*=\s*([\s\S]*?)\s+as\s+const\s*;/);
        if (!match)
            return [];
        const plan = JSON.parse(match[1]);
        const allRules = plan?.data?.rules ?? [];
        return allRules.filter(r => ruleIds.includes(r['ruleId']));
    }
    catch {
        return [];
    }
}
/** Extract all unique string values from every JSON array field named `fieldName` in `content`. */
export function extractJsonArrayField(content, fieldName) {
    const vals = new Set();
    const blockRe = new RegExp(`"${fieldName}"\\s*:\\s*\\[([\\s\\S]*?)\\]`, 'g');
    let block;
    while ((block = blockRe.exec(content)) !== null) {
        const valRe = /"([^"]+)"/g;
        let val;
        while ((val = valRe.exec(block[1])) !== null)
            vals.add(val[1]);
    }
    return [...vals];
}
export async function saveGeneratedJson(project, level, folder, shortName, content) {
    try {
        const fileInfo = { project, level, folder, shortName, extension: '.json' };
        const key = mls.stor.getKeyToFile(fileInfo);
        let file = mls.stor.files[key];
        if (!file) {
            file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
        }
        await mls.stor.localStor.setContent(file, { contentType: 'string', content });
        return true;
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] saveGeneratedJson failed', err);
        return false;
    }
}
export async function saveGeneratedHtml(project, level, folder, shortName, content) {
    try {
        const fileInfo = { project, level, folder, shortName, extension: '.html' };
        const key = mls.stor.getKeyToFile(fileInfo);
        let file = mls.stor.files[key];
        if (!file) {
            file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
        }
        await mls.stor.localStor.setContent(file, { contentType: 'string', content });
        return true;
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] saveGeneratedHtml failed', err);
        return false;
    }
}
/**
 * Returns the first-level import paths from compilerResults.imports for a .ts file,
 * filtered to imports belonging to the same project.
 */
export function getFileImports(project, level, folder, shortName) {
    try {
        const key = mls.editor.getKeyModel(project, shortName, folder, level);
        const imports = mls.editor.models[key]?.ts?.compilerResults?.imports ?? [];
        return imports
            .map(imp => imp.startsWith('/') ? imp.slice(1) : imp)
            .filter((imp) => {
            const parsed = parseMlsPath(imp);
            return parsed !== null && parsed.project === project;
        });
    }
    catch {
        return [];
    }
}
/**
 * Returns the .d.ts declaration for a .ts file.
 * Tries prodDTS from the editor model (compiling on demand if needed).
 * Falls back to raw .ts content if no model is available or compile fails.
 */
export async function getDtsForFile(project, level, folder, shortName) {
    try {
        const key = mls.editor.getKeyModel(project, shortName, folder, level);
        let modelTS = mls.editor.models[key]?.ts;
        if (!modelTS) {
            const iModels = await mls.editor.addModels(project, shortName, folder, level);
            modelTS = iModels?.ts;
        }
        if (modelTS) {
            if (!modelTS.compilerResults?.prodDTS) {
                await mls.l2.typescript.compile(modelTS);
            }
            const dts = modelTS.compilerResults?.prodDTS;
            if (dts)
                return dts;
        }
    }
    catch (err) {
        console.warn('[agentMaterializeArtifacts] getDtsForFile compile failed, falling back', err);
    }
    return await getContentByMlsPath(toMlsPath(project, level, folder, shortName, '.ts')) ?? '';
}
// ─── Tool call payload extractor ─────────────────────────────────────────────
export function extractToolCallArgs(raw, toolName) {
    const v = parseMaybeJson(raw);
    if (!isRecord(v))
        return null;
    if (v.toolName === toolName) {
        const args = parseMaybeJson(v.arguments);
        return isRecord(args) ? args : null;
    }
    if (v.type === 'flexible' && v.result !== undefined) {
        const result = parseMaybeJson(v.result);
        if (isRecord(result) && result.toolName === toolName) {
            const args = parseMaybeJson(result.arguments);
            return isRecord(args) ? args : null;
        }
    }
    if (Array.isArray(v.tool_calls)) {
        const call = v.tool_calls.find((item) => isRecord(item) && isRecord(item.function) && item.function.name === toolName);
        if (isRecord(call)) {
            const fn = call.function;
            const args = parseMaybeJson(fn.arguments);
            return isRecord(args) ? args : null;
        }
    }
    return null;
}
function parseMaybeJson(raw) {
    if (typeof raw !== 'string')
        return raw;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
function isRecord(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
