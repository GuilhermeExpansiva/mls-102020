/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentL2MaterializePageLit.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { convertFileNameToTag, convertTagToFileName } from '/_102027_/l2/utils.js';
import { getMaterializeOrchestrator } from '/_102020_/l2/agentMaterializeSolution/materializeOrchestrator.js';
import { addModuleNav, addModuleRoute } from '/_102020_/l2/agentMaterializeSolution/ast/astModuleFront.js';
import { addNav, addPage } from '/_102020_/l2/agentMaterializeSolution/ast/astIndex.js';
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { collabImport } from '/_102027_/l2/collabImport.js';
// ─── mutex ────────────────────────────────────────────────────────────────────
const _lockQueue = new Map();
async function withLock(key, fn) {
    const prev = _lockQueue.get(key) ?? Promise.resolve();
    let resolve;
    _lockQueue.set(key, new Promise(r => { resolve = r; }));
    await prev;
    try {
        return await fn();
    }
    finally {
        resolve();
    }
}
export function createAgent() {
    return {
        agentName: "agentL2MaterializePageLit",
        agentProject: 102020,
        agentFolder: "agentMaterializeSolution",
        agentDescription: "new agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const info = JSON.parse(userPrompt);
    const moduleName = info.moduleName || context.task?.iaCompressed?.longMemory['moduleName'];
    const device = info.device || context.task?.iaCompressed?.longMemory['device'] || 'web';
    const type = info.type || context.task?.iaCompressed?.longMemory['type'] || 'page11';
    info.project = mls.actualProject || 0;
    if (info.pathDefs) {
        const pageId = info.pathDefs.replace(/^\/+/, '').split('/').pop()?.replace(/\.defs\.ts$|\.ts$/, '') || '';
        info.path = info.pathDefs;
        info.item = { id: 'page', agent: agent.agentName, defsPath: info.pathDefs, outputPath: `${pageId}.ts`, dependsOn: [], moduleName };
    }
    else {
        const orch = getMaterializeOrchestrator(info.path);
        info.item = await orch.getToExecuteOnlyMaterialize(info.id);
    }
    const prompt = await getSkill(info, moduleName, device, type);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: system1 },
                { type: 'human', content: prompt }
            ],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: info.path,
            longTermMemory: { moduleName: info.moduleName, device, type, onlyStep: "true" }
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    console.info('--------agentL2MaterializePageLit--------');
    const info = JSON.parse(args);
    info.project = mls.actualProject || 0;
    const moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    const device = context.task?.iaCompressed?.longMemory['device'] || 'web';
    const type = context.task?.iaCompressed?.longMemory['type'] || 'page11';
    const prompt = await getSkill(info, moduleName, device, type);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: prompt,
        systemPrompt: system1
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`(${agent.agentName}) [afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output, agent, parentStep);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output, agent, parentStep) {
    const onlyThisStep = (context.task?.iaCompressed?.longMemory['onlyStep'] || 'false') === 'true';
    output.outputPath = output.outputPath.startsWith('/') ? output.outputPath.slice(1) : output.outputPath;
    const orch = getMaterializeOrchestrator(output.path);
    await orch.createStorFile(output.outputPath, parseAISource(output.srcFile));
    const info = mls.stor.convertFileReferenceToFile(output.outputPath);
    if (info.project === 0)
        info.project = mls.actualProject || 0;
    const tag = convertFileNameToTag(info);
    const srcHtml = `<${tag}></${tag}>`;
    await orch.createStorFile(output.outputPath.replace('.ts', '.html'), srcHtml);
    const moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    await withLock(`module:${moduleName}`, () => addModuleRoutes(context, info.shortName, tag));
    await withLock(`index:${moduleName}`, () => addIndexPage(context, info.shortName, tag));
    const stepOri = parentStep.stepId; //context.task ? (findPreviousAgentStep(context.task, parentStep.stepId))?.stepId : parentStep.stepId;
    const newSteps = [];
    if (!onlyThisStep) {
        const group = await orch.processGroup(output.id);
        Object.keys(group).forEach((g) => {
            const info = group[g];
            info.forEach((i) => {
                const newStep = {
                    type: "add-step",
                    messageId: context.message.orderAt,
                    threadId: context.message.threadId,
                    taskId: context.task?.PK || '',
                    parentStepId: stepOri || parentStep.stepId,
                    step: {
                        type: 'agent',
                        stepId: 0,
                        interaction: null,
                        status: 'waiting_human_input',
                        nextSteps: [],
                        agentName: g,
                        prompt: JSON.stringify({ path: output.path, item: i }),
                        rags: [],
                    }
                };
                newSteps.push(newStep);
            });
        });
    }
    return newSteps;
}
async function addModuleRoutes(context, shortName, tag) {
    let moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!moduleName)
        throw new Error('Not found moduleName 2: agentL2MaterializePageLit');
    const key = mls.stor.getKeyToFile({ project: mls.actualProject || 0, level: 2, folder: `${moduleName}`, shortName: "module", extension: ".ts" });
    if (!mls.stor.files[key]) {
        await generateInfoModule(moduleName);
        if (!mls.stor.files[key])
            throw new Error('[agentL2MaterializePageLit]Not found module file');
    }
    const info = convertTagToFileName(tag);
    info.extension = '.js';
    info.level = 2;
    let fileReference = mls.stor.convertFileToFileReference(info);
    fileReference = fileReference.startsWith('/') ? fileReference : '/' + fileReference;
    const sf = mls.stor.files[key];
    let src = await sf.getContent();
    src = addModuleNav(src, { id: shortName, label: shortName, href: `/${moduleName}/${shortName}`, description: shortName });
    src = addModuleRoute(src, {
        path: `/${moduleName}/${shortName}`,
        aliases: [],
        entrypoint: fileReference.replace('.ts', '.js'),
        tag,
        title: shortName,
    });
    await saveFile(mls.stor.convertFileToFileReference(sf), src);
}
async function addIndexPage(context, shortName, tag) {
    let moduleName = context.task?.iaCompressed?.longMemory['moduleName'];
    if (!moduleName)
        throw new Error('Not found moduleName 3: agentL2MaterializePageLit');
    const key = mls.stor.getKeyToFile({ project: mls.actualProject || 0, level: 2, folder: `${moduleName}`, shortName: "index", extension: ".ts" });
    if (!mls.stor.files[key]) {
        await generateHtml(moduleName);
        if (!mls.stor.files[key])
            throw new Error('[agentL2MaterializePageLit] Not found index file after generate');
    }
    ;
    const info = convertTagToFileName(tag);
    info.extension = '.js';
    info.level = 2;
    let fileReference = mls.stor.convertFileToFileReference(info);
    fileReference = fileReference.startsWith('/') ? fileReference : '/' + fileReference;
    const sf = mls.stor.files[key];
    let src = await sf.getContent();
    src = addNav(src, { label: shortName, href: `/${moduleName}/${shortName}` });
    src = addPage(src, {
        path: `/${moduleName}/${shortName}`,
        title: shortName,
        tagName: tag,
        loader: fileReference,
    });
    await saveFile(mls.stor.convertFileToFileReference(sf), src);
}
async function saveFile(ref, src) {
    const info = mls.stor.convertFileReferenceToFile(ref);
    const k = mls.stor.getKeyToFile(info);
    let sf = mls.stor.files[k];
    if (!sf) {
        const param = {
            ...info,
            source: src
        };
        sf = await createStorFile(param, true, true, true);
    }
    else {
        const m = await sf.getOrCreateModel();
        if (m && m.model)
            m.model.setValue(src);
    }
    await mls.stor.localStor.setContent(sf, { contentType: 'string', content: src });
}
async function getSkill(info, moduleName, device, type) {
    const project = info.project || 0;
    const pt = `_${project}_/l2/${moduleName}/module.ts`;
    const params = mls.stor.convertFileReferenceToFile(pt);
    const mod = await collabImport(params);
    //const mod = await import(`/_${project}_/l2/${moduleName}/module.js`) as any;
    if (!mod || !mod.moduleGenome)
        throw new Error('[agentL2MaterializePageLit] Not found moduleGenome');
    const genomeKey = Object.keys(mod.moduleGenome).find(k => k.startsWith(`${device}/`) && k.endsWith(`/${type}`));
    if (!genomeKey)
        throw new Error(`[agentL2MaterializePageLit] no genome key found for device "${device}" and type "${type}"`);
    const genome = mod.moduleGenome[genomeKey];
    if (!genome)
        throw new Error(`[agentL2MaterializePageLit] no genome config for key "${genomeKey}"`);
    /*const prj = await import(`/_${project}_/l2/project.js`) as any;
    if (!prj || !prj.projectConfig) throw new Error('[agentL2MaterializePageLit] Not found projectConfig');*/
    const prj = await getConfigProject(mls.actualProject || 0);
    if (!prj)
        throw new Error('[agentL2MaterializePageLit] Not found projectConfig');
    if (!prj.layouts)
        throw new Error('[agentL2MaterializePageLit] Not found projectConfig layout dont config');
    const layout = Object.values(prj.layouts).find((v) => v.name === genome.layout);
    if (!layout)
        throw new Error('[agentL2MaterializePageLit] Not found projectConfig layout dont config to:' + genome.layout);
    const designSystem = Object.values(prj.designSystems).find((ds) => ds.name === genome.designSystem);
    if (!designSystem)
        throw new Error('[agentL2MaterializePageLit] Not found projectConfig designSystem dont config to:' + genome.designSystem);
    const fileName = info.item.outputPath.startsWith('/') ? info.item.outputPath.slice(1) : info.item.outputPath;
    const genomeKeyNorm = genomeKey.endsWith('/') ? genomeKey.slice(0, -1) : genomeKey;
    info.item.outputPath = `_${project}_/l2/${moduleName}/${genomeKeyNorm}/${fileName}`;
    const pathSkill = (layout.skill.startsWith('/') ? layout.skill.slice(1) : layout.skill).replace('.js', '.ts');
    const pathDS = (designSystem.skill.startsWith('/') ? designSystem.skill.slice(1) : designSystem.skill).replace('.js', '.ts');
    const orch = getMaterializeOrchestrator(info.path);
    const user = await orch.getVar(info.item.defsPath, 'skill');
    const skill = await orch.getSkill(pathSkill);
    const dsSkill = await orch.getSkill(pathDS);
    const designSystemSection = dsSkill ? `\n\n##Design System\n${dsSkill}` : '';
    const prompt = `##Skill\n${skill}${designSystemSection}\n\n##User data\n${user}\n\n##User info\n${JSON.stringify(info)}`;
    return prompt;
}
function parseAISource(raw) {
    return raw;
    decodeUnicodeEscapes(raw);
}
function decodeUnicodeEscapes(src) {
    return src.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}
async function generateHtml(moduleName) {
    const srcHtml = `<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Collab Test ${moduleName}</title>
    <link rel="manifest" href="/${moduleName}/assets/manifest.json" />
  </head>
  <body>
    <collab-app-shell></collab-app-shell>
    <script type="module" src="/_${mls.actualProject}_/l2/${moduleName}/index.js"></script>
  </body>
</html>
`;
    const srcTS = `/// <mls fileReference="_${mls.actualProject}_/l2/${moduleName}/index.ts" enhancement="_blank" />
import { bootstrapCollabApp } from '/_102033_/l2/core/bootstrap.js';

void bootstrapCollabApp({
  projectId: '${mls.actualProject}',
  appId: '${moduleName}',
  title: 'Collab Test · ${moduleName}',
  shellMode: 'spa',
  navigation: [
    { label: 'Monitor', href: '/monitor' },
  ],
  pages: [],
});
`;
    await saveFile(`_${mls.actualProject}_/l2/${moduleName}/index.html`, srcHtml);
    await saveFile(`_${mls.actualProject}_/l2/${moduleName}/index.ts`, srcTS);
}
async function generateInfoModule(moduleName) {
    const src = `/// <mls fileReference="_${mls.actualProject}_/l2/${moduleName}/module.ts" enhancement="_blank" />
import type { AuraModuleFrontendDefinition, IPaths, IGenomeConfig } from '/_102029_/l2/contracts/bootstrap.js';

export const moduleGenome: Record<string, IGenomeConfig> = {
  'web/desktop/page11': {
    designSystem: 'default',
    device: 'desktop',
    layout: 'standard',
  }
} as const;
  
export const skills: IPaths = {
  web: {
    sharedPath: '/_${mls.actualProject}_/l2/${moduleName}/web/shared',
    sharedSkill: '/_102020_/l2/agents/newModule/skills/genPageShared.ts'
  }
}

export const moduleStates = {
} as const;

export const moduleShellPreferences = {
  layout: {
    asideMode: {
      desktop: 'inline',
      mobile: 'fullscreen',
    },
  },
} as const;

export const moduleFrontendDefinition: AuraModuleFrontendDefinition = {
  pageTitle: '${moduleName}',
  device: 'desktop',
  navigation: [
  ],
  routes: [
  ],
};
`;
    await saveFile(`_${mls.actualProject}_/l2/${moduleName}/module.ts`, src);
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You must return ONLY a valid JSON object. No preamble, no explanation, no markdown
fences, no text before or after the JSON. Start your response with { and end with }


## Output format
The srcFile value must be a single-line JSON string.
Escape ALL special characters inside it:
  - newlines     → \n
  - tabs         → \t
  - double quotes → \"
  - backslashes  → \\
Never embed raw multiline code blocks inside a JSON string value.

Return strictly this structure:

export type Output =
  {
    type: "flexible";
    result: {
      path: string; // same value by "User info";
      id: string; // same value by "User info";
      outputPath: string, // same value by "User info";
      srcFile: string
    }
  }

`;
//#endregion 
