/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializePages.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
export function createAgent() {
    return {
        agentName: 'agentMaterializePages',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Find all .defs.ts files in a module and trigger agentL2MaterializeDefinition for each',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
function parseInput(raw) {
    const trimmed = raw.trim();
    if (trimmed.startsWith('{')) {
        const parsed = JSON.parse(trimmed);
        const moduleName = parsed['moduleName'];
        if (typeof moduleName !== 'string' || !moduleName)
            throw new Error('[agentMaterializePages] missing "moduleName"');
        return { moduleName };
    }
    const line = trimmed.split(/[\n\r]+/).map(s => s.trim()).filter(Boolean)[0];
    if (!line)
        throw new Error('[agentMaterializePages] moduleName is required');
    return { moduleName: line };
}
// ─── file scanner ─────────────────────────────────────────────────────────────
function scanDefsFiles(moduleName) {
    const files = mls.stor.files;
    const paths = [];
    for (const key of Object.keys(files)) {
        const file = files[key];
        if (file.level === 2 && file.extension === '.defs.ts' && file.folder === moduleName && file.project === mls.actualProject && !['module', 'index'].includes(file.shortName)) {
            paths.push(`_${file.project}_/l2/${file.folder}/${file.shortName}${file.extension}`);
        }
    }
    return paths;
}
// ─── beforePromptImplicit ─────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    const { moduleName } = parseInput(userPrompt);
    const defsPaths = scanDefsFiles(moduleName);
    if (defsPaths.length === 0)
        throw new Error(`[agentMaterializePages] no .defs.ts files found for module: ${moduleName}`);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: JSON.stringify({ moduleName, defsPaths }) },
            ],
            taskTitle: `materialize-pages:${moduleName}`,
            threadId: context.message.threadId,
            userMessage: userPrompt,
            longTermMemory: { moduleName },
        },
    };
    return [addMessageAI];
}
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(agent, context, parentStep, _step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args is required`);
    const { moduleName } = parseInput(args);
    const defsPaths = scanDefsFiles(moduleName);
    const promptReady = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: JSON.stringify({ moduleName, defsPaths }),
        systemPrompt,
    };
    return [promptReady];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName})[afterPromptStep] invalid params`);
    let status = 'completed';
    const newSteps = [];
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status,
    };
    try {
        const payload = step.interaction?.payload?.[0];
        const moduleName = (payload?.type === 'flexible' ? payload.result?.moduleName : '');
        if (!moduleName)
            throw new Error('[agentMaterializePages] missing moduleName in step payload');
        const defsPaths = scanDefsFiles(moduleName);
        if (defsPaths.length === 0)
            throw new Error(`[agentMaterializePages] no .defs.ts files found for module: ${moduleName}`);
        for (const path of defsPaths) {
            const f = mls.stor.convertFileReferenceToFile(path);
            const newStep = {
                type: 'add-step',
                messageId: context.message.orderAt,
                threadId: context.message.threadId,
                taskId: context.task?.PK || '',
                parentStepId: parentStep.stepId,
                stepTitle: 'Defining page:' + f.shortName,
                step: {
                    type: 'agent',
                    stepId: 0,
                    interaction: null,
                    status: 'waiting_human_input',
                    nextSteps: [],
                    agentName: 'agentMaterializePageDef',
                    prompt: JSON.stringify({ moduleName, path }),
                    stepTitle: 'Defining page:' + f.shortName,
                    rags: [],
                },
            };
            newSteps.push(newStep);
        }
    }
    catch (err) {
        updateStatus.status = 'failed';
        console.error(`[agentMaterializePages](afterPromptStep)`, err);
        return [updateStatus];
    }
    return [...newSteps, updateStatus];
}
// ─── system prompt ────────────────────────────────────────────────────────────
const systemPrompt = `
<!-- modelType: nano -->

Return the same content passed.

## Output format
Return ONLY valid JSON, no markdown fences, no prose.

{
  "type": "flexible",
  "result": {
    "moduleName": "<echo moduleName>",
    "defsPaths": ["<echo each path from defsPaths array>"]
  }
}
`;
//#endregion
