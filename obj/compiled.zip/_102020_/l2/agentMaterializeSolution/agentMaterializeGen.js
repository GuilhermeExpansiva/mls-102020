/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeGen.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { collabImport } from '/_102027_/l2/collabImport.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { getContentByMlsPath, parseDefinitionFromContent, parseMlsPath, saveGeneratedTs, saveGeneratedHtml, extractToolCallArgs, loadModuleByBuild, loadRulesForIds, } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentMaterializeGen',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Generate a .ts file from a .defs.ts pipeline item using the resolved skill',
        visibility: 'private',
        beforePromptStep,
        afterPromptStep,
    };
}
const TOOL_NAME = 'submitGeneratedTs';
const toolSchema = {
    type: 'function',
    function: {
        name: TOOL_NAME,
        description: 'Submit the complete generated TypeScript file content.',
        parameters: {
            type: 'object',
            additionalProperties: false,
            required: ['code'],
            properties: {
                code: {
                    type: 'string',
                    description: 'Complete TypeScript file content. Must start with the /// <mls fileReference="..."> header comment.',
                },
            },
        },
    },
};
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(_agent, context, parentStep, _step, hookSequential, args) {
    if (!args)
        throw new Error('[agentMaterializeGen] missing args');
    const { defPath, pipelineItem, skillPaths } = JSON.parse(args);
    // Read .defs.ts and extract definition
    const defsContent = await getContentByMlsPath(defPath);
    if (!defsContent)
        throw new Error(`[agentMaterializeGen] .defs.ts not found: ${defPath}`);
    const definition = parseDefinitionFromContent(defsContent);
    // Load full rule definitions when rulesApplied is populated
    let resolvedRules = [];
    if (pipelineItem.rulesApplied?.length) {
        const parsed = parseMlsPath(defPath);
        if (parsed) {
            const moduleName = parsed.folder.split('/')[0];
            resolvedRules = await loadRulesForIds(parsed.project, moduleName, pipelineItem.rulesApplied);
        }
    }
    // Load skill content — .ts/.md paths go to system prompt; project refs (_digits_) go to context
    const skillSections = [];
    const defContextSections = [];
    for (const sp of skillPaths) {
        const clean = sp.startsWith('/') ? sp.slice(1) : sp;
        if (/^_\d+_$/.test(clean)) {
            const content = await loadProjectDefinition(clean);
            if (content)
                defContextSections.push(`### Project Definition (${clean})\n\`\`\`typescript\n${content}\n\`\`\``);
        }
        else {
            const content = await loadSkillContent(sp);
            if (content)
                skillSections.push(`<!-- skill: ${sp} -->\n${content}`);
        }
    }
    // Load dependsFiles as context
    const depSections = [];
    for (const dep of pipelineItem.dependsFiles) {
        const content = await getContentByMlsPath(dep);
        if (content)
            depSections.push(`### ${dep}\n\`\`\`typescript\n${content}\n\`\`\``);
    }
    const contextSections = [...defContextSections, ...depSections];
    const intent = {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt: buildSystemPrompt(skillSections, pipelineItem.outputPath),
        humanPrompt: buildHumanPrompt(definition, contextSections, pipelineItem.outputPath, resolvedRules),
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: TOOL_NAME } },
    };
    return [intent];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    const { pipelineItem, fileType } = JSON.parse(step.prompt || '{}');
    const raw = step.interaction?.payload?.[0];
    const out = extractToolCallArgs(raw, TOOL_NAME);
    if (!out?.code) {
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', 'missing generated code')];
    }
    const parsed = parseMlsPath(pipelineItem.outputPath);
    if (!parsed) {
        return [mkStatus(context, parentStep, step, hookSequential, 'failed', `invalid outputPath: ${pipelineItem.outputPath}`)];
    }
    // Ensure fileReference header is present
    const header = `/// <mls fileReference="${pipelineItem.outputPath}" enhancement="_blank"/>`;
    const code = out.code.trimStart().startsWith('///')
        ? out.code
        : `${header}\n\n${out.code}`;
    const ok = await saveGeneratedTs(parsed.project, parsed.level, parsed.folder, parsed.shortName, code);
    // Pages also need a companion .html file with the web component tag
    if (ok && fileType === 'page') {
        const tag = convertFileNameToTag({ shortName: parsed.shortName, project: parsed.project, folder: parsed.folder });
        await saveGeneratedHtml(parsed.project, parsed.level, parsed.folder, parsed.shortName, `<${tag}></${tag}>`);
    }
    return [mkStatus(context, parentStep, step, hookSequential, ok ? 'completed' : 'failed', ok ? undefined : 'saveGeneratedTs failed', ok ? 'input_output' : undefined)];
}
// ─── Skill loader ─────────────────────────────────────────────────────────────
/** Fetches the TypeScript content of a project definition reference (e.g. '_102034_'). */
async function loadProjectDefinition(projectRef) {
    const models = mls.editor?.models;
    if (!models?.[projectRef])
        return '';
    if (!models[projectRef].ts)
        return '';
    return models[projectRef].ts.model?.getValue?.() ?? '';
}
async function loadSkillContent(skillPath) {
    const clean = skillPath.startsWith('/') ? skillPath.slice(1) : skillPath;
    if (clean.endsWith('.md')) {
        return await getContentByMlsPath(clean) ?? '';
    }
    // .ts skill: try collabImport → read .skill export
    const f = mls.stor.convertFileReferenceToFile(clean);
    if (!f)
        return '';
    let mod;
    try {
        mod = await collabImport(f);
    }
    catch {
        mod = await loadModuleByBuild(clean);
    }
    if (typeof mod?.skill === 'string')
        return mod.skill;
    // Last resort: raw file content
    return await getContentByMlsPath(clean) ?? '';
}
// ─── Helpers ──────────────────────────────────────────────────────────────────
function mkStatus(context, parentStep, step, hookSequential, status, traceMsg, cleaner) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
        cleaner,
    };
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
function buildSystemPrompt(skillSections, outputPath) {
    const skills = skillSections.length
        ? skillSections.join('\n\n---\n\n')
        : '<!-- no skill loaded -->';
    return `<!-- modelType: codeinstruct -->

You generate a TypeScript file based on a definition and context files.

Target file: ${outputPath}

The file must start with:
/// <mls fileReference="${outputPath}" enhancement="_blank"/>

Follow the instructions in the skill(s) below exactly.
Use the context files (dependsFiles) as reference for types, imports and logic.

---

${skills}`;
}
function buildHumanPrompt(definition, depSections, outputPath, resolvedRules) {
    const lines = ['## Definition', '', definition];
    if (resolvedRules && resolvedRules.length > 0) {
        lines.push('', '## Business Rules', '');
        lines.push('```json');
        lines.push(JSON.stringify(resolvedRules, null, 2));
        lines.push('```');
    }
    if (depSections.length) {
        lines.push('', '## Context Files', '');
        lines.push(...depSections);
    }
    lines.push('', `Generate the file \`${outputPath}\` and call ${TOOL_NAME} with the complete code.`);
    return lines.join('\n');
}
