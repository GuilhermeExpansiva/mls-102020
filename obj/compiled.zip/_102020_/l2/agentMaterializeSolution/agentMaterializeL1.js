/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeL1.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { collabImport } from '/_102027_/l2/collabImport.js';
import { readProjectJson, scanL1DefsWithPipeline, getFileModified, toMlsPath, loadModuleByBuild, } from '/_102020_/l2/agentMaterializeSolution/agentMaterializeArtifacts.js';
export function createAgent() {
    return {
        agentName: 'agentMaterializeL1',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Generate L1 .ts files from .defs.ts pipeline definitions',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
// ─── Bootstrap ────────────────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, _userPrompt) {
    const project = mls.actualProject || 0;
    const projectJson = await readProjectJson();
    if (!projectJson?.modules?.length) {
        throw new Error('[agentMaterializeL1] l5/project.json not found or empty');
    }
    const summaries = [];
    for (const mod of projectJson.modules) {
        const candidates = await findCandidates(project, mod.moduleName);
        const byType = groupByType(candidates, mod.moduleName);
        summaries.push({
            moduleName: mod.moduleName,
            layer1: byType.layer1.length,
            layer4: byType.layer4.length,
            layer3: byType.layer3.length,
            layer2: byType.layer2.length,
        });
    }
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: buildHumanPrompt(summaries) },
            ],
            taskTitle: 'materialize-l1',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'materialize-l1', flowName: 'materialize-l1' },
        },
    };
    return [addMessageAI];
}
// ─── After LLM confirms — create all generation steps ────────────────────────
async function afterPromptStep(_agent, context, _parentStep, step, hookSequential) {
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('[agentMaterializeL1] missing payload');
        if (payload.type === 'result') {
            return [mkFail(context, _parentStep, step, hookSequential, String(payload.result))];
        }
        if (payload.type !== 'flexible' || payload.result?.status === 'failed') {
            return [mkFail(context, _parentStep, step, hookSequential, payload.result?.notes?.join('; ') || 'scan failed')];
        }
        const project = mls.actualProject || 0;
        const projectJson = await readProjectJson();
        if (!projectJson)
            throw new Error('[agentMaterializeL1] project.json unavailable');
        const intents = [];
        for (const mod of projectJson.modules) {
            const { moduleName } = mod;
            const moduleExports = await loadModuleExports(project, moduleName);
            const candidates = await findCandidates(project, moduleName);
            const byType = groupByType(candidates, moduleName);
            // Pre-compute planId arrays — used as group barriers
            const layer1PlanIds = byType.layer1.map(c => makePlanId(moduleName, c.shortName, 'layer1'));
            const layer4PlanIds = byType.layer4.map(c => makePlanId(moduleName, c.shortName, 'layer4'));
            const layer3PlanIds = byType.layer3.map(c => makePlanId(moduleName, c.shortName, 'layer3'));
            // Group 1: layer_1_external — start immediately
            for (const c of byType.layer1) {
                const planId = makePlanId(moduleName, c.shortName, 'layer1');
                const defPath = toMlsPath(project, 1, c.folder, c.shortName, '.defs.ts');
                const args = { planId, defPath, pipelineItem: c.pipeline[0], skillPaths: resolveSkillPaths('layer1', moduleExports), fileType: 'layer1' };
                intents.push(mkStep(context, step, planId, `Gen layer1: ${moduleName}/${c.shortName}`, args, [], 'waiting_human_input'));
            }
            // Group 2: layer_4_entities — wait for ALL layer1
            const dep4 = layer1PlanIds.length > 0 ? layer1PlanIds : [];
            for (const c of byType.layer4) {
                const planId = makePlanId(moduleName, c.shortName, 'layer4');
                const defPath = toMlsPath(project, 1, c.folder, c.shortName, '.defs.ts');
                const args = { planId, defPath, pipelineItem: c.pipeline[0], skillPaths: resolveSkillPaths('layer4', moduleExports), fileType: 'layer4' };
                const status = dep4.length > 0 ? 'waiting_dependency' : 'waiting_human_input';
                intents.push(mkStep(context, step, planId, `Gen layer4: ${moduleName}/${c.shortName}`, args, dep4, status));
            }
            // Group 3: layer_3_usecases — wait for ALL layer4 (fallback layer1)
            const dep3 = layer4PlanIds.length > 0 ? layer4PlanIds : layer1PlanIds;
            for (const c of byType.layer3) {
                const planId = makePlanId(moduleName, c.shortName, 'layer3');
                const defPath = toMlsPath(project, 1, c.folder, c.shortName, '.defs.ts');
                const args = { planId, defPath, pipelineItem: c.pipeline[0], skillPaths: resolveSkillPaths('layer3', moduleExports), fileType: 'layer3' };
                const status = dep3.length > 0 ? 'waiting_dependency' : 'waiting_human_input';
                intents.push(mkStep(context, step, planId, `Gen layer3: ${moduleName}/${c.shortName}`, args, dep3, status));
            }
            // Group 4: layer_2_controllers — wait for ALL layer3 (fallback layer4)
            const dep2 = layer3PlanIds.length > 0 ? layer3PlanIds : layer4PlanIds;
            for (const c of byType.layer2) {
                const planId = makePlanId(moduleName, c.shortName, 'layer2');
                const defPath = toMlsPath(project, 1, c.folder, c.shortName, '.defs.ts');
                const args = { planId, defPath, pipelineItem: c.pipeline[0], skillPaths: resolveSkillPaths('layer2', moduleExports), fileType: 'layer2' };
                const status = dep2.length > 0 ? 'waiting_dependency' : 'waiting_human_input';
                intents.push(mkStep(context, step, planId, `Gen layer2: ${moduleName}/${c.shortName}`, args, dep2, status));
            }
        }
        return intents;
    }
    catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return [mkFail(context, _parentStep, step, hookSequential, msg)];
    }
}
// ─── Candidate detection ──────────────────────────────────────────────────────
async function findCandidates(project, moduleName) {
    const all = await scanL1DefsWithPipeline(project, moduleName);
    return all.filter(({ folder, shortName }) => {
        const defMod = getFileModified(project, 1, folder, shortName, '.defs.ts');
        const tsMod = getFileModified(project, 1, folder, shortName, '.ts');
        if (tsMod === null)
            return true;
        if (defMod === null)
            return false;
        return defMod > tsMod;
    });
}
function groupByType(candidates, moduleName) {
    const result = { layer1: [], layer4: [], layer3: [], layer2: [], rulesApplied: [] };
    for (const c of candidates) {
        const ft = detectFileType(c.folder, moduleName);
        if (ft)
            result[ft].push(c);
    }
    return result;
}
// ─── File type detection ──────────────────────────────────────────────────────
function detectFileType(folder, moduleName) {
    const rel = folder.slice(moduleName.length + 1); // strip "cafeFlow/"
    if (rel === 'layer_1_external')
        return 'layer1';
    if (rel === 'layer_4_entities')
        return 'layer4';
    if (rel === 'layer_3_usecases')
        return 'layer3';
    if (rel === 'layer_2_controllers')
        return 'layer2';
    return null;
}
// ─── Skill resolution (from module.ts ISkill export) ─────────────────────────
// File types that require the project-level definition as additional context
const NEEDS_DEFINITION = ['layer1', 'layer4'];
function resolveSkillPaths(fileType, moduleExports) {
    if (!moduleExports)
        return [];
    const paths = [...(moduleExports.skills?.[fileType]?.skillPath ?? [])];
    if (NEEDS_DEFINITION.includes(fileType)) {
        const defPaths = moduleExports.skills?.definition?.skillPath ?? [];
        paths.push(...defPaths);
    }
    return paths;
}
// ─── Module loader (collabImport → esbuild fallback) ─────────────────────────
async function loadModuleExports(project, moduleName) {
    const path = toMlsPath(project, 2, moduleName, 'module', '.ts');
    const f = mls.stor.convertFileReferenceToFile(path);
    if (!f)
        return null;
    try {
        return await collabImport(f);
    }
    catch {
        return await loadModuleByBuild(path);
    }
}
// ─── ID helpers ───────────────────────────────────────────────────────────────
function makePlanId(moduleName, shortName, ft) {
    return `gen-l1-${safe(moduleName)}-${safe(shortName)}-${ft}`;
}
function safe(s) {
    return s.replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase();
}
// ─── Builders ─────────────────────────────────────────────────────────────────
function mkStep(context, rootStep, planId, title, args, dependsOn, status = 'waiting_dependency') {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: rootStep.stepId,
        step: {
            type: 'agent',
            stepId: 0,
            interaction: null,
            stepTitle: title,
            status,
            nextSteps: [],
            agentName: args.pipelineItem.agent,
            prompt: JSON.stringify(args),
            rags: [],
            planning: { planId, dependsOn, executionMode: 'parallel_static', executionHost: 'client' },
        },
    };
}
function mkFail(context, parentStep, step, hookSequential, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status: 'failed',
        traceMsg,
    };
}
// ─── Prompts ──────────────────────────────────────────────────────────────────
const systemPrompt = `<!-- modelType: codepro -->

You confirm the L1 generation scan.

If files were found, return:
{"type":"flexible","result":{"status":"ok","notes":[]}}

If nothing to generate, return:
{"type":"result","result":"No L1 files need generation"}

Return valid JSON only.`;
function buildHumanPrompt(summaries) {
    const lines = ['# L1 Generation Scan', ''];
    for (const s of summaries) {
        lines.push(`## Module: ${s.moduleName}`);
        lines.push(`  layer_1_external: ${s.layer1}, layer_4_entities: ${s.layer4}, layer_3_usecases: ${s.layer3}, layer_2_controllers: ${s.layer2}`);
    }
    const total = summaries.reduce((n, s) => n + s.layer1 + s.layer4 + s.layer3 + s.layer2, 0);
    lines.push('', `Total: ${total} file(s) to generate.`);
    lines.push('Confirm and return your response.');
    return lines.join('\n');
}
