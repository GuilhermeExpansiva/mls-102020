/// <mls fileReference="_102020_/l2/agentMaterializeSolution/agentMaterializeL1.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
export function createAgent() {
    return {
        agentName: 'agentMaterializeL1',
        agentProject: 102020,
        agentFolder: 'agentMaterializeSolution',
        agentDescription: 'Scan L1 defs, detect outdated/missing .ts outputs and dispatch agentMaterializeLayer',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
// ─── project.json ─────────────────────────────────────────────────────────────
async function readProjectModules(project) {
    const ref = `_${project}_/l5/project.json`;
    const info = mls.stor.convertFileReferenceToFile(ref);
    const key = mls.stor.getKeyToFile(info);
    const sf = mls.stor.files[key];
    if (!sf)
        throw new Error(`[agentMaterializeL1] project.json not found: ${ref}`);
    const content = await sf.getContent();
    const config = JSON.parse(typeof content === 'string' ? content : JSON.stringify(content));
    return (config.modules ?? []).map(m => m.moduleName);
}
// ─── detection ────────────────────────────────────────────────────────────────
function findTasksNeedingMaterialization(moduleNames, project) {
    const files = mls.stor.files;
    const tasks = [];
    for (const moduleName of moduleNames) {
        for (const key of Object.keys(files)) {
            const file = files[key];
            if (file.project !== project || file.level !== 1 || file.extension !== '.defs.ts')
                continue;
            // must be inside ${moduleName}/layer_*
            if (!file.folder.startsWith(`${moduleName}/layer_`))
                continue;
            // extract the layer segment: first part after moduleName/
            const afterModule = file.folder.slice(moduleName.length + 1); // e.g. 'layer_3_usecases' or 'layer_3_usecases/sub'
            const layer = afterModule.split('/')[0]; // e.g. 'layer_3_usecases'
            const defsPath = `_${project}_/l1/${file.folder}/${file.shortName}${file.extension}`;
            const defsUpdatedAt = file.updatedAt ?? 0;
            const tsKey = mls.stor.getKeyToFile({
                project, level: 1,
                folder: file.folder,
                shortName: file.shortName,
                extension: '.ts',
            });
            const tsFile = mls.stor.files[tsKey];
            if (!tsFile || defsUpdatedAt > (tsFile.updatedAt ?? 0)) {
                tasks.push({ defsPath, moduleName, layer });
            }
        }
    }
    return tasks;
}
// ─── beforePromptImplicit ─────────────────────────────────────────────────────
async function beforePromptImplicit(agent, context, userPrompt) {
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const addMessageAI = {
        type: 'add-message-ai',
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: systemPrompt },
                { type: 'human', content: JSON.stringify({ project, totalTasks: tasks.length }) },
            ],
            taskTitle: `materialize-l1:project-${project}`,
            threadId: context.message.threadId,
            userMessage: userPrompt || `project:${project}`,
        },
    };
    return [addMessageAI];
}
// ─── beforePromptStep ─────────────────────────────────────────────────────────
async function beforePromptStep(agent, context, parentStep, _step, hookSequential, args) {
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const promptReady = {
        type: 'prompt_ready',
        args: args || '',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: JSON.stringify({ project, totalTasks: tasks.length }),
        systemPrompt,
    };
    return [promptReady];
}
// ─── afterPromptStep ──────────────────────────────────────────────────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`(${agent.agentName})[afterPromptStep] invalid params`);
    const project = mls.actualProject || 0;
    const moduleNames = await readProjectModules(project);
    const tasks = findTasksNeedingMaterialization(moduleNames, project);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        cleaner: 'input_output',
        status: 'completed',
    };
    if (tasks.length === 0)
        return [updateStatus];
    const newSteps = tasks.map(task => {
        const fileId = task.defsPath.split('/').pop()?.replace(/\.defs\.ts$/, '') ?? '';
        return {
            type: 'add-step',
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: parentStep.stepId,
            stepTitle: `${task.layer}:${fileId}`,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: 'agentMaterializeLayer',
                prompt: JSON.stringify({ pathDefs: task.defsPath, moduleName: task.moduleName, layer: task.layer }),
                rags: [],
            },
        };
    });
    return [...newSteps, updateStatus];
}
// ─── system prompt ────────────────────────────────────────────────────────────
const systemPrompt = `
<!-- modelType: nano -->

Echo back the summary.

## Output format
Return ONLY valid JSON, no markdown fences, no prose.

{
  "type": "flexible",
  "result": {
    "project": <echo project>,
    "totalTasks": <echo totalTasks>
  }
}
`;
//#endregion
