/// <mls fileReference="_102020_/l2/skills/molecules/groupNotification.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
