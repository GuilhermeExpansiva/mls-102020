/// <mls fileReference="_102020_/l2/skills/design/glassmorphism.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
