/// <mls shortName="auraOrganismBase" project="102020" enhancement="_100554_enhancementLit" />

import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';

@customElement('aura-organism-base-102020')
export class AuraOrganismBase extends LitElement {


}
