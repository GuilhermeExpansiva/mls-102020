/// <mls fileReference="_102020_/l2/skills/design/glassmorphism.test.ts" enhancement="_blank"/>

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];