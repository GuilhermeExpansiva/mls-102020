/// <mls shortName="agentScaffoldToOrganismMock" project="102020" enhancement="_blank" folder="agents" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];